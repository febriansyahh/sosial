-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- Inang: localhost
-- Waktu pembuatan: 25 Mar 2021 pada 13.34
-- Versi Server: 5.1.73-log
-- Versi PHP: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `sispo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `agenda`
--

CREATE TABLE IF NOT EXISTS `agenda` (
  `id_agenda` int(11) NOT NULL AUTO_INCREMENT,
  `nama_agenda` varchar(50) NOT NULL,
  `jenis_acara` varchar(30) NOT NULL,
  `isi_agenda` text NOT NULL,
  `tgl_agenda` date NOT NULL,
  `jam_agenda` time NOT NULL,
  `file_agenda` text NOT NULL,
  `undangan` text NOT NULL,
  `waktu_agd` datetime NOT NULL,
  PRIMARY KEY (`id_agenda`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data untuk tabel `agenda`
--

INSERT INTO `agenda` (`id_agenda`, `nama_agenda`, `jenis_acara`, `isi_agenda`, `tgl_agenda`, `jam_agenda`, `file_agenda`, `undangan`, `waktu_agd`) VALUES
(24, 'Undangan Dies Natalies UPGRIS', '', '<p>Undangan Dies Natalies UPGRIS 10 Juli 2019 Jam 10.00<br></p>', '2019-08-05', '21:15:00', '201553072_IMK.pdf', 'Rektor', '0000-00-00 00:00:00'),
(25, 'Undangan Gladi Bersih Wisuda Periode Oktober 2019', '', '<p>Undangan Gladi Bersih Wisuda Periode Oktober 2019<br></p><p>Tanggal 21 Agustus 2019</p><p>Auditorium UMK</p>', '2019-08-21', '10:00:00', 'Und Gladi Wisuda 2018.pdf', 'Rektor, Wakil Rektor 1, Wakil Rektor 2, Wakil Rektor 3, Wakil Rektor 4', '0000-00-00 00:00:00'),
(26, 'Undangan Rapat Senat', '', '<p>Rapat Senat Universitas</p>', '2019-08-20', '12:00:00', 'Undangan Senat.pdf', 'Rektor', '0000-00-00 00:00:00'),
(27, 'Undangan Rapat dengan YP UMK', '', '<p>Rapat</p>', '2019-08-20', '15:30:00', 'Und Rapat YP UMK.pdf', 'Rektor', '0000-00-00 00:00:00'),
(28, 'Coba', '', '<p>-Â Â Â Â </p>', '2019-08-26', '11:15:00', 'DOKUMEN KOSONG.pdf', 'Wakil Rektor 1, Wakil Rektor 2', '2019-08-26 11:06:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar_grup_e`
--

CREATE TABLE IF NOT EXISTS `daftar_grup_e` (
  `id_daftar_g_e` int(11) NOT NULL AUTO_INCREMENT,
  `id_grup_e` int(11) NOT NULL,
  `id_pimpinan` int(11) NOT NULL,
  PRIMARY KEY (`id_daftar_g_e`),
  KEY `id_grup_e` (`id_grup_e`),
  KEY `id_pimpinan` (`id_pimpinan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data untuk tabel `daftar_grup_e`
--

INSERT INTO `daftar_grup_e` (`id_daftar_g_e`, `id_grup_e`, `id_pimpinan`) VALUES
(4, 2, 3),
(5, 2, 4),
(6, 2, 5),
(7, 2, 6),
(8, 2, 7),
(9, 3, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dispo_s_masuk`
--

CREATE TABLE IF NOT EXISTS `dispo_s_masuk` (
  `id_dispo` int(11) NOT NULL AUTO_INCREMENT,
  `id_s_masuk` int(11) NOT NULL,
  `id_pgw` int(11) NOT NULL,
  `unit` enum('0','1') NOT NULL,
  `informasi` text NOT NULL,
  `tgl_dispo` datetime NOT NULL,
  `pemberi` int(11) NOT NULL,
  `status` enum('0','1','2') NOT NULL,
  `info_pemberi_dispo` text NOT NULL,
  PRIMARY KEY (`id_dispo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data untuk tabel `dispo_s_masuk`
--

INSERT INTO `dispo_s_masuk` (`id_dispo`, `id_s_masuk`, `id_pgw`, `unit`, `informasi`, `tgl_dispo`, `pemberi`, `status`, `info_pemberi_dispo`) VALUES
(2, 22, 3, '0', 'Disposisi', '2020-04-27 12:25:47', 1, '0', 'DIsposisi'),
(3, 22, 11, '0', 'DIsposisi', '2020-04-27 12:38:07', 3, '2', ''),
(4, 37, 3, '0', '', '2020-04-27 15:41:14', 1, '0', 'Disposisi PSI'),
(10, 37, 26, '1', 'Disposisi PSI', '2020-04-27 16:19:44', 3, '2', ''),
(11, 37, 11, '0', 'Disposisi PSI', '2020-04-27 16:19:46', 3, '2', ''),
(12, 55, 3, '0', 'Disposisi WR2', '2020-04-28 11:55:30', 1, '0', 'Disposisi Ka BAU'),
(13, 55, 13, '0', 'Disposisi Ka BAU', '2020-04-28 11:56:58', 3, '0', 'Disposisi Yayasan'),
(14, 55, 33, '1', 'Disposisi Yayasan', '2020-04-28 12:02:17', 13, '2', ''),
(15, 56, 3, '0', 'Lanjutkan', '2020-04-30 09:25:25', 1, '0', 'Disposisi'),
(16, 56, 2, '0', 'Lanjutkan', '2020-04-30 09:25:25', 1, '0', 'Disposisi WR2. Mohon di setujui'),
(17, 56, 3, '0', 'Disposisi WR2. Mohon di setujui', '2020-04-30 09:36:51', 2, '2', ''),
(18, 56, 10, '0', 'Disposisi', '2020-04-30 09:46:26', 3, '1', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `format_surat`
--

CREATE TABLE IF NOT EXISTS `format_surat` (
  `id_format_s` int(11) NOT NULL AUTO_INCREMENT,
  `format_surat` varchar(50) NOT NULL,
  `id_unit` int(11) NOT NULL,
  PRIMARY KEY (`id_format_s`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data untuk tabel `format_surat`
--

INSERT INTO `format_surat` (`id_format_s`, `format_surat`, `id_unit`) VALUES
(1, 'UPT.PSI.UMK', 26),
(5, 'AK.UMK/AKA', 13001),
(6, 'BPM.UMK', 28),
(7, 'AK.UMK/KMH', 13003),
(8, 'R.III.UMK/KMH', 13003),
(9, 'R.UMK/Sek', 10),
(10, 'R.I.UMK/Sek', 10),
(11, 'R.II.UMK/Sek', 10),
(12, 'R.III.UMK/Sek', 10),
(13, 'R.IV.UMK/Sek', 10),
(14, 'FT.UMK', 29);

-- --------------------------------------------------------

--
-- Struktur dari tabel `grup_email`
--

CREATE TABLE IF NOT EXISTS `grup_email` (
  `id_grup_e` int(11) NOT NULL AUTO_INCREMENT,
  `nama_grup_e` varchar(30) NOT NULL,
  `status_grup_e` enum('Aktif','Tidak Aktif') NOT NULL,
  PRIMARY KEY (`id_grup_e`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `grup_email`
--

INSERT INTO `grup_email` (`id_grup_e`, `nama_grup_e`, `status_grup_e`) VALUES
(2, 'Grup Satu', 'Aktif'),
(3, 'Coba', 'Aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kode_surat`
--

CREATE TABLE IF NOT EXISTS `kode_surat` (
  `id_kode` int(11) NOT NULL AUTO_INCREMENT,
  `kd_surat` varchar(5) NOT NULL,
  `nama_kode` varchar(50) NOT NULL,
  `level` varchar(5) NOT NULL,
  `parent` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_kode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=270 ;

--
-- Dumping data untuk tabel `kode_surat`
--

INSERT INTO `kode_surat` (`id_kode`, `kd_surat`, `nama_kode`, `level`, `parent`) VALUES
(2, '03', 'Bantuan Tenaga Pengajar', '2', '5'),
(3, 'A', 'Pendidikan dan Pengajaran', '1', NULL),
(4, 'B', 'Penelitian', '1', NULL),
(5, 'C', 'Pengabdian Masyarakat', '1', NULL),
(6, 'D', 'Organisasi', '1', NULL),
(7, 'F', 'Komunikasi', '1', NULL),
(9, 'G', 'Kepegawaian', '1', NULL),
(10, 'H', 'Keuangan', '1', NULL),
(11, 'I', 'Perbekalan', '1', NULL),
(12, 'J', 'Tata Usaha', '1', NULL),
(13, 'K', 'Hubungan Masyarakat', '1', NULL),
(14, 'L', 'Umum', '1', NULL),
(15, 'SK', 'Surat Keputusan Rektor', '1', NULL),
(16, 'E', 'Manajemen', '1', NULL),
(17, '01', 'Academic manuscript', '2', '3'),
(18, '02', 'Alumni', '2', '3'),
(19, '03', 'Bantuan luar negeri', '2', '3'),
(21, '04', 'Bea Siswa', '2', '3'),
(22, '05', 'Coschap', '2', '3'),
(25, '07', 'Daftar Mahasiswa', '2', '3'),
(26, '06', 'Daftar Dosen', '2', '3'),
(27, '01', 'Dokumentasi', '2', '4'),
(28, '01', 'Afiliasi', '2', '5'),
(29, '02', 'Bantuan Tenaga Mahasiswa', '2', '5'),
(30, '01', 'Buku Petunjuk', '2', '6'),
(31, '01', 'Pemeriksaan', '2', '16'),
(32, '01', 'Instruksi', '2', '7'),
(33, '01', 'Asuransi Kesehatan', '2', '9'),
(34, '01', 'Anggaran', '2', '10'),
(35, '01', 'Air Minum', '2', '11'),
(36, '01', 'Alamat dan Nama Kantor', '2', '12'),
(37, '01', 'Iklan', '2', '13'),
(38, '02', 'Konferensi Pers', '2', '13'),
(39, '01', 'Dies Natalis', '2', '14'),
(40, '08', 'Dispensasi', '2', '3'),
(41, '09', 'Ijasah', '2', '3'),
(42, '10', 'Ikatan', '2', '3'),
(43, '11', 'Judisium', '2', '3'),
(44, '12', 'Kalender akademis', '2', '3'),
(45, '13', 'Kartu Mahasiswa', '2', '3'),
(46, '14', 'Kemampuan Belajar', '2', '3'),
(47, '15', 'Kewiraan', '2', '3'),
(48, '16', 'Konsorsium', '2', '3'),
(49, '17', 'Kuliah', '2', '3'),
(50, '18', 'Kurikulum', '2', '3'),
(51, '19', 'Lulusan Sarjana', '2', '3'),
(52, '20', 'Mahasiswa Asing', '2', '3'),
(53, '21', 'Mahasiswa Pendengar', '2', '3'),
(54, '22', 'Mahasiswa Teladan', '2', '3'),
(55, '23', 'Mutasi Mahasiswa', '2', '3'),
(56, '24', 'Nilai', '2', '3'),
(57, '25', 'Pekan Orientasi Studi Mahasiswa', '2', '3'),
(58, '26', 'Pencangkokan Mahasiswa', '2', '3'),
(59, '27', 'Pendaftaran ulang', '2', '3'),
(60, '28', 'Pendidikan Spesialisasi', '2', '3'),
(61, '29', 'Pengawas Ujian', '2', '3'),
(62, '30', 'Penilaian Ujian', '2', '3'),
(63, '31', 'Penulisan Buku', '2', '3'),
(64, '32', 'Perpustakaan', '2', '3'),
(65, '33', 'Pindah Universitas', '2', '3'),
(66, '34', 'Praktikum', '2', '3'),
(67, '35', 'Program Doktor', '2', '3'),
(68, '36', 'Resimen Mahasiswa', '2', '3'),
(69, '37', 'Silabus', '2', '3'),
(70, '38', 'Sistem Kredit', '2', '3'),
(71, '39', 'Skorsing Mahasiswa', '2', '3'),
(72, '40', 'Skripsi', '2', '3'),
(73, '41', 'Sumpah Doktor', '2', '3'),
(74, '42', 'S T T B', '2', '3'),
(75, '43', 'Syarat Calon Mahasiswa', '2', '3'),
(76, '44', 'Testing Mahasiswa', '2', '3'),
(77, '45', 'Terjemahan', '2', '3'),
(78, '46', 'Thesis', '2', '3'),
(79, '47', 'Tidak Aktif Kuliah', '2', '3'),
(80, '48', 'Ujian', '2', '3'),
(81, '49', 'Wajib Militer', '2', '3'),
(82, '50', 'Wewena g Mengajar & Mengaji', '2', '3'),
(83, '51', 'Wisuda Sarjana', '2', '3'),
(84, '52', 'Dan Sebagainya', '2', '3'),
(86, '03', 'Ijin-ijin', '2', '4'),
(87, '07', 'Telegram', '2', '4'),
(88, '08', 'Dan Sebagainya', '2', '4'),
(90, '02', 'Kredit Point', '2', '9'),
(91, '03', 'Cuti', '2', '9'),
(92, '04', 'Daftar Prestasi', '2', '9'),
(93, '05', 'Daftar Riwayat Hidup', '2', '9'),
(94, '06', 'Formasi', '2', '9'),
(95, '07', 'Istirahat Sakit', '2', '9'),
(96, '08', 'Kartu Pegawai', '2', '9'),
(97, '09', 'Kenaikan Gaji Berkala', '2', '9'),
(98, '10', 'Kenaikan Pangkat', '2', '9'),
(99, '11', 'Kesehatan', '2', '9'),
(100, '12', 'Kredit Rumah', '2', '9'),
(101, '13', 'Kredit Kendaraan', '2', '9'),
(102, '14', 'Kursus Pegawai Intern', '2', '9'),
(103, '15', 'Lamaran Pekerjaan', '2', '9'),
(104, '16', 'Lowongan Jabatan', '2', '9'),
(105, '17', 'Lowongan Pekerjaan', '2', '9'),
(106, '18', 'Masa Kerja', '2', '9'),
(107, '19', 'Mutasi Pegawai', '2', '9'),
(108, '20', 'NIP', '2', '9'),
(109, '21', 'Olahraga', '2', '9'),
(110, '22', 'Pegawai Teladan', '2', '9'),
(111, '23', 'Pemberhentian Pegawai', '2', '9'),
(112, '24', 'Pemberhentian Sementara', '2', '9'),
(113, '25', 'Penambahan Pegawai', '2', '9'),
(114, '26', 'Penempatan Pegawai', '2', '9'),
(115, '27', 'Penilaian Pelaksanaan Pegawai', '2', '9'),
(116, '28', 'Pensiun', '2', '9'),
(117, '29', 'Permintaan Restitusi Pengobatan', '2', '9'),
(118, '30', 'Rekreasi', '2', '9'),
(119, '31', 'Santiaji', '2', '9'),
(120, '32', 'Seleksi Pegawai', '2', '9'),
(121, '33', 'Sumpah Jabatan', '2', '9'),
(122, '34', 'Sumpah Pegawai', '2', '9'),
(123, '35', 'Tanda Penghargaan', '2', '9'),
(124, '36', 'Tugas Belajar Pegawai', '2', '9'),
(125, '37', 'Ujian Dinas', '2', '9'),
(126, '38', 'Usul Tenaga Administrasi', '2', '9'),
(127, '39', 'Usul Tenaga Edukatif', '2', '9'),
(128, '40', 'Dan Sebagaianya', '2', '9'),
(132, '06', 'Surat Teguran', '2', '4'),
(133, '04', 'Butsi', '2', '5'),
(134, '05', 'Ceramah', '2', '5'),
(135, '06', 'Kerjasama', '2', '5'),
(136, '07', 'Kuliah Kerja Nyata', '2', '5'),
(137, '08', 'Kursus Exstra', '2', '5'),
(138, '09', 'Pelayanan Kesehatan', '2', '5'),
(139, '10', 'Pemeriksaan Sample Obat', '2', '5'),
(140, '11', 'Penerimaan Peninjauan', '2', '5'),
(141, '12', 'Penyuluhan dan Bimbingan', '2', '5'),
(142, '13', 'Seminar', '2', '5'),
(143, '14', 'Studi Praktek', '2', '5'),
(144, '15', 'Widya Wisata', '2', '5'),
(145, '16', 'Workshop', '2', '5'),
(146, '17', 'Dan Sebagainya', '2', '5'),
(147, '02', 'Badan Koordinasi Kemahasiswaan', '2', '6'),
(148, '03', 'Dewan Pegawai (KORPRI)', '2', '6'),
(149, '04', 'Dewan Penyantun', '2', '6'),
(150, '05', 'Dharma Wanita', '2', '6'),
(151, '06', 'Keluarga Universitas', '2', '6'),
(152, '07', 'KORPRI', '2', '6'),
(153, '08', 'Majelis Pegawai', '2', '6'),
(154, '09', 'Pengurus Fak, Lembaga Univ, RT', '2', '6'),
(155, '10', 'Reorganisasi', '2', '6'),
(156, '11', 'Referendum', '2', '6'),
(157, '12', 'Senat Mahasiswa', '2', '6'),
(158, '13', 'Senat Universitas', '2', '6'),
(159, '14', 'Statuta', '2', '6'),
(160, '15', 'Struktur Organisasi', '2', '6'),
(161, '16', 'Timbang terima jabatan', '2', '6'),
(162, '17', 'Dan Sebagainya', '2', '6'),
(164, '02', 'Pengembangan Universitas', '2', '16'),
(165, '03', 'Penyempurnaan', '2', '16'),
(166, '04', 'Rencana Kerja', '2', '16'),
(167, '05', 'Dan Sebagainya', '2', '16'),
(168, '02', 'Laporan', '2', '7'),
(169, '03', 'Rapat Dinas', '2', '7'),
(170, '04', 'Rapat Kerja Universitas', '2', '7'),
(171, '05', 'Surat Perintah', '2', '7'),
(172, '06', 'Surat Teguran', '2', '7'),
(173, '07', 'Telegram', '2', '7'),
(174, '08', 'Dan Sebagainya', '2', '7'),
(176, '03', 'Bendaharawan', '2', '10'),
(177, '04', 'Beras', '2', '10'),
(178, '05', 'Daftar Isian Kegiatan (DIK)', '2', '10'),
(179, '06', 'Daftar Isian Proyek (DIP)', '2', '10'),
(180, '07', 'Daftar Usulan Kegiatan (DUK)', '2', '10'),
(181, '08', 'Daftar Usulan Proyek (DUP)', '2', '10'),
(182, '09', 'Gaji', '2', '10'),
(183, '10', 'Honorarium', '2', '10'),
(184, '11', 'Pajak', '2', '10'),
(185, '12', 'Pelita', '2', '10'),
(186, '13', 'Pembuat Daftar Gaji', '2', '10'),
(187, '14', 'Saldo Giro', '2', '10'),
(188, '15', 'Sewa Rumah', '2', '10'),
(189, '16', 'SKKP', '2', '10'),
(190, '17', 'SPJ', '2', '10'),
(191, '18', 'SPMU', '2', '10'),
(192, '19', 'SPP', '2', '10'),
(193, '20', 'Tunjangan Jabatan', '2', '10'),
(194, '21', 'Tunjangan', '2', '10'),
(195, '22', 'Uang Lembur', '2', '10'),
(196, '23', 'Uang Praktikum', '2', '10'),
(197, '24', 'Vakasi', '2', '10'),
(198, '25', 'Dan Sebagainya', '2', '10'),
(199, '02', 'Alat Kantor', '2', '11'),
(200, '03', 'Alat Kantor Laboratorium', '2', '11'),
(201, '04', 'Alat Peraga', '2', '11'),
(202, '05', 'Alat Rumah Tangga', '2', '11'),
(203, '06', 'Alat Tulis', '2', '11'),
(204, '07', 'Asrama', '2', '11'),
(205, '08', 'Balik Nama Kendaraan', '2', '11'),
(206, '09', 'Bahan Kimia', '2', '11'),
(207, '10', 'Disel', '2', '11'),
(208, '11', 'Distribusi Barang', '2', '11'),
(209, '12', 'Ganti Rugi Tanah', '2', '11'),
(210, '13', 'Gedung', '2', '11'),
(211, '14', 'Inventarisasi', '2', '11'),
(212, '15', 'Lelangan', '2', '11'),
(213, '16', 'Mesin Fotocopy', '2', '11'),
(214, '17', 'Mesin Hitung', '2', '11'),
(215, '18', 'Mesin Kantor', '2', '11'),
(216, '19', 'Mesin Stensil', '2', '11'),
(217, '20', 'Mesin Ketik', '2', '11'),
(218, '21', 'Mobil', '2', '11'),
(219, '22', 'Obat-obatan', '2', '11'),
(220, '23', 'Pakaian Dinas', '2', '11'),
(221, '24', 'Papan Nama', '2', '11'),
(222, '25', 'Pengadaan Barang', '2', '11'),
(223, '26', 'Perabot Kantor', '2', '11'),
(224, '27', 'Pemohonan Kendaraan', '2', '11'),
(225, '28', 'Pesawat Telepon', '2', '11'),
(226, '29', 'Sepeda', '2', '11'),
(227, '30', 'Standardisasi', '2', '11'),
(228, '31', 'Toga', '2', '11'),
(229, '32', 'Dan Sebagainya', '2', '11'),
(231, '02', 'Amplop Surat', '2', '12'),
(232, '03', 'Cap Dinas', '2', '12'),
(233, '04', 'Formulir', '2', '12'),
(234, '05', 'Kode Surat', '2', '12'),
(235, '06', 'Pedoman Surat', '2', '12'),
(236, '07', 'Pemusnahan Arsip', '2', '12'),
(237, '08', 'Pengetikan', '2', '12'),
(238, '09', 'Pengisian Daftar Pertanyaan', '2', '12'),
(239, '10', 'Penyimpanan Arsip', '2', '12'),
(240, '11', 'Penyusutan Arsip', '2', '12'),
(241, '12', 'Petunjuk Telepon', '2', '12'),
(242, '13', 'Statistik', '2', '12'),
(243, '14', 'Surat Dinas', '2', '12'),
(244, '15', 'Undangan', '2', '12'),
(245, '16', 'Dan Sebagainya', '2', '12'),
(247, '03', 'Kunjungan', '2', '13'),
(248, '04', 'Pameran', '2', '13'),
(249, '05', 'Pres Releace', '2', '13'),
(250, '06', 'Sayembara', '2', '13'),
(251, '07', 'Siaran Ilmu melalui koran,radio,relevisi', '2', '13'),
(252, '08', 'Spanduk', '2', '13'),
(253, '09', 'Dan Sebagainya', '2', '13'),
(254, '02', 'Hari Libur', '2', '14'),
(255, '03', 'Jamban', '2', '14'),
(256, '04', 'Keamanan', '2', '14'),
(257, '05', 'Kebersihan', '2', '14'),
(258, '06', 'Kenang-kenangan', '2', '14'),
(259, '07', 'Kunjungan Tamu', '2', '14'),
(260, '08', 'Lelayu', '2', '14'),
(261, '09', 'Parkir', '2', '14'),
(262, '10', 'Peraturan-peraturan', '2', '14'),
(263, '11', 'Sumbangan', '2', '14'),
(264, '12', 'Tanah', '2', '14'),
(265, '13', 'Ucapan terima kasih', '2', '14'),
(266, '14', 'Upacara', '2', '14'),
(267, '15', 'Vandel', '2', '14'),
(268, '16', 'Dan Sebagainya', '2', '14'),
(269, '02', 'Belanja', '2', '10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(25) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `jabatan` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tmpt_lahir` varchar(25) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jekel` enum('Pria','Wanita') NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pgw`
--

CREATE TABLE IF NOT EXISTS `pgw` (
  `id_pgw` bigint(20) NOT NULL AUTO_INCREMENT,
  `nip` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gelar_depan` varchar(10) NOT NULL,
  `gelar_belakang` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `jabatan_fungsional` varchar(100) NOT NULL,
  `jabatan_struktural` varchar(100) NOT NULL,
  `pangkat` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pgw`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `pgw`
--

INSERT INTO `pgw` (`id_pgw`, `nip`, `nama`, `gelar_depan`, `gelar_belakang`, `email`, `jabatan_fungsional`, `jabatan_struktural`, `pangkat`) VALUES
(1, '0610701000001014', 'Suparnyo', 'Dr', 'SH, MS', 'd.suparnyo@yahoo.co.', 'Lektor Kepala', 'Rektor', 'IV/b'),
(2, '196612071992031003', 'Murtono', 'Dr. Drs.', 'M.Pd', 'murtono@umk.ac.id', 'Lektor Kepala', 'Wakil Rektor 1', 'IV/a'),
(3, '0610702010101026', 'H. M. Zainuri', 'Dr. Drs.', 'MM.', 'zainuri@umk.ac.id', 'Lektor', 'Wakil Rektor 2', 'III/d'),
(4, '0610701000001138', 'Rochmad Winarso', '', 'ST., MT', 'boswin2002@gmail.com', 'Lektor', 'Wakil Rektor 3', 'III/d'),
(5, '0610701000001017', 'Subarkah', 'Dr.', 'SH, M.Hum', '', 'Lektor Kepala', 'Wakil Rektor 4', 'IV/a'),
(7, '0610702000002184', 'Abdul Ghofur', '', 'A.Md', '', 'Tenaga Laboran', 'Pelaksana', 'II/b'),
(8, '0610701000001303', 'Aditya Akbar Riadi', '', 'S.Kom., M.Kom', 'adit.zink@gmail.com', 'Asisten Ahli', '', 'III/b'),
(9, '0610701000001262', 'Fajar Nugraha', '', 'S.Kom, M.Kom.', 'fajar.nugraha@umk.ac', 'Asisten Ahli', 'Ka UPT PSI', 'III/b'),
(10, 'ardi_2018', 'Ardi Irfanto', '', 'S.Kom.', 'ardiirfanto@yahoo.co', '', '', ''),
(11, 'Higan_2018', 'Higan Nanda Ahyudiya', '', 'S.Kom.', 'higannahyudiya@gmail', '', '', ''),
(12, '0628017501', 'Anteng Widodo', '', 'ST, M.Kom', 'antengwidodo@si.umk.', 'Asisten Ahli', 'Dosen', 'III/b'),
(13, '0610796000002102', 'Muh. Manjid', '', 'SE', 'muh.manjid@umk.ac.id', '', 'Ka BAU', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pimpinan`
--

CREATE TABLE IF NOT EXISTS `pimpinan` (
  `id_pimpinan` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gelar_depan` varchar(10) NOT NULL,
  `gelar_belakang` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jabatan_fungsional` varchar(100) NOT NULL,
  `jabatan_struktural` varchar(100) NOT NULL,
  `pangkat` varchar(20) NOT NULL,
  `status` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_pimpinan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `pimpinan`
--

INSERT INTO `pimpinan` (`id_pimpinan`, `nip`, `nama`, `gelar_depan`, `gelar_belakang`, `email`, `jabatan_fungsional`, `jabatan_struktural`, `pangkat`, `status`) VALUES
(3, '0610701000001014', 'Suparnyo', 'Dr', 'SH, MS', 'd.suparnyo@yahoo.co.id', 'Lektor Kepala', 'Rektor', 'IV/b', '1'),
(4, '196612071992031003', 'Murtono', 'Dr. Drs.', 'M.Pd', 'murtono@umk.ac.id', 'Lektor Kepala', 'Wakil Rektor 1', 'IV/a', '1'),
(5, '0610702010101026', 'H. M. Zainuri', 'Dr. Drs.', 'MM.', '', 'Lektor', 'Wakil Rektor 2', 'III/d', '1'),
(6, '0610701000001138', 'Rochmad Winarso', '', 'ST., MT', 'boswin2002@gmail.com', 'Lektor', 'Wakil Rektor 3', 'III/d', '1'),
(7, '0610701000001017 ', 'Subarkah', 'Dr.', 'SH, M.Hum', '', 'Lektor Kepala', 'Wakil Rektor 4', 'IV/a', '1'),
(8, '0610796000002102', 'Muh. Manjid', '', 'SE', 'muh.manjid@umk.ac.id', '', 'Ka BAU', '', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `setting_nomor`
--

CREATE TABLE IF NOT EXISTS `setting_nomor` (
  `id_nomor` int(11) NOT NULL AUTO_INCREMENT,
  `tipe` enum('Urut Nomor','Urut Kode') NOT NULL,
  `setting` enum('Manual','Otomatis') NOT NULL,
  `id_kode` int(11) DEFAULT NULL,
  `id_unit` int(11) NOT NULL,
  `nomor_surat` varchar(10) NOT NULL,
  PRIMARY KEY (`id_nomor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data untuk tabel `setting_nomor`
--

INSERT INTO `setting_nomor` (`id_nomor`, `tipe`, `setting`, `id_kode`, `id_unit`, `nomor_surat`) VALUES
(6, 'Urut Kode', 'Manual', 17, 26, '12'),
(7, 'Urut Kode', 'Manual', 21, 26, '22'),
(8, 'Urut Nomor', 'Manual', NULL, 26, '15'),
(9, 'Urut Kode', 'Manual', 269, 26, '15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `set_notif`
--

CREATE TABLE IF NOT EXISTS `set_notif` (
  `id_s_notif` int(11) NOT NULL AUTO_INCREMENT,
  `id_agenda` int(11) NOT NULL,
  `set_waktu` varchar(30) NOT NULL,
  `waktu_notif` time NOT NULL,
  `status_kirim` enum('Belum','Sudah') NOT NULL,
  `id_grup_e` int(11) NOT NULL,
  PRIMARY KEY (`id_s_notif`),
  KEY `id_agenda` (`id_agenda`),
  KEY `id_grup_e` (`id_grup_e`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data untuk tabel `set_notif`
--

INSERT INTO `set_notif` (`id_s_notif`, `id_agenda`, `set_waktu`, `waktu_notif`, `status_kirim`, `id_grup_e`) VALUES
(43, 24, '00:30:00', '20:45:00', 'Sudah', 3),
(44, 25, '00:30:00', '09:30:00', 'Sudah', 2),
(45, 26, '00:30:00', '11:30:00', 'Sudah', 3),
(47, 27, '00:30:00', '15:00:00', 'Sudah', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_bau`
--

CREATE TABLE IF NOT EXISTS `status_bau` (
  `id_s_bau` int(11) NOT NULL AUTO_INCREMENT,
  `id_s_masuk` int(11) NOT NULL,
  `ket` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_s_bau`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_keluar`
--

CREATE TABLE IF NOT EXISTS `surat_keluar` (
  `id_s_keluar` int(11) NOT NULL AUTO_INCREMENT,
  `no_s_keluar` varchar(100) NOT NULL,
  `tgl_s_keluar` date NOT NULL,
  `perihal_s_keluar` text NOT NULL,
  `ket_s_keluar` text NOT NULL,
  `scan_s_keluar` text NOT NULL,
  `id_kode` int(11) NOT NULL,
  `id_unit` int(11) NOT NULL,
  `time_s_keluar` datetime NOT NULL,
  PRIMARY KEY (`id_s_keluar`),
  KEY `id_kode` (`id_kode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data untuk tabel `surat_keluar`
--

INSERT INTO `surat_keluar` (`id_s_keluar`, `no_s_keluar`, `tgl_s_keluar`, `perihal_s_keluar`, `ket_s_keluar`, `scan_s_keluar`, `id_kode`, `id_unit`, `time_s_keluar`) VALUES
(36, '01/BPM.UMK/A.01.01/III/2020', '2020-03-18', 'Test PSI', '-', '01BPM.UMKA.01.01III2020.pdf', 17, 28, '2020-03-18 09:44:40'),
(37, '01/R.UMK/Sek/F.01.01/III/2020', '2020-03-18', 'Perihal Satu', '-', '01R.UMKSekF.01.01III2020.pdf', 32, 10, '2020-03-18 10:05:01'),
(38, '02/BPM.UMK/A.01.02/III/2020', '2020-03-26', 'Perihal Satu', '-', '02BPM.UMKA.01.02III2020.pdf', 17, 28, '2020-03-26 10:32:55'),
(39, '01/AK.UMK/KMH/A.01.01/III/2020', '2020-03-26', 'test', '-', '01AK.UMKKMHA.01.01III2020.pdf', 17, 13003, '2020-03-26 10:34:09'),
(51, '01/AK.UMK/AKA/A.01.01/IV/2020', '2020-04-19', 'Test to PSI', 'test', '01AK.UMKAKAA.01.01IV2020.pdf', 17, 13001, '2020-04-19 20:57:48'),
(58, '01/UPT.PSI.UMK/A.01.012/IV/2020', '2020-04-27', 'Perihal Satu', '-', '01UPT.PSI.UMKA.01.012IV2020.pdf', 17, 26, '2020-04-27 12:05:35'),
(60, '02/UPT.PSI.UMK/A.01.013/IV/2020', '2020-04-27', 'Perihal Satu', '-', '02UPT.PSI.UMKA.01.013IV2020.pdf', 17, 26, '2020-04-27 12:09:59'),
(61, '03/UPT.PSI.UMK/H.02.01/IV/2020', '2020-04-28', 'Test PSI', '-', '03UPT.PSI.UMKH.02.01IV2020.pdf', 269, 26, '2020-04-28 11:53:52'),
(62, '015/UPT.PSI.UMK/K.03.01/IV/2020', '2020-04-30', 'Studi Banding', 'Studi Banding Bandung\r\nPersonil : A, B, C', '015UPT.PSI.UMKK.03.01IV2020.pdf', 247, 26, '2020-04-30 09:22:35'),
(63, '015/UPT.PSI.UMK/D.15.01/III/2021', '2021-03-08', 'Tes PSI 2021', 'Pengajuan Barang', '015UPT.PSI.UMKD.15.01III2021.pdf', 160, 26, '2021-03-08 09:19:11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_masuk`
--

CREATE TABLE IF NOT EXISTS `surat_masuk` (
  `id_s_masuk` int(11) NOT NULL AUTO_INCREMENT,
  `no_s_masuk` varchar(100) NOT NULL,
  `perihal_s_masuk` text NOT NULL,
  `tgl_s_kirim` date NOT NULL,
  `tgl_s_terima` date NOT NULL,
  `scan_s_masuk` text NOT NULL,
  `id_unit` int(11) DEFAULT NULL,
  `pengirim_eks` varchar(50) NOT NULL,
  `id_kode` int(11) NOT NULL,
  `id_pimpinan` int(11) DEFAULT NULL,
  `id_penerima` int(11) DEFAULT NULL,
  `no_agenda` varchar(50) NOT NULL,
  `time_s_masuk` datetime NOT NULL,
  `surat_tugas` text NOT NULL,
  `status_s_masuk` enum('','0','1') NOT NULL,
  `info_rektor` text NOT NULL,
  `status_proses` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_s_masuk`),
  KEY `id_kode` (`id_kode`),
  KEY `id_unit` (`id_unit`),
  KEY `id_pegawai` (`id_pimpinan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data untuk tabel `surat_masuk`
--

INSERT INTO `surat_masuk` (`id_s_masuk`, `no_s_masuk`, `perihal_s_masuk`, `tgl_s_kirim`, `tgl_s_terima`, `scan_s_masuk`, `id_unit`, `pengirim_eks`, `id_kode`, `id_pimpinan`, `id_penerima`, `no_agenda`, `time_s_masuk`, `surat_tugas`, `status_s_masuk`, `info_rektor`, `status_proses`) VALUES
(22, '01/BPM.UMK/A.01.01/III/2020', 'Test PSI', '2020-03-18', '2020-03-18', '01BPM.UMKA.01.01III2020.pdf', 28, '', 17, 3, NULL, '', '0000-00-00 00:00:00', '', '0', 'Disposisi', '0'),
(23, '01/BPM.UMK/A.01.01/III/2020', 'Test PSI', '2020-03-18', '2020-03-18', '01BPM.UMKA.01.01III2020.pdf', 28, '', 17, 4, NULL, '', '0000-00-00 00:00:00', '', '', '', '0'),
(24, '01/BPM.UMK/A.01.01/III/2020', 'Test PSI', '2020-03-18', '2020-03-18', '01BPM.UMKA.01.01III2020.pdf', 28, '', 17, NULL, 26, '', '0000-00-00 00:00:00', '', '', '', '0'),
(25, '01/BPM.UMK/A.01.01/III/2020', 'Test PSI', '2020-03-18', '2020-03-18', '01BPM.UMKA.01.01III2020.pdf', 28, '', 17, NULL, 13001, '', '0000-00-00 00:00:00', '', '', '', '0'),
(26, '01/R.UMK/Sek/F.01.01/III/2020', 'Perihal Satu', '2020-03-18', '2020-03-18', '01R.UMKSekF.01.01III2020.pdf', 10, '', 32, NULL, 13001, '', '0000-00-00 00:00:00', '', '', '', '0'),
(27, '02/BPM.UMK/A.01.02/III/2020', 'Perihal Satu', '2020-03-26', '2020-03-26', '02BPM.UMKA.01.02III2020.pdf', 28, '', 17, NULL, 13, '', '0000-00-00 00:00:00', '', '', '', '0'),
(28, '02/BPM.UMK/A.01.02/III/2020', 'Perihal Satu', '2020-03-26', '2020-03-26', '02BPM.UMKA.01.02III2020.pdf', 28, '', 17, NULL, 26, '', '0000-00-00 00:00:00', '', '', '', '0'),
(29, '01/AK.UMK/KMH/A.01.01/III/2020', 'test', '2020-03-26', '2020-03-26', '01AK.UMKKMHA.01.01III2020.pdf', 13003, '', 17, NULL, 31, '', '0000-00-00 00:00:00', '', '', '', '0'),
(30, '01/AK.UMK/KMH/A.01.01/III/2020', 'test', '2020-03-26', '2020-03-26', '01AK.UMKKMHA.01.01III2020.pdf', 13003, '', 17, NULL, 26, '', '0000-00-00 00:00:00', '', '', '', '0'),
(31, '01/UPT.PSI.UMK/I.25.01/III/2020', 'Test', '2020-03-26', '2020-03-26', '01UPT.PSI.UMKI.25.01III2020.pdf', 26, '', 222, NULL, 14, '', '0000-00-00 00:00:00', '', '', '', '0'),
(32, '01/UPT.PSI.UMK/I.25.01/III/2020', 'Test', '2020-03-26', '2020-03-26', '01UPT.PSI.UMKI.25.01III2020.pdf', 26, '', 222, 3, NULL, '', '0000-00-00 00:00:00', '', '', '', '0'),
(33, '02/UPT.PSI.UMK/A.02.01/III/2020', 'gu', '2020-03-04', '2020-03-29', '02UPT.PSI.UMKA.02.01III2020.pdf', 26, '', 18, NULL, 41, '', '0000-00-00 00:00:00', '', '', '', '0'),
(34, '03/UPT.PSI.UMK/A.01.01/III/2020', 'Humasss', '2020-03-04', '2020-03-29', '03UPT.PSI.UMKA.01.01III2020.pdf', 26, '', 17, NULL, 41, '', '0000-00-00 00:00:00', '', '', '', '0'),
(35, '04/UPT.PSI.UMK/A.01.02/III/2020', 'Cekk Lagi', '2020-03-30', '2020-03-29', '04UPT.PSI.UMKA.01.02III2020.pdf', 26, '', 17, NULL, 41, '', '0000-00-00 00:00:00', '', '', '', '0'),
(36, 'Cek001', 'sdds', '2020-04-01', '2020-04-17', 'Cek001.pdf', 47, '', 18, NULL, 26, 'AGENDA1', '2020-04-01 18:25:05', '', '', '', '0'),
(37, 'Mbuh109', 'Cek Surat Keluar', '2020-04-07', '2020-04-22', 'Mbuh109.pdf', 26, '', 18, 3, NULL, 'AGENDA3', '2020-04-01 19:06:25', '', '0', '', '0'),
(38, '05/UPT.PSI.UMK/A.01.03/IV/2020', 'Coba Surat Keluar PSI', '2020-04-01', '2020-04-04', '05UPT.PSI.UMKA.01.03IV2020.pdf', 26, '', 17, NULL, 41, '', '0000-00-00 00:00:00', '', '', '', '0'),
(39, '06/UPT.PSI.UMK/A.01.04/IV/2020', 'Cek Kedua Kalinya', '2020-04-08', '2020-04-04', '06UPT.PSI.UMKA.01.04IV2020.pdf', 26, '', 17, NULL, 14, '', '0000-00-00 00:00:00', '', '', '', '0'),
(40, '07/UPT.PSI.UMK/A.03.01/IV/2020', 'Bantuan utk Luar Negeri', '2020-04-16', '2020-04-04', '07UPT.PSI.UMKA.03.01IV2020.pdf', 26, '', 19, NULL, 41, '', '0000-00-00 00:00:00', '', '', '', '0'),
(41, '08/UPT.PSI.UMK/A.01.05/IV/2020', 'Cek Rektor', '2020-04-07', '2020-04-04', '08UPT.PSI.UMKA.01.05IV2020.pdf', 26, '', 17, 4, NULL, '', '0000-00-00 00:00:00', '', '', '', '0'),
(42, '09/UPT.PSI.UMK/A.04.01/IV/2020', 'Terkait Beasiswa', '2020-04-04', '2020-04-04', '09UPT.PSI.UMKA.04.01IV2020.pdf', 26, '', 21, NULL, 46, '', '0000-00-00 00:00:00', '', '', '', '0'),
(43, '010/UPT.PSI.UMK/A.32.01/IV/2020', 'df', '2020-04-10', '2020-04-09', '010UPT.PSI.UMKA.32.01IV2020.pdf', 26, '', 64, 3, NULL, '', '0000-00-00 00:00:00', '', '1', 'Bisa Datang', '0'),
(44, '011/UPT.PSI.UMK/A.04.02/IV/2020', 'Beasiswa', '2020-04-01', '2020-04-14', '011UPT.PSI.UMKA.04.02IV2020.pdf', 26, '', 21, 6, NULL, '', '0000-00-00 00:00:00', '', '', '', '0'),
(45, '01/AK.UMK/AKA/A.01.01/IV/2020', 'Test to PSI', '2020-04-19', '2020-04-19', '01AK.UMKAKAA.01.01IV2020.pdf', 13001, '', 17, NULL, 26, '', '0000-00-00 00:00:00', '', '', '', '0'),
(46, '05/UPT.PSI.UMK/A.01.01/IV/2020', 'Cek PSI', '2020-04-26', '2020-04-26', '05UPT.PSI.UMKA.01.01IV2020.pdf', 26, '', 17, NULL, 13, '', '0000-00-00 00:00:00', '', '', '', '0'),
(47, '06/UPT.PSI.UMK/A.01.02/IV/2020', 'Perihal Satu', '2020-04-26', '2020-04-26', '06UPT.PSI.UMKA.01.02IV2020.pdf', 26, '', 17, NULL, 28, '', '0000-00-00 00:00:00', '', '', '', '0'),
(48, '01/UPT.PSI.UMK/A.01.03/IV/2020', 'Perihal Satu', '2020-04-26', '2020-04-26', '01UPT.PSI.UMKA.01.03IV2020.pdf', 26, '', 17, NULL, 28, '', '0000-00-00 00:00:00', '', '', '', '0'),
(49, '01/UPT.PSI.UMK/A.01.01/IV/2020', 'Perihal Satu', '2020-04-27', '2020-04-27', '01UPT.PSI.UMKA.01.01IV2020.pdf', 26, '', 17, NULL, 28, '', '0000-00-00 00:00:00', '', '', '', '0'),
(50, '02/UPT.PSI.UMK/A.01.02/IV/2020', 'Perihal Dua', '2020-04-27', '2020-04-27', '02UPT.PSI.UMKA.01.02IV2020.pdf', 26, '', 17, NULL, 46, '', '0000-00-00 00:00:00', '', '', '', '0'),
(51, '01/UPT.PSI.UMK/A.01.01/IV/2020', 'Perihal Satu', '2020-04-27', '2020-04-27', '01UPT.PSI.UMKA.01.01IV2020.pdf', 26, '', 17, NULL, 28, '', '0000-00-00 00:00:00', '', '', '', '0'),
(52, '01/UPT.PSI.UMK/A.01.012/IV/2020', 'Perihal Satu', '2020-04-27', '2020-04-27', '01UPT.PSI.UMKA.01.012IV2020.pdf', 26, '', 17, NULL, 13, '', '0000-00-00 00:00:00', '', '', '', '0'),
(53, '02/UPT.PSI.UMK/A.01.013/IV/2020', 'Perihal Satu', '2020-04-27', '2020-04-27', '02UPT.PSI.UMKA.01.013IV2020.pdf', 26, '', 17, NULL, 28, '', '0000-00-00 00:00:00', '', '', '', '0'),
(54, '02/UPT.PSI.UMK/A.01.013/IV/2020', 'Perihal Satu', '2020-04-27', '2020-04-27', '02UPT.PSI.UMKA.01.013IV2020.pdf', 26, '', 17, NULL, 28, '', '0000-00-00 00:00:00', '', '', '', '0'),
(55, '03/UPT.PSI.UMK/H.02.01/IV/2020', 'Test PSI', '2020-04-28', '2020-04-28', '03UPT.PSI.UMKH.02.01IV2020.pdf', 26, '', 269, 3, NULL, '', '0000-00-00 00:00:00', '', '0', 'Disposisi WR2', '0'),
(56, '015/UPT.PSI.UMK/K.03.01/IV/2020', 'Studi Banding', '2020-04-30', '2020-04-30', '015UPT.PSI.UMKK.03.01IV2020.pdf', 26, '', 247, 3, NULL, '', '0000-00-00 00:00:00', '', '0', 'Lanjutkan', '1'),
(57, '015/UPT.PSI.UMK/D.15.01/III/2021', 'Tes PSI 2021', '2021-03-08', '2021-03-08', '015UPT.PSI.UMKD.15.01III2021.pdf', 26, '', 160, 3, NULL, '', '0000-00-00 00:00:00', '', '', '', '0'),
(58, '123', 'Testing Coba 2021', '2021-03-07', '2021-03-08', '123.pdf', 999, 'PSI', 17, 3, NULL, '123', '2021-03-08 09:29:50', '', '', '', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_tugas`
--

CREATE TABLE IF NOT EXISTS `surat_tugas` (
  `id_s_tugas` int(11) NOT NULL AUTO_INCREMENT,
  `id_s_masuk` int(11) NOT NULL,
  `kd_s_tugas` varchar(150) NOT NULL,
  `keperluan` text NOT NULL,
  `hari` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `waktu` varchar(100) NOT NULL,
  `tempat` text NOT NULL,
  `keterangan` text NOT NULL,
  `ttd` int(11) NOT NULL,
  PRIMARY KEY (`id_s_tugas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `surat_tugas`
--

INSERT INTO `surat_tugas` (`id_s_tugas`, `id_s_masuk`, `kd_s_tugas`, `keperluan`, `hari`, `tanggal`, `waktu`, `tempat`, `keterangan`, `ttd`) VALUES
(1, 56, '011.AA', 'Keperluan', 'Sabtu', '31 April 2020', '09:00', 'Bandung', 'Studi banding ke Bandung', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tujuan_s_keluar`
--

CREATE TABLE IF NOT EXISTS `tujuan_s_keluar` (
  `id_tujuan` int(11) NOT NULL AUTO_INCREMENT,
  `id_unit` int(11) DEFAULT NULL,
  `id_s_keluar` int(11) NOT NULL,
  `jenis_unit` varchar(15) NOT NULL,
  `unit_eks` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tujuan`),
  KEY `id_s_keluar` (`id_s_keluar`),
  KEY `id_unit` (`id_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `id_unit` int(11) NOT NULL,
  `nama_unit` varchar(100) NOT NULL,
  `level` varchar(5) NOT NULL,
  `parent` varchar(5) NOT NULL,
  `login` enum('1','0') NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id_unit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `unit`
--

INSERT INTO `unit` (`id_unit`, `nama_unit`, `level`, `parent`, `login`, `email`) VALUES
(2, 'Fakultas Pertanian ', '1', '', '1', ''),
(6, 'Fakultas Ekonomi dan Bisnis', '1', '', '1', ''),
(9, 'Lemlit', '1', '', '1', ''),
(10, 'Sekretariat Rektor', '1', '', '1', ''),
(12, 'LPM', '1', '', '1', ''),
(13, 'BAAK', '1', '', '0', ''),
(14, 'BAU', '1', '', '0', ''),
(20, 'UPT Perpustakaan', '1', '', '1', ''),
(21, 'UPT Komputer', '1', '', '1', ''),
(23, 'UPT  Bahasa', '1', '', '1', ''),
(26, 'UPT PSI', '1', '', '1', ''),
(27, 'Fakultas Hukum', '1', '', '1', ''),
(28, 'BPM', '1', '', '1', ''),
(29, 'Fakultas Teknik', '1', '', '1', ''),
(30, 'FKIP', '1', '', '1', ''),
(31, 'Fakultas Psikologi', '1', '', '1', ''),
(32, 'Lemdik', '1', '', '1', ''),
(33, 'Yayasan Pembina UMK', '1', '', '1', ''),
(34, 'SATPAM', '1', '', '1', ''),
(39, 'UPT MKU-Ketrampilan', '1', '', '1', ''),
(40, 'Lembaga INFOKOM', '1', '', '1', ''),
(41, 'Humas', '1', '', '1', ''),
(44, 'Lembaga Penelitian dan Pengabdian pada Masyarakat', '1', '', '1', ''),
(45, 'Kantor Urusan Internasional', '1', '', '1', ''),
(46, 'Pusat Karir dan Pelacakan Alumni', '1', '', '1', ''),
(47, 'UPT. Keselamatan, Kesehatan Kerja dan Lingkungan (K3L)', '1', '', '1', ''),
(13001, 'Akademik', '2', '13', '1', ''),
(13002, 'Registrasi', '2', '13', '1', ''),
(13003, 'Kemahasiswaan', '2', '13', '1', ''),
(14001, 'Kepegawaian', '2', '14', '1', ''),
(14002, 'Umum', '2', '14', '1', ''),
(14003, 'Rumah Tangga', '2', '14', '1', ''),
(14004, 'Keuangan', '2', '14', '1', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_pimpinan` int(11) DEFAULT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` varchar(15) NOT NULL,
  `id_unit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `id_pimpinan`, `username`, `password`, `level`, `id_unit`) VALUES
(1, NULL, 'admin', 'admin', 'Admin', NULL),
(2, 3, 'rektor', 'rektor', 'Pimpinan', NULL),
(3, NULL, 'bau_admin', 'bau12345', 'BAU', NULL),
(4, NULL, 'baak_admin', 'baak12345', 'BAAK', NULL),
(5, NULL, 'psi', 'psi', 'Unit', 26),
(6, NULL, 'bau_umum', 'bau_umum', 'Unit', 14002),
(7, NULL, 'sek_rektor', 'sek_rektor', 'Unit', 10),
(8, NULL, 'baak_ak', 'baak_ak', 'Unit', 13001),
(9, NULL, 'bau_ku', 'bau_ku', 'Unit', 14004),
(10, 6, 'warek3', 'warek3', 'Pimpinan', NULL),
(11, 5, 'warek2', 'warek2', 'Pimpinan', NULL),
(12, 8, 'manjid', 'manjid', 'Pimpinan', NULL),
(13, 4, 'warek1', 'warek1', 'Pimpinan', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
