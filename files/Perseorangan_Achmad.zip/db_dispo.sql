-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Jan 2020 pada 05.15
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_dispo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `agenda`
--

CREATE TABLE `agenda` (
  `id_agenda` int(11) NOT NULL,
  `nama_agenda` varchar(50) NOT NULL,
  `jenis_acara` varchar(30) NOT NULL,
  `isi_agenda` text NOT NULL,
  `tgl_agenda` date NOT NULL,
  `jam_agenda` time NOT NULL,
  `file_agenda` text NOT NULL,
  `undangan` text NOT NULL,
  `waktu_agd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `agenda`
--

INSERT INTO `agenda` (`id_agenda`, `nama_agenda`, `jenis_acara`, `isi_agenda`, `tgl_agenda`, `jam_agenda`, `file_agenda`, `undangan`, `waktu_agd`) VALUES
(24, 'Undangan Dies Natalies UPGRIS', '', '<p>Undangan Dies Natalies UPGRIS 10 Juli 2019 Jam 10.00<br></p>', '2019-08-05', '21:15:00', '201553072_IMK.pdf', 'Rektor', '0000-00-00 00:00:00'),
(25, 'Undangan Gladi Bersih Wisuda Periode Oktober 2019', '', '<p>Undangan Gladi Bersih Wisuda Periode Oktober 2019<br></p><p>Tanggal 21 Agustus 2019</p><p>Auditorium UMK</p>', '2019-08-21', '10:00:00', 'Und Gladi Wisuda 2018.pdf', 'Rektor, Wakil Rektor 1, Wakil Rektor 2, Wakil Rektor 3, Wakil Rektor 4', '0000-00-00 00:00:00'),
(26, 'Undangan Rapat Senat', '', '<p>Rapat Senat Universitas</p>', '2019-08-20', '12:00:00', 'Undangan Senat.pdf', 'Rektor', '0000-00-00 00:00:00'),
(27, 'Undangan Rapat dengan YP UMK', '', '<p>Rapat</p>', '2019-08-20', '15:30:00', 'Und Rapat YP UMK.pdf', 'Rektor', '0000-00-00 00:00:00'),
(28, 'Coba', '', '<p>-Â Â Â Â </p>', '2019-08-26', '11:15:00', 'DOKUMEN KOSONG.pdf', 'Wakil Rektor 1, Wakil Rektor 2', '2019-08-26 11:06:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar_grup_e`
--

CREATE TABLE `daftar_grup_e` (
  `id_daftar_g_e` int(11) NOT NULL,
  `id_grup_e` int(11) NOT NULL,
  `id_pimpinan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `daftar_grup_e`
--

INSERT INTO `daftar_grup_e` (`id_daftar_g_e`, `id_grup_e`, `id_pimpinan`) VALUES
(4, 2, 3),
(5, 2, 4),
(6, 2, 5),
(7, 2, 6),
(8, 2, 7),
(9, 3, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dispo_s_masuk`
--

CREATE TABLE `dispo_s_masuk` (
  `id_dispo` int(11) NOT NULL,
  `id_s_masuk` int(11) NOT NULL,
  `id_pgw` int(11) NOT NULL,
  `informasi` text NOT NULL,
  `tgl_dispo` datetime NOT NULL,
  `pemberi` int(11) NOT NULL,
  `status` enum('0','1','2') NOT NULL,
  `info_pemberi_dispo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dispo_s_masuk`
--

INSERT INTO `dispo_s_masuk` (`id_dispo`, `id_s_masuk`, `id_pgw`, `informasi`, `tgl_dispo`, `pemberi`, `status`, `info_pemberi_dispo`) VALUES
(122, 7, 5, 'Coba', '2020-01-08 11:05:03', 1, '0', ''),
(124, 7, 8, 'Bs Mas', '2020-01-08 11:17:40', 1, '1', ''),
(126, 7, 10, 'Test', '2020-01-08 14:40:11', 5, '1', 'Ardi Bisa'),
(127, 7, 11, 'Test', '2020-01-08 14:40:13', 5, '1', ''),
(128, 7, 12, '', '2020-01-15 08:18:07', 5, '1', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `grup_email`
--

CREATE TABLE `grup_email` (
  `id_grup_e` int(11) NOT NULL,
  `nama_grup_e` varchar(30) NOT NULL,
  `status_grup_e` enum('Aktif','Tidak Aktif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `grup_email`
--

INSERT INTO `grup_email` (`id_grup_e`, `nama_grup_e`, `status_grup_e`) VALUES
(2, 'Grup Satu', 'Aktif'),
(3, 'Coba', 'Aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kode_surat`
--

CREATE TABLE `kode_surat` (
  `id_kode` int(11) NOT NULL,
  `kd_surat` varchar(5) NOT NULL,
  `nama_kode` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kode_surat`
--

INSERT INTO `kode_surat` (`id_kode`, `kd_surat`, `nama_kode`) VALUES
(3, 'A', 'Pendidikan dan Pengajaran'),
(4, 'B', 'Penelitian'),
(5, 'C', 'Pengabdian Masyarakat'),
(6, 'D', 'Organisasi'),
(7, 'F', 'Komunikasi'),
(9, 'G', 'Kepegawaian'),
(10, 'H', 'Keuangan'),
(11, 'I', 'Perbekalan'),
(12, 'J', 'Tata Usaha'),
(13, 'K', 'Hubungan Masyarakat'),
(14, 'L', 'Umum'),
(15, 'SK', 'Surat Keputusan Rektor'),
(16, 'E', 'Manajemen');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `jabatan` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tmpt_lahir` varchar(25) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jekel` enum('Pria','Wanita') NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pgw`
--

CREATE TABLE `pgw` (
  `id_pgw` bigint(20) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gelar_depan` varchar(10) NOT NULL,
  `gelar_belakang` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `jabatan_fungsional` varchar(100) NOT NULL,
  `jabatan_struktural` varchar(100) NOT NULL,
  `pangkat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pgw`
--

INSERT INTO `pgw` (`id_pgw`, `nip`, `nama`, `gelar_depan`, `gelar_belakang`, `email`, `jabatan_fungsional`, `jabatan_struktural`, `pangkat`) VALUES
(1, '0610701000001014', 'Suparnyo', 'Dr', 'SH, MS', 'd.suparnyo@yahoo.co.', 'Lektor Kepala', 'Rektor', 'IV/b'),
(2, '19661207199203100', 'Murtono', 'Dr. Drs.', 'M.Pd', 'murtono@umk.ac.id', 'Lektor Kepala', 'Wakil Rektor 1', 'IV/a'),
(3, '610702010101026', 'H. M. Zainuri', 'Dr. Drs.', 'MM.', '', 'Lektor', 'Wakil Rektor 2', 'III/d'),
(4, '610701000001138', 'Rochmad Winarso', '', 'ST., MT', 'boswin2001@gmail.com', 'Lektor', 'Wakil Rektor 3', 'III/d'),
(5, '0610701000001017', 'Subarkah', 'Dr.', 'SH, M.Hum', '', 'Lektor Kepala', 'Wakil Rektor 4', 'IV/a'),
(7, '0610702000002184', 'Abdul Ghofur', '', 'A.Md', '', 'Tenaga Laboran', 'Pelaksana', 'II/b'),
(8, '0610701000001303', 'Aditya Akbar Riadi', '', 'S.Kom., M.Kom', 'adit.zink@gmail.com', 'Asisten Ahli', '', 'III/b'),
(9, '0610701000001262', 'Fajar Nugraha', '', 'S.Kom, M.Kom.', 'fajar.nugraha@umk.ac', 'Asisten Ahli', 'Ka UPT PSI', 'III/b'),
(10, 'ardi_2018', 'Ardi Irfanto', '', 'S.Kom.', 'ardiirfanto@yahoo.co', '', '', ''),
(11, 'Higan_2018', 'Higan Nanda Ahyudiya', '', 'S.Kom.', 'higannahyudiya@gmail', '', '', ''),
(12, '0628017501', 'Anteng Widodo', '', 'ST, M.Kom', 'antengwidodo@si.umk.', 'Asisten Ahli', 'Dosen', 'III/b');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pimpinan`
--

CREATE TABLE `pimpinan` (
  `id_pimpinan` int(11) NOT NULL,
  `nip` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gelar_depan` varchar(10) NOT NULL,
  `gelar_belakang` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jabatan_fungsional` varchar(100) NOT NULL,
  `jabatan_struktural` varchar(100) NOT NULL,
  `pangkat` varchar(20) NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pimpinan`
--

INSERT INTO `pimpinan` (`id_pimpinan`, `nip`, `nama`, `gelar_depan`, `gelar_belakang`, `email`, `jabatan_fungsional`, `jabatan_struktural`, `pangkat`, `status`) VALUES
(3, '0610701000001014', 'Suparnyo', 'Dr', 'SH, MS', 'd.suparnyo@yahoo.co.id', 'Lektor Kepala', 'Rektor', 'IV/b', '1'),
(4, '19661207199203100', 'Murtono', 'Dr. Drs.', 'M.Pd', 'murtono@umk.ac.id', 'Lektor Kepala', 'Wakil Rektor 1', 'IV/a', '1'),
(5, '610702010101026', 'H. M. Zainuri', 'Dr. Drs.', 'MM.', '', 'Lektor', 'Wakil Rektor 2', 'III/d', '1'),
(6, '610701000001138', 'Rochmad Winarso', '', 'ST., MT', 'boswin2001@gmail.com', 'Lektor', 'Wakil Rektor 3', 'III/d', '1'),
(7, '0610701000001017 ', 'Subarkah', 'Dr.', 'SH, M.Hum', '', 'Lektor Kepala', 'Wakil Rektor 4', 'IV/a', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `set_notif`
--

CREATE TABLE `set_notif` (
  `id_s_notif` int(11) NOT NULL,
  `id_agenda` int(11) NOT NULL,
  `set_waktu` varchar(30) NOT NULL,
  `waktu_notif` time NOT NULL,
  `status_kirim` enum('Belum','Sudah') NOT NULL,
  `id_grup_e` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `set_notif`
--

INSERT INTO `set_notif` (`id_s_notif`, `id_agenda`, `set_waktu`, `waktu_notif`, `status_kirim`, `id_grup_e`) VALUES
(43, 24, '00:30:00', '20:45:00', 'Sudah', 3),
(44, 25, '00:30:00', '09:30:00', 'Sudah', 2),
(45, 26, '00:30:00', '11:30:00', 'Sudah', 3),
(47, 27, '00:30:00', '15:00:00', 'Sudah', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_bau`
--

CREATE TABLE `status_bau` (
  `id_s_bau` int(11) NOT NULL,
  `id_s_masuk` int(11) NOT NULL,
  `ket` text NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_keluar`
--

CREATE TABLE `surat_keluar` (
  `id_s_keluar` int(11) NOT NULL,
  `no_s_keluar` varchar(30) NOT NULL,
  `tgl_s_keluar` date NOT NULL,
  `perihal_s_keluar` text NOT NULL,
  `scan_s_keluar` text NOT NULL,
  `id_kode` int(11) NOT NULL,
  `time_s_keluar` datetime NOT NULL,
  `adm` enum('0','1') NOT NULL,
  `rektor` enum('0','1') NOT NULL,
  `wr1` enum('0','1') NOT NULL,
  `wr2` enum('0','1') NOT NULL,
  `wr3` enum('0','1') NOT NULL,
  `wr4` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_masuk`
--

CREATE TABLE `surat_masuk` (
  `id_s_masuk` int(11) NOT NULL,
  `no_s_masuk` varchar(30) NOT NULL,
  `perihal_s_masuk` text NOT NULL,
  `tgl_s_kirim` date NOT NULL,
  `tgl_s_terima` date NOT NULL,
  `scan_s_masuk` text NOT NULL,
  `id_unit` int(11) DEFAULT NULL,
  `pengirim_eks` varchar(50) NOT NULL,
  `id_kode` int(11) NOT NULL,
  `id_pimpinan` int(11) NOT NULL,
  `no_agenda` varchar(50) NOT NULL,
  `time_s_masuk` datetime NOT NULL,
  `surat_tugas` text NOT NULL,
  `status_s_masuk` enum('','0','1') NOT NULL,
  `info_rektor` text NOT NULL,
  `status_proses` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `surat_masuk`
--

INSERT INTO `surat_masuk` (`id_s_masuk`, `no_s_masuk`, `perihal_s_masuk`, `tgl_s_kirim`, `tgl_s_terima`, `scan_s_masuk`, `id_unit`, `pengirim_eks`, `id_kode`, `id_pimpinan`, `no_agenda`, `time_s_masuk`, `surat_tugas`, `status_s_masuk`, `info_rektor`, `status_proses`) VALUES
(7, 'No_0001', 'Pertamax', '2020-01-06', '2020-01-06', 'No_0001.pdf', 26, '', 3, 3, 'AGENDA1', '2020-01-06 15:04:55', '', '0', 'Test', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_tugas`
--

CREATE TABLE `surat_tugas` (
  `id_s_tugas` int(11) NOT NULL,
  `id_s_masuk` int(11) NOT NULL,
  `kd_s_tugas` varchar(150) NOT NULL,
  `keperluan` text NOT NULL,
  `hari` varchar(100) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `waktu` varchar(100) NOT NULL,
  `tempat` text NOT NULL,
  `keterangan` text NOT NULL,
  `ttd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tujuan_s_keluar`
--

CREATE TABLE `tujuan_s_keluar` (
  `id_tujuan` int(11) NOT NULL,
  `id_unit` int(11) DEFAULT NULL,
  `id_s_keluar` int(11) NOT NULL,
  `jenis_unit` varchar(15) NOT NULL,
  `unit_eks` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit`
--

CREATE TABLE `unit` (
  `id_unit` int(11) NOT NULL,
  `nama_unit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `unit`
--

INSERT INTO `unit` (`id_unit`, `nama_unit`) VALUES
(2, 'Fakultas Pertanian '),
(26, 'UPT PSI'),
(31, 'Fakultas Psikologi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `id_pimpinan` int(11) DEFAULT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `level` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `id_pimpinan`, `username`, `password`, `level`) VALUES
(1, NULL, 'admin', 'admin', 'Admin'),
(2, 3, 'rektor', 'rektor', 'Pimpinan'),
(3, NULL, 'bau', 'bau', 'BAU'),
(4, NULL, 'baak', 'baak', 'BAAK');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id_agenda`);

--
-- Indeks untuk tabel `daftar_grup_e`
--
ALTER TABLE `daftar_grup_e`
  ADD PRIMARY KEY (`id_daftar_g_e`),
  ADD KEY `id_grup_e` (`id_grup_e`),
  ADD KEY `id_pimpinan` (`id_pimpinan`);

--
-- Indeks untuk tabel `dispo_s_masuk`
--
ALTER TABLE `dispo_s_masuk`
  ADD PRIMARY KEY (`id_dispo`);

--
-- Indeks untuk tabel `grup_email`
--
ALTER TABLE `grup_email`
  ADD PRIMARY KEY (`id_grup_e`);

--
-- Indeks untuk tabel `kode_surat`
--
ALTER TABLE `kode_surat`
  ADD PRIMARY KEY (`id_kode`);

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indeks untuk tabel `pgw`
--
ALTER TABLE `pgw`
  ADD PRIMARY KEY (`id_pgw`);

--
-- Indeks untuk tabel `pimpinan`
--
ALTER TABLE `pimpinan`
  ADD PRIMARY KEY (`id_pimpinan`);

--
-- Indeks untuk tabel `set_notif`
--
ALTER TABLE `set_notif`
  ADD PRIMARY KEY (`id_s_notif`),
  ADD KEY `id_agenda` (`id_agenda`),
  ADD KEY `id_grup_e` (`id_grup_e`);

--
-- Indeks untuk tabel `status_bau`
--
ALTER TABLE `status_bau`
  ADD PRIMARY KEY (`id_s_bau`);

--
-- Indeks untuk tabel `surat_keluar`
--
ALTER TABLE `surat_keluar`
  ADD PRIMARY KEY (`id_s_keluar`),
  ADD KEY `id_kode` (`id_kode`);

--
-- Indeks untuk tabel `surat_masuk`
--
ALTER TABLE `surat_masuk`
  ADD PRIMARY KEY (`id_s_masuk`),
  ADD KEY `id_kode` (`id_kode`),
  ADD KEY `id_unit` (`id_unit`),
  ADD KEY `id_pegawai` (`id_pimpinan`);

--
-- Indeks untuk tabel `surat_tugas`
--
ALTER TABLE `surat_tugas`
  ADD PRIMARY KEY (`id_s_tugas`);

--
-- Indeks untuk tabel `tujuan_s_keluar`
--
ALTER TABLE `tujuan_s_keluar`
  ADD PRIMARY KEY (`id_tujuan`),
  ADD KEY `id_s_keluar` (`id_s_keluar`),
  ADD KEY `id_unit` (`id_unit`);

--
-- Indeks untuk tabel `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id_unit`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id_agenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `daftar_grup_e`
--
ALTER TABLE `daftar_grup_e`
  MODIFY `id_daftar_g_e` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `dispo_s_masuk`
--
ALTER TABLE `dispo_s_masuk`
  MODIFY `id_dispo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT untuk tabel `grup_email`
--
ALTER TABLE `grup_email`
  MODIFY `id_grup_e` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kode_surat`
--
ALTER TABLE `kode_surat`
  MODIFY `id_kode` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pgw`
--
ALTER TABLE `pgw`
  MODIFY `id_pgw` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `pimpinan`
--
ALTER TABLE `pimpinan`
  MODIFY `id_pimpinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `set_notif`
--
ALTER TABLE `set_notif`
  MODIFY `id_s_notif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT untuk tabel `status_bau`
--
ALTER TABLE `status_bau`
  MODIFY `id_s_bau` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `surat_keluar`
--
ALTER TABLE `surat_keluar`
  MODIFY `id_s_keluar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `surat_masuk`
--
ALTER TABLE `surat_masuk`
  MODIFY `id_s_masuk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `surat_tugas`
--
ALTER TABLE `surat_tugas`
  MODIFY `id_s_tugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tujuan_s_keluar`
--
ALTER TABLE `tujuan_s_keluar`
  MODIFY `id_tujuan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
