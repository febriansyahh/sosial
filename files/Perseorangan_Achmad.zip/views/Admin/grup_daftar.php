<header class="page-header">
	<h2>Grup Email</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Grup Email</span></li>
			<li><span>Daftar</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
			$dt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from grup_email where id_grup_e='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {
				$sql_insert = "INSERT INTO daftar_grup_e (id_grup_e,id_pimpinan) VALUES (
		              '".$_GET ['id']."',
		              '".$_POST ['cboPegawai']."')";
		        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

	        	if ($query_insert) {
	          		echo "<meta http-equiv='refresh' content='0; url=?v=grup_daftar&id=$_GET[id]'>";
	        	}
		    }

		    if (!$_GET['hapus']=="") { 

				$sql_hapus = "DELETE FROM daftar_grup_e WHERE id_daftar_g_e='".$_GET['hapus']."'";
				$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
				if ($query_hapus) {
			        echo "<meta http-equiv='refresh' content='0; url=?v=grup_daftar&id=$_GET[id]'>";
			    }
		  	}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Daftar Email</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<table class="table">
						<tbody>
							<tr class="gradeX">
								<td width="170"><b>Nama Grup</b></td>
								<td><?php echo $dt['nama_grup_e'] ?></td>
							</tr>
							<tr class="gradeX">
								<td width="170"><b>Status Grup</b></td>
								<td><?php echo $dt['status_grup_e'] ?></td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Pegawai: </label>
						<div class="col-sm-8">
							<select data-plugin-selectTwo class="form-control" name="cboPegawai" id="pgw" onchange="changeValue(this.value)">
								<option>*Pilih Pegawai</option>
								<?php
	                                $result  = mysqli_query($koneksi, "SELECT*from pimpinan where not exists(SELECT*from daftar_grup_e where daftar_grup_e.id_pimpinan=pimpinan.id_pimpinan and id_grup_e='$_GET[id]')") or die (mysqli_error());
	                                $jsArray = "var dtPgw = new Array();\n";
	                                while ($row = mysqli_fetch_array($result))
	                                {         
	                                    echo "<option value='$row[id_pimpinan]'>$row[nama_pimpinan] [NIP : $row[nip]]</option>";
	                                    $jsArray .= "dtPgw['" . $row['id_pimpinan']. "'] = {email:'" . addslashes($row['email']). "'};\n";
	                                }
	                            ?>
							</select>
							<small>*) Hanya memuat pegawai yang belum masuk ke daftar grup <b><?php echo $dt['nama_grup_e'] ?></b></small>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Email: </label>
						<div class="col-sm-4">
							<input type="text" class="form-control" id="email" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label"></label>
						<div class="col-sm-3">
							<button class="btn btn-success" type="submit" name="btnSimpan">Tambahkan</button>
						</div>
					</div><br>
					<table class="table table-bordered table-striped mb-none">
						<thead>
							<tr>
								<th width="32">No</th>
								<th>Pegawai</th>
								<th>Email</th>
								<th width="40"></th>
							</tr>
						</thead>
						<tbody>
							<?php
			                    $no=1;
			                    $query = mysqli_query($koneksi,"SELECT * from daftar_grup_e inner join pimpinan on pimpinan.id_pimpinan=daftar_grup_e.id_pimpinan where id_grup_e='$_GET[id]'");
			                    while($data = mysqli_fetch_array($query)){
			                ?>
							<tr class="gradeX">
								<td><center><?php echo $no ?>.</center></td>
								<td><?php echo $data['nama_pimpinan'] ?> [NIP: <?php echo $data['nip'] ?>]</td>
								<td><?php echo $data['email'] ?></td>
								<td>
									<a class="btn btn-sm btn-danger" title="Hapus" data-toggle='modal' data-target='#konfirmasi_hapus' data-href='?v=grup_daftar&hapus=<?php echo $data['id_daftar_g_e'] ?>&id=<?php echo $_GET['id'] ?>'><i class="fa fa-trash-o"></i></a>
								</td>
							</tr>
							<?php
								$no++;
								}
							?>
						</tbody>
					</table>
				</div>
				<footer class="panel-footer">
					<a href="?v=grup" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Daftar pegawai akan dihapus dari grup email.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script>
	<?php echo $jsArray ?>
    function changeValue(pgw){
        document.getElementById('email').value = dtPgw[pgw].email;
    }

    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>