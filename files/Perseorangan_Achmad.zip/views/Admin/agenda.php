<header class="page-header">
	<h2>Agenda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Daftar Agenda</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php

	if (!$_GET['id']=="") { 

		$sql_hapus = "DELETE FROM agenda WHERE id_agenda='".$_GET['id']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<div class='alert alert-primary'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<strong>Hapus Berhasil!</strong> Tunggu...
				  </div>";
	        echo "<meta http-equiv='refresh' content='1; url=?v=agenda'>";
	    }
  	}

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Daftar Agenda <a href="?v=agenda_tambah" class="btn btn-sm btn-success"><i class="fa fa-plus-square"></i> Tambah</a></h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>Nama Agenda</th>
					<th>Waktu</th>
					<th>Undangan</th>
					<th>Ditambahkan</th>
					<th width="150"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT * from agenda order by waktu_agd desc");
                    while($data = mysqli_fetch_array($query)){
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td><?php echo $data['nama_agenda'] ?></td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_agenda']));?> <?php echo $data['jam_agenda'] ?></td>
					<td><?php echo $data['undangan'] ?></td>
					<td><?php echo waktu_lalu($data['waktu_agd']) ?></td>
					<td>
						<a href="?v=agenda_detail&id=<?php echo $data['id_agenda'] ?>" class="btn btn-sm btn-default"><i class="fa fa-info"></i></a>
						<?php
							date_default_timezone_set('Asia/Jakarta');
							$agd=$data['tgl_agenda'].' '.$data['jam_agenda'];
							$now=date('Y-m-d H:i:s');
							if($agd >= $now){
						?>
						<a href="?v=agenda_ubah&id=<?php echo $data['id_agenda'] ?>" title="Ubah" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
						<?php
							}else{
						?>
						
						<?php
							}
						?>
						<a class="btn btn-sm btn-danger" data-toggle='modal' data-target='#konfirmasi_hapus' title="Hapus" data-href='?v=agenda&id=<?php echo $data['id_agenda'] ?>'><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>