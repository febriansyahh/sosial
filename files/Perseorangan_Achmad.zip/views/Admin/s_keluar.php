<header class="page-header">
	<h2>Arsip Surat Keluar</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Arsip Surat Keluar</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<section class="panel">
	<?php
        $query = mysqli_query($koneksi,"SELECT * from kode_surat where level='1' order by kd_surat asc");
        while($data = mysqli_fetch_array($query)){

        	// $cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_keluar where id_kode=$data[idkode] and adm='0' group by id_kode"));
        	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_keluar a inner join kode_surat b on b.id_kode=a.id_kode where parent='$data[id_kode]' group by parent"));
        	// var_dump("SELECT count(*) as cnt from surat_keluar a inner join kode_surat b on b.id_kode=a.id_kode where parent='$data[id_kode]' group by a.id_kode");
        	// var_dump($cek);
        	if($cek['cnt'] > 0){
        		$ttl=$cek['cnt'];
        		$label='<span class="label-label-success">Surat</span>';
        	}else{
        		$ttl='0';
        		$label='';
        	}
    ?>
	<div class="col-md-6 col-lg-6 col-xl-3">
		<section class="panel panel-featured-top panel-featured-primary">
			<div class="panel-body">
				<div class="widget-summary">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-primary">
							<?php echo $data['kd_surat'] ?>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo $data['nama_kode'] ?></h4>
							<div class="info">
								<strong class="amount"><?php echo $ttl ?></strong> <?php echo $label ?>
								<!-- <span class="text-primary">(14 unread)</span> -->
							</div>
						</div>
						<div class="summary-footer">
							<a href="?v=s_keluar_daftar&id=<?php echo $data['id_kode'] ?>" class="text-uppercase">Tampilkan Semua</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<?php
		}
	?>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>