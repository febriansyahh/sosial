<header class="page-header">
	<h2>Kode Surat</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Kode Surat</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from kode_surat where id_kode='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		      	$sql_update = "UPDATE kode_surat SET
		      		kd_surat='".$_POST['txtKode']."',
		      		nama_kode='".$_POST['txtNama']."'
		      		WHERE id_kode='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        if ($query_update) {
		          	echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Ubah Berhasil!</strong> Tunggu...
						</div>";
		          	echo "<meta http-equiv='refresh' content='1; url=?v=kode'>";
		        }
		    }

		    if (isset ($_POST ['btnTambah'])) {
				$sql_insert = "INSERT INTO kode_surat (kd_surat,nama_kode,level,parent) VALUES (
					  '".$_POST ['txtKode_sub']."',
					  '".$_POST ['txtNama_sub']."',
					  '2',
		              '".$_GET ['id']."')";
		        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

	        	if ($query_insert) {
	          		echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]&edt_sub=1#1');</script>";
	        	}
		    }

		    if (isset ($_POST ['btnUbah'])) {
				$sql_update = "UPDATE kode_surat SET
		      		kd_surat='".$_POST['txtKode_sub']."',
		      		nama_kode='".$_POST['txtNama_sub']."'
		      		WHERE id_kode='".$_GET['edit']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

	        	if ($query_update) {
	          		echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]&edt_sub=1#1');</script>";
	        	}
		    }

		    if (!$_GET['del']=="") { 

				$sql_hapus = "DELETE FROM kode_surat WHERE id_kode='".$_GET['del']."'";
				$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
				if ($query_hapus) {
			        echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]&edt_sub=1#1');</script>";
			    }
		  	}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Ubah Kode Surat <?php if($_GET['edt_sub']!=''){ ?><a href="?v=kode_ubah&id=<?php echo $_GET['id'] ?>" class="btn btn-primary">Edit</a><?php } ?></h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<?php 
						if($_GET['edt_sub']==''){
							$stts='required';
						}else{
							$stts='disabled';
						}
					?>
					<div class="form-group">
						<label class="col-sm-2 control-label">Kode Surat: </label>
						<div class="col-sm-2">
							<input type="text" class="form-control" value="<?php echo $data['kd_surat'] ?>" name="txtKode" <?php echo $stts ?>>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Kode Surat: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" value="<?php echo $data['nama_kode'] ?>" name="txtNama" <?php echo $stts ?>>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<?php if($_GET['edt_sub']==''){ ?>
						<button class="btn btn-success" type="submit" name="btnSimpan">Ubah </button>
					<?php } ?>
					<a href="?v=kode" class="btn btn-default">Kembali Halaman Kode</a>
				</footer>
			</section>

			<section class="panel" id='1'>
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Sub Kode Surat <?php if($_GET['edt_sub']==''){ ?><a href="?v=kode_ubah&id=<?php echo $_GET['id'] ?>&edt_sub=1#1" class="btn btn-primary">Edit</a><?php } ?></h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<?php
					if (!$_GET['edit']=="") {
						$nama=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from kode_surat where id_kode='$_GET[edit]'"));
						$val_kode=$nama['kd_surat'];
						$val_nama=$nama['nama_kode'];
					}else{
						$val_kode="";
						$val_nama="";
					}
				?>
				<div class="panel-body">
					<?php if (!$_GET['edt_sub']=="") { ?>
						<div class="col-sm-6">
							<div class="form-group">
								<label class="col-sm-3 control-label">Kode Sub: </label>
								<div class="col-sm-4">
									<input type="text" class="form-control" value="<?php echo $val_kode ?>" name="txtKode_sub" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label">Nama Sub: </label>
								<div class="col-sm-9">
									<input type="text" class="form-control" value="<?php echo $val_nama ?>" name="txtNama_sub" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label"></label>
								<div class="col-sm-9">
									<?php if ($_GET['edit']=="") { ?>
										<button class="btn btn-primary" type="submit" name="btnTambah">Tambah </button>
									<?php }else{ ?>
										<button class="btn btn-warning" type="submit" name="btnUbah">Ubah </button>
										<a href="?v=kode_ubah&id=<?php echo $_GET['id'] ?>&edt_sub=1#1" class="btn btn-default">Batal</a>
									<?php } ?>
								</div>
							</div>
						</div>
					<div class="col-sm-6">
					<?php }else{ ?>
					<div class="col-sm-12">
					<?php } ?>
						<table class="table table-bordered table-striped mb-none" id="datatable-default">
							<thead>
								<tr>
									<th width="32">No</th>
									<th>Kode</th>
									<th>Nama Kode</th>
									<?php if (!$_GET['edt_sub']=="") { ?>
										<th width="125"></th>
									<?php } ?>
								</tr>
							</thead>
							<tbody>
								<?php
				                    $no=1;
				                    $query = mysqli_query($koneksi,"SELECT * from kode_surat where parent='$_GET[id]' and level='2' order by kd_surat asc");
				                    // var_dump("SELECT * from kode_surat where parent='$_GET[id]' and level='2' order by kd_surat asc");
				                    while($dt = mysqli_fetch_array($query)){
				                ?>
				                <?php if($_GET['edit']==$dt['id_kode']){ ?>
									<tr class="gradeX" style="background-color: yellow;">
				                <?php }else{ ?>
				                	<tr class="gradeX">
				                <?php } ?>
									<td><center><?php echo $no ?>.</center></td>
									<td><?php echo $dt['kd_surat'] ?></td>
									<td><?php echo $dt['nama_kode'] ?></td>
									<?php if (!$_GET['edt_sub']=="") { ?>
										<td>
											<?php if($_GET['edit']==$dt['id_kode']){ ?>

											<?php }else{ ?>
												<a href="?v=kode_ubah&id=<?php echo $dt['parent'] ?>&edit=<?php echo $dt['id_kode'] ?>&edt_sub=1#1" title="Ubah" class="btn btn-xs btn-primary">Ubah</a>
												<a class="btn btn-xs btn-danger" data-toggle='modal' data-target='#konfirmasi_hapus' title="Hapus" data-href='?v=kode_ubah&id=<?php echo $dt['parent'] ?>&del=<?php echo $dt['id_kode'] ?>&edt_sub=1#1'>Hapus</a>
											<?php } ?>
										</td>
									<?php } ?>
								</tr>
								<?php
									$no++;
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</section>
		</form>
	</div>
</div>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>