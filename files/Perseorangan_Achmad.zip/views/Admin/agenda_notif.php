<header class="page-header">
	<h2>Notif Agenda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Notif Agenda</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php

	if (!$_GET['id']=="") { 

		$sql_hapus = "DELETE FROM set_notif WHERE id_s_notif='".$_GET['id']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<div class='alert alert-primary'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<strong>Hapus Berhasil!</strong> Tunggu...
				  </div>";
	        echo "<meta http-equiv='refresh' content='1; url=?v=agenda_notif'>";
	    }
  	}

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Notif Agenda <a href="?v=agenda_notif_tambah" class="btn btn-sm btn-success"><i class="fa fa-plus-square"></i> Tambah</a></h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>Nama Agenda</th>
					<th>Waktu Agenda</th>
					<th>Set Waktu Notif</th>
					<th>Status</th>
					<th width="135"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT id_s_notif,nama_agenda,status_kirim,tgl_agenda,jam_agenda,set_waktu,SUBTIME(jam_agenda,set_waktu) as jam_notif from set_notif inner join agenda on agenda.id_agenda=set_notif.id_agenda order by status_kirim,tgl_agenda,jam_agenda asc");
                    while($data = mysqli_fetch_array($query)){
                    	if($data['set_waktu']=='00:30:00'){
                    		$notif='30 menit';
                    	}elseif($data['set_waktu']=='1:00:00'){
                    		$notif='1 jam';
                    	}elseif($data['set_waktu']=='6:00:00'){
                    		$notif='6 jam';
                    	}elseif($data['set_waktu']=='12:00:00'){
                    		$notif='12 jam';
                    	}
                    	$jam
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td><?php echo $data['nama_agenda'] ?></td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_agenda']));?> <?php echo $data['jam_agenda'] ?></td>
					<td><?php echo $notif ?> sebelum waktu agenda (<b><?php echo substr($data['jam_notif'],0,5) ?></b>)</td>
					<td><?php echo $data['status_kirim'] ?></td>
					<td>
						<a href="?v=agenda_notif_detail&id=<?php echo $data['id_s_notif'] ?>" class="btn btn-sm btn-default"><i class="fa fa-info"></i></a>
						<?php
							if($data['status_kirim']=="Belum"){
						?>
						<a href="?v=agenda_notif_ubah&id=<?php echo $data['id_s_notif'] ?>" title="Ubah" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
						<?php
							}
						?>
						<a class="btn btn-sm btn-danger" data-toggle='modal' data-target='#konfirmasi_hapus' title="Hapus" data-href='?v=agenda_notif&id=<?php echo $data['id_s_notif'] ?>'><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>