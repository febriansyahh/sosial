<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Proses</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			require '../../PHPMailer/PHPMailerAutoload.php';
			$mail = new PHPMailer;

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM surat_masuk sm 
				INNER JOIN pimpinan p ON sm.id_pimpinan = p.id_pimpinan 
				INNER JOIN unit u ON sm.id_unit = u.id_unit where sm.id_s_masuk='$_GET[kd]'"));	
			$pimpinan = $data['gelar_depan'].".".$data['nama'].", ".$data['gelar_belakang'];		
			$surat=$data['scan_s_masuk'];
			$suratTugas=$data['surat_tugas'];
			$idsurat=$data['id_s_masuk'];

			$rowdispo = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk WHERE id_s_masuk = '$_GET[kd]' "));

			if(isset($_GET['del'])){
				$id = $_GET['del'];
				$pemberi = $_GET['pemberi'];

				if($pemberi == '1'){
					$updSMasuk = mysqli_query($koneksi,"UPDATE surat_masuk SET status_s_masuk ='', info_rektor ='' WHERE id_s_masuk ='$id' ");
				}
				$delQuery = mysqli_query($koneksi,"DELETE FROM dispo_s_masuk WHERE id_s_masuk='$id' AND pemberi ='$pemberi'");
				if ($delQuery) {
					echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Hapus Berhasil!</strong> Tunggu...
							</div>";
					echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_proses&kd=$id'>";
				}
			}

			if(isset($_GET['proses'])){
				$id = $_GET['kd'];
				
				$statusQuery = mysqli_query($koneksi,"UPDATE surat_masuk SET status_proses='1' WHERE id_s_masuk='$id'");
				if ($statusQuery) {
					echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Perubahan Status Berhasil!</strong> Tunggu...
							</div>";
					echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_proses&kd=$id'>";
				}
			}

		
		?>

		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Proses Surat Masuk</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">

					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i>
									Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
							<!-- <li>
								<a href="#recent11" data-toggle="tab" class="text-center">Surat Tugas</a>
							</li> -->
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Pengirim</b></td>
											<?php if($data['nama_unit']=='Lainnya'){ ?>
											<td><?php echo $data['pengirim_eks'] ?></td>
											<?php }else{ ?>
											<td><?php echo $data['nama_unit'] ?></td>
											<?php } ?>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Terima</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Ditujukan Kepada</b></td>
											<td><?php echo $pimpinan;?> [<?php echo $data['nip'];?>]</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>No Agenda</b></td>
											<td><?php echo $data['no_agenda'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170" colspan="2" style="font-size: 15px; color:red;">
												<b>DISPOSISI SURAT : </b> <a href="?v=s_masuk_dispo_tambah&kd=<?php echo $_GET['kd']?>" class="btn btn-success btn-sm" <?php if($data['status_proses']=='1'){echo"disabled";} ?> >Tambah Disposisi</a></td>
										</tr>
										<tr class="gradeX">
											<td colspan="2">
												<div class="panel-group" id="accordionPrimary">
													<?php 
														if($rowdispo > 0){
															$qdispo = mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk WHERE id_s_masuk = '$_GET[kd]' GROUP BY pemberi ");
															while ($datadispo = mysqli_fetch_array($qdispo)) {
																$getpemberi=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM pgw WHERE id_pgw ='$datadispo[pemberi]'"));
														?>
													<div class="panel panel-accordion panel-accordion-primary">
														<div class="panel-heading">
															<h4 class="panel-title">
																<a class="accordion-toggle" data-toggle="collapse"
																	data-parent="#accordionPrimary"
																	href="#<?php echo $datadispo['id_dispo'] ?>">
																	<?php echo $getpemberi['gelar_depan']." ".$getpemberi['nama'].",".$getpemberi['gelar_belakang'] ?>
																</a>
															</h4>
														</div>
														<div id="<?php echo $datadispo['id_dispo'] ?>"
															class="accordion-body collapse">
															<div class="panel-body">
																Disposisi Ke:
																<ul>
																	<?php
																		$qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk 
																		inner join pgw on pgw.id_pgw=dispo_s_masuk.id_pgw
																		where id_s_masuk='$data[id_s_masuk]' and pemberi = '$datadispo[pemberi]' ");
																		while($dta = mysqli_fetch_array($qr)){
																			$st = '';
																			if($dta['status']=='1'){
																				$st = 'Bisa';
																			} else if($dta['status']=='0'){
																				$st='Tidak Bisa';
																			} else {
																				$st='Belum Konfirmasi';
																			}
										                			?>
																	<li>
																		<b><?php echo $dta['gelar_depan']." ".$dta['nama'].",".$dta['gelar_belakang'] ?> </b>
																		(<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>) - <?php echo $st ?>
																	</li>
																	<p> - Instruksi/Informasi :  <?php echo $dta['informasi'] ?></p>
																	<?php
																		}
																	?>
																</ul>
																<!-- <hr>
																Informasi/Intruksi:
																<p><b><?php echo $datadispo['informasi'] ?></b></p> -->
																<hr>
																<a href="?v=s_masuk_dispo_ubah&kd=<?php echo $datadispo['id_s_masuk'] ?>&pemberi=<?php echo $datadispo['pemberi'] ?>&idpgw=<?php echo $datadispo['id_pgw'] ?>" class="btn btn-primary" style="float:left" <?php if($data['status_proses']=='1'){echo"disabled";} ?> >Ubah Disposisi</a>
																<a href="?v=s_masuk_proses&del=<?php echo $datadispo['id_s_masuk'] ?>&pemberi=<?php echo $datadispo['pemberi'] ?>" onclick="return confirm('Anda Yakin ingin Menghapus?')" class="btn btn-danger" style="float:right" <?php if($data['status_proses']=='1'){echo"disabled";} ?>>Hapus Disposisi</a>
															</div>
														</div>
													</div>
													<?php 
															}
														} else {
															if($data['status_s_masuk'] == '0' ){
																echo "<b>" .$pimpinan. "</b> Mendisposisi";
														?>
														<?php
															} else if($data['status_s_masuk'] == '1' ) {
																echo "<b>" .$pimpinan. "</b> Bisa Menghadiri";
															} else {
																echo "<b>" .$pimpinan. "</b> Belum Memberi Putusan";
															}
														}
													?>
												</div>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
							<!-- <div id="recent11" class="tab-pane">
								<div id="example2"></div>
							</div> -->
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<a href="?v=s_masuk_daftar&id=<?php echo $data['id_kode'] ?>" class="btn btn-default">Kembali</a>
					<?php 
						if($data['status_proses']=='1'){
					?>
					<h5 style="float:right;color:crimson" ><b>Sudah Dikonfirmasi</b></h5>
					<?php
						} else {
					?>
					<a href="?v=s_masuk_proses&kd=<?php echo $_GET['kd'] ?>&proses=1" class="btn btn-success" style="float:right">Konfirmasi</a>
					<?php 
						}
					?>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>
	PDFObject.embed("../../File/SuratMasuk/<?php echo $surat ?>#toolbar=0", "#example1");
</script>
<!-- <script>PDFObject.embed("../../File/Surat Tugas/<?php echo $suratTugas ?>#toolbar=1", "#example2");</script> -->

<style>
	.pdfobject-container {
		height: 90rem;
		border: 0.4rem solid rgba(0, 0, 0, .1);
	}
</style>

<script>
	function hanyaAngka(evt) {
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))

			return false;
		return true;
	}

	function yesnoCheck() {
		if (document.getElementById('radioExample2').checked) {
			document.getElementById('disposisi').style.display = 'block';
			document.getElementById('listdispo').style.display = 'block';
		} else if (document.getElementById('radioExample1').checked) {
			document.getElementById('disposisi').style.display = 'none';
			document.getElementById('listdispo').style.display = 'none';
		}
	}
</script>