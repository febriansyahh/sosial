<header class="page-header">
	<h2>Pegawai</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Pegawai</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
		    if (isset ($_POST ['btnSimpan'])) {

		      	$cek=mysqli_num_rows(mysqli_query($koneksi,"SELECT*from pegawai where nip='$_POST[txtNIP]'"));
		      	$cekemail=mysqli_num_rows(mysqli_query($koneksi,"SELECT*from pegawai where email='$_POST[txtEmail]'"));
		      	if($cek>0){
		      		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Pegawai dengan NIP <strong>$_POST[txtNIP]</strong> sudah dimasukkan.
					 	  </div>";
				}elseif($cekemail>0){
		      		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Email <strong>$_POST[txtEmail]</strong> sudah dimasukkan.
					 	  </div>";
				}else{
					$sql_insert = "INSERT INTO pegawai (nip,nama_pegawai,jabatan,email,tmpt_lahir,tgl_lahir,jekel,alamat,no_telp) VALUES (
			              '".$_POST ['txtNIP']."',
			              '".$_POST ['txtNama']."',
			              '".$_POST ['cboJabatan']."',
			              '".$_POST ['txtEmail']."',
			              '".$_POST ['txtTempat']."',
			              '".date("Y/m/d", strtotime($_POST['txtTgl']))."',
			              '".$_POST ['rbJekel']."',
			              '".$_POST ['taAlamat']."',
			              '".$_POST ['txtTelp']."')";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

		        	if ($query_insert) {
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='1; url=?v=pegawai'>";
		        	}
		      	}
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Pegawai</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">NIP </label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="txtNIP" onkeypress="return hanyaAngka(event)" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Pegawai: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Jabatan: </label>
						<div class="col-sm-3">
							<select data-plugin-selectTwo class="form-control" name="cboJabatan" required>
								<?php
									$cekrektor=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from pegawai where jabatan='Rektor'"));
									$cekwr=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from pegawai where jabatan='Wakil Rektor'"));
								?>
								<option>*Pilih Jabatan</option>
								<?php if($cekrektor < 1){ ?>
									<option value="Rektor" disabled>Rektor</option>
								<?php } ?>
								<?php if($cekwr < 4){ ?>
								<option value="Wakil Rektor">Wakil Rektor</option>
								<?php } ?>
								<option value="Staff">Staff</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Email: </label>
						<div class="col-sm-4">
							<input type="email" class="form-control" name="txtEmail" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">TTL: </label>
						<div class="col-sm-3">
							<input type="text" name="txtTempat" class="form-control">
						</div>
						<div class="col-sm-2">
							<input type="text" name="txtTgl" data-plugin-datepicker class="form-control" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Telp: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" name="txtTelp" onkeypress="return hanyaAngka(event)" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Alamat: </label>
						<div class="col-sm-5">
							<textarea class="form-control" name="taAlamat" rows="5"></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Jekel: </label>
						<div class="col-sm-3">
							<div class="radio-custom radio-primary">
								<input type="radio" id="radioExample2" name="rbJekel" value="Pria">
								<label for="radioExample2">Pria</label>
							</div>
							<div class="radio-custom radio-primary">
								<input type="radio" id="radioExample2" name="rbJekel" value="Wanita">
								<label for="radioExample2">Wanita</label>
							</div>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=pegawai" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>