<header class="page-header">
	<h2>Daftar Unit</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Unit</span></li>
			<li><span>Daftar</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
			$dt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from unit where id_unit='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {
				$sql_insert = "INSERT INTO unit (nama_unit,tipe,parent,id_pegawai) VALUES (
		              '".$_POST ['txtNama']."',
		              '1',
		              '".$_GET ['id']."',
		              '".$_POST ['cboPegawai']."')";
		        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

	        	if ($query_insert) {
	          		// echo "<meta http-equiv='refresh' content='0; url=?v=unit_daftar&id=$_GET[id]'>";
	          		echo "<script>window.location.replace('?v=unit_daftar&id=$_GET[id]');</script>";
	        	}
		    }

		    if (!$_GET['hapus']=="") { 

				$sql_hapus = "DELETE FROM unit WHERE id_unit='".$_GET['hapus']."'";
				$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
				if ($query_hapus) {
			        // echo "<meta http-equiv='refresh' content='0; url=?v=unit_daftar&id=$_GET[id]'>";
			        echo "<script>window.location.replace('?v=unit_daftar&id=$_GET[id]');</script>";
			    }
		  	}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Daftar Unit</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<table class="table">
						<tbody>
							<tr class="gradeX">
								<td width="170"><b>Nama Unit</b></td>
								<td><?php echo $dt['nama_unit'] ?></td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Pegawai: </label>
						<div class="col-sm-8">
							<select data-plugin-selectTwo class="form-control" name="cboPegawai">
								<option>*Pilih pegawai</option>
								<?php
	                                $query  = mysqli_query($koneksi, "SELECT*from pegawai where not exists(SELECT*from unit where unit.id_pegawai=pegawai.id_pegawai and parent='$_GET[id]')") or die (mysqli_error());
	                                while ($data = mysqli_fetch_array($query))
	                                {         
	                                    echo "<option value='$data[id_pegawai]'>$data[nama_pegawai] [NIP : $data[nip]]</option>";
	                                }
	                            ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label"></label>
						<div class="col-sm-3">
							<button class="btn btn-success" type="submit" name="btnSimpan">Tambahkan</button>
						</div>
					</div><br>
					<table class="table table-bordered table-striped mb-none" id="datatable-default">
						<thead>
							<tr>
								<th width="32">No</th>
								<th>NIP</th>
								<th>Pegawai</th>
								<th width="40"></th>
							</tr>
						</thead>
						<tbody>
							<?php
			                    $no=1;
			                    $query = mysqli_query($koneksi,"SELECT * from unit inner join pegawai on pegawai.id_pegawai=unit.id_pegawai where parent='$_GET[id]' and tipe='1'");
			                    while($data = mysqli_fetch_array($query)){
			                ?>
							<tr class="gradeX">
								<td><center><?php echo $no ?>.</center></td>
								<td><?php echo $data['nip'] ?></td>
								<td><?php echo $data['nama_pegawai'] ?></td>
								<td>
									<a class="btn btn-sm btn-danger" title="Hapus" data-toggle='modal' data-target='#konfirmasi_hapus' data-href='?v=unit_daftar&hapus=<?php echo $data['id_unit'] ?>&id=<?php echo $_GET['id'] ?>'><i class="fa fa-trash-o"></i></a>
								</td>
							</tr>
							<?php
								$no++;
								}
							?>
						</tbody>
					</table>
				</div>
				<footer class="panel-footer">
					<a href="?v=unit" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Daftar pegawai akan dihapus dari unit.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script>
	<?php echo $jsArray ?>
    function changeValue(pgw){
        document.getElementById('email').value = dtPgw[pgw].email;
    }

    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>