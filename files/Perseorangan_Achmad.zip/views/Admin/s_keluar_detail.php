<header class="page-header">
	<h2>Surat Keluar</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Keluar</span></li>
			<li><span>Detail</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar inner join kode_surat on kode_surat.id_kode=surat_keluar.id_kode where surat_keluar.id_s_keluar='$_GET[kd]'"));
			$surat=$data['scan_s_keluar'];

			if (!$_GET['kd']=="") {
				if($data['adm']=='0'){
					$sql_update = "UPDATE surat_keluar SET
		      		adm='1'
		      		WHERE id_s_keluar='".$_GET['kd']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
				}
			}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Detail Surat Keluar</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					
					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i> Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_keluar'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nama Sub Kode</b></td>
											<td><?php echo $data['nama_kode'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_keluar']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_keluar'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Keterangan</b></td>
											<td><?php echo $data['ket_s_keluar'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Unit Dituju</b></td>
											<td>
												<ul>
													<?php
														$qr = mysqli_query($koneksi,"SELECT * from surat_masuk where no_s_masuk='$data[no_s_keluar]'");
									                    while($dt = mysqli_fetch_array($qr)){
															if($dt['id_penerima']!=null){
																$getUnit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.id_unit='$dt[id_penerima]'"));
																if($getUnit['nama2']!=null){
																	$penerima=$getUnit['nama2'].' '.$getUnit['nama1'];
																}else{
																	$penerima=$getUnit['nama1'];
																}
															}else{
																$getPimpinan=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pimpinan where id_pimpinan='$dt[id_pimpinan]'"));
																$penerima=$getPimpinan['jabatan_struktural'];
															}
									                ?>
													<li><?php echo $penerima ?></li>
													<?php
														}
													?>
												</ul>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<a href="?v=s_keluar_daftar&id=<?php echo $data['id_kode'] ?>" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>PDFObject.embed("../../File/SuratKeluar/<?php echo $surat ?>#toolbar=1", "#example1");</script>

<style>
.pdfobject-container { height: 90rem; border: 0.4rem solid rgba(0,0,0,.1); }
</style>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>