<header class="page-header">
	<h2>Grup Email</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Grup Email</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from grup_email where id_grup_e='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {
				$sql_update = "UPDATE grup_email SET
		      		nama_grup_e='".$_POST['txtNama']."',
		      		status_grup_e='".$_POST['cboStatus']."'
		      		WHERE id_grup_e='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

	        	if ($query_update) {
	        		echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Berhasil!</strong> Tunggu...
						  </div>";
	          		echo "<meta http-equiv='refresh' content='1; url=?v=grup'>";
	        	}
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Ubah Grup Email</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Grup: </label>
						<div class="col-sm-8">
							<input type="text" value="<?php echo $data['nama_grup_e'] ?>" class="form-control" name="txtNama" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Status Grup: </label>
						<div class="col-sm-3">
							<select data-plugin-selectTwo class="form-control" name="cboStatus" required>
								<option value="Aktif" <?php if($data['status_grup_e']=="Aktif") {echo "SELECTED";} ?>>Aktif</option>
								<option value="Tidak Aktif" <?php if($data['status_grup_e']=="Tidak Aktif") {echo "SELECTED";} ?>>Tidak Aktif</option>
							</select>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Ubah </button>
					<a href="?v=grup" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>