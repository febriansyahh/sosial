<header class="page-header">
	<h2>Pegawai</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Pegawai</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pegawai where id_pegawai='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		      	$sql_update = "UPDATE pegawai SET
		      		nama_pegawai='".$_POST['txtNama']."',
		      		jabatan='".$_POST['cboJabatan']."',
		      		email='".$_POST['txtEmail']."',
		      		tmpt_lahir='".$_POST['txtTempat']."',
		      		tgl_lahir='".date("Y/m/d", strtotime($_POST['txtTgl']))."',
		      		jekel='".$_POST['rbJekel']."',
		      		alamat='".$_POST['taAlamat']."',
		      		no_telp='".$_POST['txtTelp']."'
		      		WHERE id_pegawai='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        if ($query_update) {
		          	echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Ubah Berhasil!</strong> Tunggu...
						</div>";
		          	echo "<meta http-equiv='refresh' content='1; url=?v=pegawai'>";
		        }
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Pegawai</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">NIP </label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="txtNIP" value="<?php echo $data['nip'] ?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Pegawai: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" value="<?php echo $data['nama_pegawai'] ?>" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Jabatan: </label>
						<div class="col-sm-3">
							<select data-plugin-selectTwo class="form-control" name="cboJabatan" required>
								<option <?php if($data['jabatan']==''){ echo "SELECTED";} ?>>*Pilih Jabatan</option>
								<option value="Rektor" <?php if($data['jabatan']=='Rektor'){ echo "SELECTED";} ?>>Rektor</option>
								<option value="Wakil Rektor" <?php if($data['jabatan']=='Wakil Rektor'){ echo "SELECTED";} ?>>Wakil Rektor</option>
								<option value="Staff" <?php if($data['jabatan']=='Staff'){ echo "SELECTED";} ?>>Staff</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Email: </label>
						<div class="col-sm-4">
							<input type="email" class="form-control" name="txtEmail" value="<?php echo $data['email'] ?>" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">TTL: </label>
						<div class="col-sm-3">
							<input type="text" name="txtTempat" value="<?php echo $data['tmpt_lahir'] ?>" class="form-control">
						</div>
						<div class="col-sm-2">
							<input type="text" name="txtTgl" value="<?php echo date("d/m/Y", strtotime($data['tgl_lahir']));?>" data-plugin-datepicker class="form-control" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Telp: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" value="<?php echo $data['no_telp'] ?>" name="txtTelp" onkeypress="return hanyaAngka(event)" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Alamat: </label>
						<div class="col-sm-5">
							<textarea class="form-control" name="taAlamat" rows="5"><?php echo $data['alamat'] ?></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Jekel: </label>
						<div class="col-sm-3">
							<div class="radio-custom radio-primary">
								<input type="radio" id="radioExample2" name="rbJekel" value="Pria" <?php if($data['jekel']=='Pria'){ echo "checked";} ?>>
								<label for="radioExample2">Pria</label>
							</div>
							<div class="radio-custom radio-primary">
								<input type="radio" id="radioExample2" name="rbJekel" value="Wanita" <?php if($data['jekel']=='Wanita'){ echo "checked";} ?>>
								<label for="radioExample2">Wanita</label>
							</div>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Ubah </button>
					<a href="?v=pegawai" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>