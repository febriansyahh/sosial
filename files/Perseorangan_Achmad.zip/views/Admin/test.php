<?php
    
    $koneksi = mysqli_connect("localhost","root","","att");
    // $idd=$_GET['id'];
    $p=mysqli_query($koneksi,"SELECT * from set_notif where status_kirim='Belum'");
    $pgw=mysqli_fetch_array($p);
    $pgw2=mysqli_num_rows($p);
    
    // if($pgw2>0){
    //     $sql_update = "UPDATE set_notif SET
    //         status_kirim='Sudah'
    //         WHERE id_s_notif='".$pgw['id_s_notif']."'";
    //     $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
    // }else{

    // }

    if($pgw2>0){
        $cekwaktu=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * from set_notif inner join agenda on agenda.id_agenda=set_notif.id_agenda where status_kirim='Belum'"));
        // WAktu Agenda
        $waktu=$cekwaktu['tgl_agenda'].' '.$cekwaktu['jam_agenda'];

        if($cekwaktu['set_waktu']=='30 menit'){
            $add='+30 minutes';
        }elseif($cekwaktu['set_waktu']=='1 jam'){
            $add='+1 hours';
        }elseif($cekwaktu['set_waktu']=='6 jam'){
            $add='+6 hours';
        }elseif($cekwaktu['set_waktu']=='12 jam'){
            $add='+12 hours';
        }

        date_default_timezone_set('Asia/Jakarta');
        $waktudevice=date('Y-m-d H:i:s', strtotime($add));

        // if($waktu==$waktudevice || $waktu <= $waktudevice){
            $sql_update = "UPDATE set_notif SET
                status_kirim='Sudah'
                WHERE id_s_notif='".$pgw['id_s_notif']."'";
            $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

            require '../../PHPMailer/PHPMailerAutoload.php';

            //Create a new PHPMailer instance
            $mail = new PHPMailer;

            //Tell PHPMailer to use SMTP
            $mail->isSMTP();

            $mail->Host = 'smtp.gmail.com';
            
            $mail->Port = 587;

            $mail->SMTPSecure = 'tls';

            $mail->SMTPAuth = true;

            $mail->Username = "streamcool15@gmail.com";

            $mail->Password = "higannanda";

            $data = array();
            $sql = mysqli_query($koneksi,"SELECT*from set_notif inner join grup_email on grup_email.id_grup_e=set_notif.id_grup_e inner join daftar_grup_e on daftar_grup_e.id_grup_e=grup_email.id_grup_e inner join pimpinan on pimpinan.id_pimpinan=daftar_grup_e.id_pimpinan where id_s_notif='3'"); //query untuk mendapatkan semua data mahasiswa

            while ($r = mysqli_fetch_array($sql)){ // data akan di ulang
                $data[]=$r['email'];
            }

            $implode = implode(",",$data);
            $process = explode(",",$implode);
            // $thn="'".$implode."'";
            // print_r($process);exit();
            reset($process);

            foreach ($process as $to) {

            //Set who the message is to be sent from
            $mail->setFrom('from@example.com', 'Admin Sekretariat UMK');

            //Set an alternative reply-to address
            $mail->addReplyTo('replyto@example.com', 'Admin Sekretariat UMK');

            //Set who the message is to be sent to
            $mail->addAddress($to);

            $get = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * from set_notif inner join agenda on agenda.id_agenda=set_notif.id_agenda where id_s_notif='3'"));

            //Set the subject line
            $mail->Subject = $get['nama_agenda'];
            // $mail_body = 'Isi body'


            // $sent=mail($to,$mail_subject,$mail_body, "From: youremail@domain.com");

            $mail->Body = $get['isi_agenda'];
            //Read an HTML message body from an external file, convert referenced images to embedded,
            //convert HTML into a basic plain-text alternative body
            // $mail->msgHTML(file_get_contents('PHPMailer/examples/contents.html'), dirname(__FILE__));

            //Replace the plain text body with one created manually
            $mail->AltBody = 'This is a plain-text message body';

            //Attach an image file
            // $mail->addAttachment('PHPMailer/examples/images/phpmailer_mini.png');

            }
        // }else{

        // }

    }else{
        
    }

?>