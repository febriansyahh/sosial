<header class="page-header">
	<h2>User</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>User</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
		    if (isset ($_POST ['btnSimpan'])) {

		      	$cek=mysqli_num_rows(mysqli_query($koneksi,"SELECT*from user where username='$_POST[txtUsername]'"));
		      	if($cek>0){
		      		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Username <strong>$_POST[txtUsername]</strong> sudah dipakai.
					 	  </div>";
				}else{

					$username = $_POST ['txtUsername'];
					$password = $_POST ['txtPassword'];
					$pengguna = $_POST ['cboPengguna'];
					$kategori = $_POST['rbKategori'];
					$level = "";

					if($kategori == 1){
						$level = "Pimpinan";
						$sql_insert = "INSERT INTO user (id_pimpinan,username,password,level) VALUES ('$pengguna','$username','$password','$level')";
					} else {
						$level = "Unit";
						$sql_insert = "INSERT INTO user (id_unit,username,password,level) VALUES ('$pengguna','$username','$password','$level')";
					}
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

		        	if ($query_insert) {
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='1; url=?v=user'>";
		        	}
		      	}
		    }
		?>

		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah User</h2>
				</header>
				<div class="panel-body">
					<div class="form-group row">
						<label class="col-sm-2 control-label">Kategori User: </label>
						<div class="col-sm-2">
							<div class="radio-custom">
								<input type="radio" id="radio1" name="rbKategori" value="1" checked>
								<label for="radio1">Pimpinan</label>
							</div>
						</div>
						<div class="col-sm-8">
							<div class="radio-custom">
								<input type="radio" id="radio2" name="rbKategori" value="2">
								<label for="radio2">Unit</label>
								</<div>
							</div>
							<br>
						</div>

						<div class="form-group row">
							<label class="col-sm-2 control-label">Pengguna: </label>
							<div class="col-sm-8" id="selectPimpinan">
								<select data-plugin-selectTwo class="form-control" name="cboPengguna">
									<option>*Pilih Pimpinan</option>
									<?php
	                                $query  = mysqli_query($koneksi, "SELECT*from pimpinan where not exists(SELECT*from user where user.id_pimpinan=pimpinan.id_pimpinan)") or die (mysqli_error());
	                                while ($data = mysqli_fetch_array($query))
	                                {         
	                                    echo "<option value='$data[id_pimpinan]'>$data[gelar_depan].$data[nama], $data[gelar_belakang] [NIP : $data[nip]]</option>";
	                                }
	                            ?>
								</select>
								<small>*) Hanya memuat Pimpinan yang belum masuk ke data user</small>
							</div>
							<div class="col-sm-8" id="selectUnit" style="display:none">
								<select data-plugin-selectTwo class="form-control populate" name="cboPengguna" id="unitpengirim">
									<option>*Pilih Unit</option>
									<?php
										$qryPengirim = mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.login='1' order by b.nama_unit,a.nama_unit asc");
										while($dtPengirim = mysqli_fetch_array($qryPengirim)){
											if($dtPengirim['nama2']!=null){
												$unit=$dtPengirim['nama2'];
											}
									?>
									<option value="<?php echo $dtPengirim['id_unit'] ?>">
										<?php echo $unit ?>
										<?php echo $dtPengirim['nama1'] ?>
									</option>
									<?php
										}
									?>
								</select>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 control-label">Username: </label>
							<div class="col-sm-3">
								<input type="text" class="form-control" name="txtUsername" maxlength="10" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-2 control-label">Password: </label>
							<div class="col-sm-3">
								<input type="password" class="form-control" name="txtPassword" maxlength="10" required>
							</div>
						</div>
						<br>
					</div>
					<footer class="panel-footer">
						<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
						<a href="?v=user" class="btn btn-default">Kembali</a>
					</footer>
			</section>
		</form>
	</div>
</div>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
	$(document).ready(function () {
		$("input[name=rbKategori]:radio").click(function () {
			if ($(this).attr("value") == "1") {
				console.log("Pimpinan")
				$("#selectPimpinan").css('display', 'block');
				$("#selectUnit").css('display', 'none');
			}
			if ($(this).attr("value") == "2") {
				console.log("Unit")
				$("#selectPimpinan").css('display', 'none');
				$("#selectUnit").css('display', 'block');
			}
		});
	});

	// function yesnoCheck() {

	// 	if($('#radio1').attr('checked','checked')){
	// 		$('#selectPimpinan').show();
	// 		$('#selectUnit').hide();
	// 		console.log("Pimpinan")
	// 	} else if ($('#radio2').attr('checked','checked')){
	// 		$('#selectPimpinan').hide();
	// 		$('#selectUnit').show();
	// 		console.log("Unit")
	// 	}
	// }
</script>