<header class="page-header">
    <h2>Disposisi Surat Masuk</h2>

    <div class="right-wrapper pull-right">
        <ol class="breadcrumbs">
            <li>
                <a href="?v=beranda">
                    <i class="fa fa-home"></i>
                </a>
            </li>
            <li><span>Surat Masuk</span></li>
            <li><span>Proses</span></li>
            <li><span>Ubah Disposisi</span></li>
        </ol>

        <a class="sidebar-right-toggle"></a>
    </div>
</header>

<div class="row">
    <div class="col-md-12">
        <?php

            include "function.php";

            $datapegawai = getPegawai();

			require '../../PHPMailer/PHPMailerAutoload.php';
			$mail = new PHPMailer;

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM surat_masuk sm 
				INNER JOIN pimpinan p ON sm.id_pimpinan = p.id_pimpinan 
				INNER JOIN unit u ON sm.id_unit = u.id_unit where sm.id_s_masuk='$_GET[kd]'"));
			$surat=$data['scan_s_masuk'];
			$suratTugas=$data['surat_tugas'];
            $idsurat=$data['id_s_masuk'];
            $tglsekarang = date("Y-m-d");

            $getdispo = mysqli_fetch_array(mysqli_query($koneksi,"SELECT *from dispo_s_masuk 
            where id_s_masuk='$data[id_s_masuk]' and pemberi='$_GET[pemberi]' "));

            

            // var_dump("SELECT *from dispo_s_masuk 
            // where id_s_masuk='$data[id_s_masuk]' and pemberi='$_GET[pemberi]'");

            $ds = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE id_pgw = '$_GET[pemberi]' "));

            // var_dump($ds['id_pgw']." - ".$getID['id_dispo']);

			// Fungsi Kelola Disposisi
			if(isset($_POST['btnSimpan'])){

                $arrDariTemp = array();
                $arrDariSave = array();
                // $cboDari = explode('*',$_POST['cboDari']);
                $cboDariVal = $ds['id_pgw'];
                $cboDariLevel = $ds['jabatan_struktural'];

                $pemberi  = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE id_pgw ='$cboDariVal' "));
                $arrDariTemp['nip'] = $pemberi['nip'];

                foreach ($datapegawai as $key => $valRes) {
                    if(in_array($valRes['nip'],$arrDariTemp)){
                        $arrDariSave[] = $valRes;
                    }
                }

                if($arrDariSave[0]['nip'] != NULL | 
                    $arrDariSave[0]['nama'] != NULL | 
                    $arrDariSave[0]['gelar_depan'] != NULL |
                    $arrDariSave[0]['gelar_belakang'] != NULL |
                    $arrDariSave[0]['email'] != NULL |
                    $arrDariSave[0]['jabatan_fungsional'] != NULL |
                    $arrDariSave[0]['jabatan_struktural'] != NULL |
                    $arrDariSave[0]['pangkat'] != NULL ){
                        $arrDariNIP = $arrDariSave[0]['nip'];
                        $arrDariNama = $arrDariSave[0]['nama'];
                        $arrDariGdepan = $arrDariSave[0]['gelar_depan'];
                        $arrDariGblkg = $arrDariSave[0]['gelar_belakang'];
                        $arrDariEmail = $arrDariSave[0]['email'];
                        $arrDariJfung = $arrDariSave[0]['jabatan_fungsional'];
                        $arrDariJStruk = $arrDariSave[0]['jabatan_struktural'];
                        $arrDariPangkat = $arrDariSave[0]['pangkat'];
                        $queryArrayUpdatePegawaiPemberi = mysqli_query($koneksi,"UPDATE pgw SET
                            nip = '$arrDariNIP',
                            nama = '$arrDariNama',
                            gelar_depan = '$arrDariGdepan',
                            gelar_belakang = '$arrDariGblkg,
                            email = '$arrDariEmail',
                            jabatan_fungsional = '$arrDariJfung',
                            jabatan_struktural = '$arrDariJStruk',
                            pangkat = '$arrDariPangkat'
                            WHERE id_pgw = '$cboDariVal'
                        ");
                    }

                if($cboDariLevel=='Rektor'){
                    if($_POST['rbStatus']=='1'){
                        $sql_update = "UPDATE surat_masuk SET
                            status_s_masuk='".$_POST['rbStatus']."',
                            info_rektor='".$_POST['txtInfo']."'
                            WHERE id_s_masuk='".$data['id_s_masuk']."'";
                        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
    
                        $sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$data['id_s_masuk']."'";
                        $query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
                    }else{
    
                        $imp= implode("~ ", $_POST['cboTujuan']);
                        $exp= explode("~ ", $imp);
                        $count = count($exp);
    
                        $sql_update = "UPDATE surat_masuk SET
                            status_s_masuk='".$_POST['rbStatus']."',
                            info_rektor='".$_POST['txtInfo']."'
                            WHERE id_s_masuk='".$_GET['kd']."'";
                        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
    
                        if($_POST['cboTujuan'] != ''){
                            $sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$_GET['kd']."'";
                            $query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
                
                            $mail->isSMTP();                                     
                            $mail->Host = 'smtp.gmail.com';  
                            $mail->SMTPAuth = true;                      
                            $mail->Username = 'ardi.irfanto@umk.ac.id';        
                            $mail->Password = 'Regenerator';                         
                            $mail->SMTPSecure = 'tls';                           
                            $mail->Port = 587;                                   
                            $mail->setFrom('ardi.irfanto@umk.ac.id', 'Sistem Disposisi Surat Rektorat UMK');
                
                            $mail->smtpConnect(
                                array(
                                    "ssl" => array(
                                        "verify_peer" => false,
                                        "verify_peer_name" => false,
                                        "allow_self_signed" => true
                                    )
                                )
                            );
    
                            for($x=0;$x<$count;$x++){

                                $arrKeSave = explode('*',$exp[$x]);

                                $arrKeNIP = $arrKeSave[0];
                                $arrKeNama = $arrKeSave[1];
                                $arrKeGdepan = $arrKeSave[2];
                                $arrKeGblkg = $arrKeSave[3];
                                $arrKeEmail = $arrKeSave[4];
                                $arrKeJfung = $arrKeSave[5];
                                $arrKeJStruk = $arrKeSave[6];
                                $arrKePangkat = $arrKeSave[7];


                                $getKe = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama ='$arrKeNama' "));

                                if($getKe){
                                    $updateKe = mysqli_query($koneksi,"UPDATE pgw SET
                                        nip = '$arrKeNIP',
                                        nama = '$arrKeNama',
                                        gelar_depan = '$arrKeGdepan',
                                        gelar_belakang = '$arrKeGblkg',
                                        email = '$arrKeEmail',
                                        jabatan_fungsional = '$arrKeJfung',
                                        jabatan_struktural = '$arrKeJStruk',
                                        pangkat = '$arrKePangkat'
                                        WHERE id_pgw = '$getKe[id_pgw]'"
                                    );
                                    $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama = '$arrKeNama' "));
                                } else {
                                    $insertKe = mysqli_query($koneksi, "INSERT INTO pgw(nip,nama,gelar_depan,gelar_belakang,email,jabatan_fungsional,jabatan_struktural,pangkat)
                                        VALUES ('$arrKeNIP','$arrKeNama','$arrKeGdepan','$arrKeGblkg','$arrKeEmail',
                                            '$arrKeJfung','$arrKeJStruk','$arrKePangkat');
                                    ");
                                    $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw ORDER BY id_pgw DESC LIMIT 1 "));
                                }

                                mysqli_query($koneksi,"INSERT INTO dispo_s_masuk(id_s_masuk,id_pgw,informasi,tgl_dispo,pemberi,status) 
                                    values('$idsurat','$getKe2[id_pgw][$x]','$_POST[txtInfo]',NOW(),'$cboDariVal','2')");
                                $email = $getKe2['email'];

                                $mail->Subject = 'Pemberitahuan Disposisi';
                                $mail->Body    = "<div class='card' style='margin:50px;'>
                                                    <div class='card-header'>
                                                        <h5 align='center'>Pemberitahuan Disposisi</h5>
                                                    </div>
                                                    <div class='card-body'>
                                                        <div class='alert alert-success alert-bordered'>
                                                            <p> <b> Berikut adalah Detail Disposisi: </b> </p>
                                                            <p> Pemberi Disposisi      			:". $pemberi['gelar_depan']."".$pemberi['nama'].",". $pemberi['gelar_belakang'] ." </p>
                                                            <p> Disposisi ditujukan kepada      :". $getKe2['nama'] ." </p>
                                                            <p> Instruksi/Informasi     		:". $_POST['txtInfo'] ." </p>
                                                            <hr>
                                                            <p> Download File Surat Masuk       : <a href='localhost/disposisi/File/SuratMasuk/". $data['scan_s_masuk'] ."'> Download </a> </p>
                                                            <p> Untuk Ketersediaan terkait bisa/tidak silahkan menghubungi Admin Rektorat. Terima Kasih</p>
                                                        </div>
                                                    </div>
                                                </div>";
                                $mail->AltBody = '----------------------------------------------';
    
                                $mail->addAddress('ardi.irfanto@umk.ac.id','1');													
                                $mail->isHTML(true);
                                $mail->send();
                                $mail->ClearAddresses();
                                
                            }
                        }
                    }
                } else {
                    $getID = mysqli_fetch_array(mysqli_query($koneksi,"SELECT *from dispo_s_masuk where id_s_masuk='$data[id_s_masuk]' and id_pgw='$_GET[pemberi]'"));

                    // var_dump($getID);exit();

                    if($_POST['rbStatus']=='1'){
                        $sql_update = "UPDATE dispo_s_masuk SET
                            status ='".$_POST['rbStatus']."',
                            info_pemberi_dispo='".$_POST['txtInfo']."'
                            WHERE id_dispo='".$getID['id_dispo']."'";
                        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
    
                        $sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$_GET['kd']."' AND pemberi = '".$_GET['pemberi']."' ";
                        $query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
                    }else{
    
                        $imp= implode("~ ", $_POST['cboTujuan']);
                        $exp= explode("~ ", $imp);
                        $count = count($exp);
    
                        $sql_update = "UPDATE dispo_s_masuk SET
                            status ='".$_POST['rbStatus']."',
                            info_pemberi_dispo='".$_POST['txtInfo']."'
                            WHERE id_dispo='".$get['id_dispo']."'";
                        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
    
                        if($_POST['cboTujuan'] != ''){
                            $sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$_GET['kd']."' AND pemberi = '".$_GET['pemberi']."' ";
                            $query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());

                            $mail->isSMTP();                                     
                            $mail->Host = 'smtp.gmail.com';  
                            $mail->SMTPAuth = true;                      
                            $mail->Username = 'ardi.irfanto@umk.ac.id';        
                            $mail->Password = 'Regenerator';                         
                            $mail->SMTPSecure = 'tls';                           
                            $mail->Port = 587;                                   
                            $mail->setFrom('ardi.irfanto@umk.ac.id', 'Sistem Disposisi Surat Rektorat UMK');
                            $mail->smtpConnect(
                                array(
                                    "ssl" => array(
                                        "verify_peer" => false,
                                        "verify_peer_name" => false,
                                        "allow_self_signed" => true
                                    )
                                )
                            );
    
                            for($x=0;$x<$count;$x++){
                                $arrKeSave = explode('*',$exp[$x]);

                                $arrKeNIP = $arrKeSave[0];
                                $arrKeNama = $arrKeSave[1];
                                $arrKeGdepan = $arrKeSave[2];
                                $arrKeGblkg = $arrKeSave[3];
                                $arrKeEmail = $arrKeSave[4];
                                $arrKeJfung = $arrKeSave[5];
                                $arrKeJStruk = $arrKeSave[6];
                                $arrKePangkat = $arrKeSave[7];


                                $getKe = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama ='$arrKeNama' "));

                                if($getKe){
                                    $updateKe = mysqli_query($koneksi,"UPDATE pgw SET
                                        nip = '$arrKeNIP',
                                        nama = '$arrKeNama',
                                        gelar_depan = '$arrKeGdepan',
                                        gelar_belakang = '$arrKeGblkg',
                                        email = '$arrKeEmail',
                                        jabatan_fungsional = '$arrKeJfung',
                                        jabatan_struktural = '$arrKeJStruk',
                                        pangkat = '$arrKePangkat'
                                        WHERE id_pgw = '$getKe[id_pgw]'"
                                    );
                                    $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama = '$arrKeNama' "));
                                } else {
                                    $insertKe = mysqli_query($koneksi, "INSERT INTO pgw(nip,nama,gelar_depan,gelar_belakang,email,jabatan_fungsional,jabatan_struktural,pangkat)
                                        VALUES ('$arrKeNIP','$arrKeNama','$arrKeGdepan','$arrKeGblkg','$arrKeEmail',
                                            '$arrKeJfung','$arrKeJStruk','$arrKePangkat');
                                    ");
                                    $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw ORDER BY id_pgw DESC LIMIT 1 "));
                                }

                                mysqli_query($koneksi,"INSERT INTO dispo_s_masuk(id_s_masuk,id_pgw,informasi,tgl_dispo,pemberi,status) 
                                    values('$idsurat','$getKe2[id_pgw][$x]','$_POST[txtInfo]',NOW(),'$_GET[pemberi]','2')");
                                $email = $getKe2['email'];

                                $mail->Subject = 'Pemberitahuan Disposisi';
                                $mail->Body    = "<div class='card' style='margin:50px;'>
                                                    <div class='card-header'>
                                                        <h5 align='center'>Pemberitahuan Disposisi</h5>
                                                    </div>
                                                    <div class='card-body'>
                                                        <div class='alert alert-success alert-bordered'>
                                                            <p> <b> Berikut adalah Detail Disposisi: </b> </p>
                                                            <p> Pemberi Disposisi      			:". $pemberi['gelar_depan']."".$pemberi['nama'].",". $pemberi['gelar_belakang'] ." </p>
                                                            <p> Disposisi ditujukan kepada      :". $getKe2['gelar_depan']."".$getKe2['nama'].",". $getKe2['gelar_belakang'] ." </p>
                                                            <p> Instruksi/Informasi     		:". $_POST['txtInfo'] ." </p>
                                                            <hr>
                                                            <p> Download File Surat Masuk       : <a href='localhost/disposisi/File/SuratMasuk/". $data['scan_s_masuk'] ."'> Download </a> </p>
                                                            <p> Untuk Ketersediaan terkait bisa/tidak silahkan menghubungi Admin Rektorat. Terima Kasih</p>
                                                        </div>
                                                    </div>
                                                </div>";
                                $mail->AltBody = '----------------------------------------------';
    
                                $mail->addAddress('ardi.irfanto@umk.ac.id','1');													
                                $mail->isHTML(true);
                                $mail->send();
                                $mail->ClearAddresses();
                            }
                        }
                    }
                }

	        	if ($query_update) {
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
                              echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_proses&kd=$_GET[kd]'>";
                            }
            }
            
            // Fungsi Kelola Anggota Disposisi
            if(isset($_POST['btnSimpanMember'])){
                $jml = count($_POST['iddispo']);
                
                for ($i=0; $i < $jml; $i++) { 
                    $id = $_POST['iddispo'];
                    $status =  $_POST['cbStatusDispo'];
                    $ket = $_POST['tKet'];
                    $int = $_POST['tIn'];
                    $query_update = mysqli_query($koneksi,"UPDATE dispo_s_masuk SET status = '$status[$i]', info_pemberi_dispo ='$ket[$i]', informasi='$int[$i]' WHERE id_dispo = '$id[$i]' ");
                }

                if ($query_update) {
                    echo "<div class='alert alert-primary'>
                            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
                            <strong>Simpan Berhasil!</strong> Tunggu...
                            </div>";
                    echo "<script>window.location.replace('?v=s_masuk_dispo_ubah&kd=$_GET[kd]&pemberi=$_GET[pemberi]&idpgw=$_GET[idpgw]');</script>";
                }
            }

            // Fungsi Hapus Dispo
            if(isset($_GET['del'])){
                $id = $_GET['del'];
                $delQuery = mysqli_query($koneksi,"DELETE FROM dispo_s_masuk WHERE id_dispo ='$id'");
				if ($delQuery) {
					echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Hapus Berhasil!</strong> Tunggu...
							</div>";
					echo "<script>window.location.replace('?v=s_masuk_dispo_ubah&kd=$_GET[kd]&pemberi=$_GET[pemberi]&idpgw=$_GET[idpgw]');</script>";
				}
            }

		?>

        <!-- Ubah Disposisi -->
        <form method="POST" class="form-horizontal">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                    </div>

                    <h2 class="panel-title"><b><?php echo $ds['gelar_depan']." ".$ds['nama'].", ".$ds['gelar_belakang'] ?></b></h2>
                </header>
                <div class="panel-body">
                    <table class="table">
                        <tbody>
                            <tr class="gradeX">
                                <td width="170"><b>Disposisi Dari</b></td>
                                <td>
                                    <?php
										echo "<b> ".$ds['gelar_depan']." ".$ds['nama'].", ".$ds['gelar_belakang']." </b>";
									?>
                                </td>
                            </tr>
                            <tr class="gradeX">
                                <td width="170"><b>Aksi</b></td>
                                <td>
                                    <div class="col-md-4">
                                        <div class="radio-custom">
                                            <input type="radio" id="radioExample1" onclick="javascript:yesnoCheck();"
                                                name="rbStatus" value="1"
                                                <?php if($data['status_s_masuk']=='1'){echo "checked";} ?>>
                                            <label for="radioExample1">Menghadiri/Menyanggupi</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="radio-custom">
                                            <input type="radio" id="radioExample2" onclick="javascript:yesnoCheck();"
                                                name="rbStatus" value="0"
                                                <?php if($data['status_s_masuk']=='0'){echo "checked";} ?>>
                                            <label for="radioExample1">Disposisi</label>
                                        </div>
                                    </div>
                                    <?php
													if($data['status_s_masuk']=='0'){
												?>
                                    <div class="col-md-7" id="disposisi" style="display: block;">
                                        <?php
													}else{
												?>
                                        <div class="col-md-12" id="disposisi" style="display: none;">
                                            <?php
													}
												?>
                                            <br>
                                            <?php
														if($data['status_s_masuk']=='0'){
											?>
                                            <label>Ubah disposisi:</label>
                                            <?php
														}else{
											?>
                                            <label>Disposisi ke:</label>
                                            <?php
														}
											?>

                                            <select multiple data-plugin-selectTwo class="form-control populate"
                                                name="cboTujuan[]">
                                                <option>*Pilih</option>
                                                <?php
                                                    foreach ($datapegawai as $key => $val) {
                                                        $value = $val['nip']."*".
                                                                $val['nama']."*".
                                                                $val['gelar_depan']."*".
                                                                $val['gelar_belakang']."*".
                                                                $val['email']."*".
                                                                $val['jabatan_fungsional']."*".
                                                                $val['jabatan_struktural']."*".
                                                                $val['pangkat'];
                                                        echo "<option value='$value' > $val[gelar_depan] $val[nama], $val[gelar_belakang] [$val[nip]] </option>";
                                                    }
							                    ?>
                                            </select>
                                            <small>*) Kosongi bila disposisi tidak diubah</small>
                                        </div>
                                        <?php
											$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk where id_s_masuk='$_GET[kd]' "));
											if($data['status_s_masuk']=='0'){
										?>
                                        <div class="col-md-5" id="listdispo" style="top: 20px;margin-bottom:20px;">
                                            Disposisi Ke
                                            <ul>
                                                <?php
													$qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk dsm inner join pgw p on dsm.id_pgw = p.id_pgw where dsm.id_s_masuk='$data[id_s_masuk]' AND dsm.pemberi ='$_GET[pemberi]'");
													while($dta = mysqli_fetch_array($qr)){
										        ?>
                                                <li>
                                                    <b><?php echo $dta['gelar_depan']." ".$dta['nama'].", ".$dta['gelar_belakang'] ?></b>
                                                    (<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>)
                                                </li>
                                                <?php
													}
												?>
                                            </ul>
                                        </div>
                                        <?php
											}
										?>
                                </td>
                            </tr>
                            <tr class="gradeX">
                                <td width="170"><b>Instruksi/Informasi</b></td>
                                <td>
                                    <textarea class="form-control" rows="3" id="textareaAutosize" name="txtInfo"
                                        data-plugin-textarea-autosize><?php echo $getdispo['informasi'] ?></textarea>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <footer class="panel-footer">
                    <button class="btn btn-success" type="submit" name="btnSimpan">Simpan</button>
                    <a href="index.php?v=s_masuk_proses&kd=<?php echo $_GET['kd']?>" class="btn btn-default">Kembali</a>
                </footer>
            </section>
        </form>
        
        <!-- Ubah yang di Disposisi -->
        <form method="POST" class="form-horizontal">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                    </div>

                    <h2 class="panel-title">Daftar Pegawai yang ditugaskan</h2>
                </header>
                <div class="panel-body">
                    <table class="table">
                        <thead>
                            <th>No</th>
                            <th>Nama Pegawai/Unit</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Informasi/Instruksi</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php 
                                $noo = 1;
                                $unit = '';
                                $qdis = mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk dsm 
                                                    INNER JOIN pgw p ON dsm.id_pgw = p.id_pgw
                                                    WHERE dsm.pemberi = '$_GET[pemberi]' 
                                                    AND dsm.id_s_masuk ='$_GET[kd]'");
                                while ($ddis = mysqli_fetch_array($qdis)) {
                            ?>
                            <tr>
                                <td>
                                    <?php echo $noo++ ?>
                                    <input type="hidden" value="<?php echo $ddis['id_dispo'] ?>" name="iddispo[]">
                                </td>
                                <td><?php echo $ddis['gelar_depan']." ".$ddis['nama'].", ".$ddis['gelar_belakang'] ?></td>
                                <td>
                                    <select name="cbStatusDispo[]" class="form-control">
                                        <option value="2" <?php if($ddis['status']=='2'){echo "SELECTED";} ?>> Belum Memberi Putusan </option>
                                        <option value="1" <?php if($ddis['status']=='1'){echo "SELECTED";} ?>> Bisa </option>
                                        <option value="0" <?php if($ddis['status']=='0'){echo "SELECTED";} ?>> Tidak Bisa </option>
                                    </select>
                                </td>
                                <td>
                                    <textarea name="tKet[]" class="form-control" cols="30" rows="2"><?php echo $ddis['info_pemberi_dispo'] ?></textarea>
                                </td>
                                <td>
                                    <textarea name="tIn[]" class="form-control" cols="30" rows="2"><?php echo $ddis['informasi'] ?></textarea>
                                </td>
                                <td>
                                    <a href="index.php?v=s_masuk_dispo_ubah&kd=<?php echo $_GET['kd'] ?>&pemberi=<?php echo $_GET['pemberi'] ?>&del=<?php echo $ddis['id_dispo'] ?>" style="margin-top:10px;" class="btn btn-danger btn-sm">X</a>
                                </td>
                            </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
                <footer class="panel-footer">
                    <button class="btn btn-info" type="submit" name="btnSimpanMember">Simpan</button>
                </footer>
            </section>
        </form> 
    </div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>
    PDFObject.embed("../../File/Surat Masuk/<?php echo $surat ?>#toolbar=0", "#example1");
</script>
<!-- <script>PDFObject.embed("../../File/Surat Tugas/<?php echo $suratTugas ?>#toolbar=1", "#example2");</script> -->

<style>
    .pdfobject-container {
        height: 90rem;
        border: 0.4rem solid rgba(0, 0, 0, .1);
    }
</style>

<script>
    function hanyaAngka(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))

            return false;
        return true;
    }

    function yesnoCheck() {
        if (document.getElementById('radioExample2').checked) {
            document.getElementById('disposisi').style.display = 'block';
            document.getElementById('listdispo').style.display = 'block';
        } else if (document.getElementById('radioExample1').checked) {
            document.getElementById('disposisi').style.display = 'none';
            document.getElementById('listdispo').style.display = 'none';
        }
    }
</script>