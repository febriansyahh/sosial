<header class="page-header">
	<h2>Notif Agenda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Notif Agenda</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			date_default_timezone_set('Asia/Jakarta');
    		$tglskrg=date('Y-m-d');
    		$jamskrg=date('H:i:s');

		    if (isset ($_POST ['btnSimpan'])) {
		    	$tglAgd=$_POST['tanggalAgd'];
		    	$jamAgd=$_POST['jam_agenda'];

		    	if($_POST['cboWaktu']=='00:30:00'){
		            $add='+30 minutes';
		            $min='-30 minutes';
		        }elseif($_POST['cboWaktu']=='1:00:00'){
		            $add='+1 hours';
		            $min='-1 hours';
		        }elseif($_POST['cboWaktu']=='6:00:00'){
		            $add='+6 hours';
		            $min='-6 hours';
		        }elseif($_POST['cboWaktu']=='12:00:00'){
		            $add='+12 hours';
		            $min='-12 hours';
		        }
		    	$waktuNotif=date('H:i:s', strtotime($add));
		    	$SelisihNotif=date($jamAgd, strtotime($min));

		    	$date = date_create($jamAgd);
				date_add($date, date_interval_create_from_date_string($min));
				$selisih=date_format($date, 'H:i:s').'';

		    	$cekNotif=mysqli_num_rows(mysqli_query($koneksi, "SELECT * from agenda inner join set_notif on set_notif.id_agenda=agenda.id_agenda where status_kirim='Belum' and tgl_agenda='$tglAgd' and waktu_notif='$selisih'"));
		    	// var_dump($cekNotif);exit();
		    	if($tglskrg > $tglAgd){
		    		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Tanggal agenda terlewat.
						  </div>";
		    	}else{
		    		if($tglskrg >= $tglAgd && $jamskrg > $jamAgd){
		    			echo "<div class='alert alert-danger'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Gagal!</strong> Jam agenda terlewat.
							  </div>";
		    		}else{
		    			// var_dump($selisih.' - '.$jamAgd);exit();
		    			if($tglskrg >= $tglAgd && $selisih > $jamAgd || $tglskrg >= $tglAgd && $jamskrg > $selisih){
		    				echo "<div class='alert alert-danger'>
									<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
									<strong>Simpan Gagal!</strong> Waktu Notif melebihi jam agenda/terlewat dengan waktu saat ini.
								  </div>";
		    			}else{
		    				if($cekNotif > 0){
		    					echo "<div class='alert alert-danger'>
										<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
										<strong>Simpan Gagal!</strong> Sudah ada seting notif pada <strong>$selisih</strong>.
									  </div>";
		    				}else{
		    					$sql_insert = "INSERT INTO set_notif (id_agenda,set_waktu,id_grup_e,waktu_notif) VALUES (
						              '".$_POST ['cboAgenda']."',
						              '".$_POST ['cboWaktu']."',
						              '".$_POST ['cboGrup']."',
						              '".$selisih."')";
						        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

					        	if ($query_insert) {
					        		echo "<div class='alert alert-primary'>
											<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
											<strong>Simpan Berhasil!</strong> Tunggu...
										  </div>";
					          		echo "<meta http-equiv='refresh' content='1; url=?v=agenda_notif'>";
					        	}
		    				}
		    			}
		    		}
		    	}
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Notif Agenda</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Cari Agenda: </label>
						<div class="col-sm-8">
							<select data-plugin-selectTwo class="form-control" name="cboAgenda" id="kredit" onchange="changeValue(this.value)" required>
								<option>*Pilih</option>
								<?php
	                                $query  = mysqli_query($koneksi, "SELECT*from agenda where not exists(SELECT*from set_notif where set_notif.id_agenda=agenda.id_agenda)");
	                                $jsArray = "var dtAg = new Array();\n";
	                                while ($data = mysqli_fetch_array($query))
	                                {         
	                                    echo "<option value='$data[id_agenda]'>$data[nama_agenda]</option>";
	                                    $jsArray .= "dtAg['" . $data['id_agenda']. "'] = {tgl_agenda:'" . addslashes( date("d/m/Y", strtotime($data['tgl_agenda'])) ). "',tanggalAgd:'" . addslashes( $data['tgl_agenda'] ). "',jam_agenda:'" . addslashes($data['jam_agenda']). "'};\n";
	                                }
	                            ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Waktu Agenda: </label>
						<div class="col-sm-2">
							<input type="text" class="form-control" id="tgl_agenda" name="tgl_agenda" autocomplete="off" readonly>
							<input type="hidden" name="tanggalAgd" id="tanggalAgd">
						</div>
						<div class="col-sm-2">
							<input type="text" name="jam_agenda" class="form-control" id="jam_agenda" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Set Waktu: </label>
						<div class="col-sm-3">
							<select data-plugin-selectTwo class="form-control" name="cboWaktu" required>
								<option>*Pilih</option>
								<option value="00:30:00">30 menit</option>
								<option value="1:00:00">1 jam</option>
								<option value="6:00:00">6 jam</option>
								<option value="12:00:00">12 jam</option>
							</select>
						</div>
						<small>Sebelum waktu agenda</small>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Grup Email: </label>
						<div class="col-sm-5">
							<select data-plugin-selectTwo class="form-control" name="cboGrup" required>
								<option>*Pilih</option>
								<?php
	                                $query  = mysqli_query($koneksi, "SELECT*from grup_email where status_grup_e='Aktif'") or die (mysqli_error());
	                                while ($data = mysqli_fetch_array($query))
	                                {         
	                                    echo "<option value='$data[id_grup_e]'>$data[nama_grup_e]</option>";
	                                }
	                            ?>
							</select>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=agenda_notif" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>

    <?php echo $jsArray ?>
    function changeValue(kredit){
        document.getElementById('tgl_agenda').value = dtAg[kredit].tgl_agenda;
        document.getElementById('jam_agenda').value = dtAg[kredit].jam_agenda;
        document.getElementById('tanggalAgd').value = dtAg[kredit].tanggalAgd;
    }

</script>