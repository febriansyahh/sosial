<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk where id_s_masuk='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		    	if ($_FILES['File']['name']!=""){
		    		$nama2=str_replace('/', '', $_POST['txtNoSurat']);
			        $file = $nama2.'.pdf';

			        copy($_FILES['File']['tmp_name'],"../../File/Surat Masuk/".$file);
			    }else{
			        $nama_file = $data['scan_s_masuk'];
			        $file = $nama_file;
			    }

			    if ($_FILES['FileST']['name']!=""){
		    		$nama3=str_replace('/', '', $_POST['txtNoSurat']);
			        $fileST = $nama3.'.pdf';

			        copy($_FILES['FileST']['tmp_name'],"../../File/Surat Tugas/".$fileST);
			    }else{
			        $nama_file2 = $data['surat_tugas'];
			        $fileST = $nama_file2;
			    }

				$sql_update = "UPDATE surat_masuk SET
		      		perihal_s_masuk='".$_POST['txtPerihal']."',
		      		tgl_s_kirim='".date("Y/m/d", strtotime($_POST['txtTglSurat']))."',
		      		tgl_s_terima='".date("Y/m/d", strtotime($_POST['txtTglTerima']))."',
		      		scan_s_masuk='".$file."',
		      		id_unit='".$_POST['cboUnit']."',
		      		id_kode='".$_POST['cboKode']."'
		      		WHERE id_s_masuk='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

	        	if ($query_update) {
	        		echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Berhasil!</strong> Tunggu...
						  </div>";
	          		echo "<meta http-equiv='refresh' content='1; url=?v=s_masuk_daftar&id=$_POST[cboKode]'>";
	        	}
		    }
		?>
		
		<form method="POST" class="form-horizontal" enctype="multipart/form-data">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Ubah Surat Masuk</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">No Surat: </label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="txtNoSurat" value="<?php echo $data['no_s_masuk'] ?>" readonly maxlength="50">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Tanggal Surat: </label>
						<div class="col-sm-2">
							<input type="text" name="txtTglSurat" data-plugin-datepicker class="form-control" required value="<?php echo date("m/d/Y", strtotime($data['tgl_s_kirim'])) ?>" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Tanggal Terima: </label>
						<div class="col-sm-2">
							<input type="text" name="txtTglTerima" data-plugin-datepicker class="form-control" required value="<?php echo date("m/d/Y", strtotime($data['tgl_s_terima'])) ?>" autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Perihal Surat: </label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="txtPerihal" value="<?php echo $data['perihal_s_masuk'] ?>" required maxlength="100">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">File Surat: </label>
						<div class="col-sm-5">
							<input type="file" class="form-control" name="File" accept=".pdf">
							<small>*) Kosongi bila file tidak diubah</small>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Surat Tugas: </label>
						<div class="col-sm-5">
							<input type="file" class="form-control" name="FileST" accept=".pdf">
							<small>*) Kosongi bila file tidak diubah</small>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Kode Surat: </label>
						<div class="col-sm-8">
							<select data-plugin-selectTwo class="form-control" required name="cboKode">
								<option>*Pilih</option>
								<?php
	                                $query1  = mysqli_query($koneksi, "SELECT*from kode_surat") or die (mysqli_error());
	                                while ($data1 = mysqli_fetch_array($query1))
	                                {         
	                                    if($data[id_kode] == $data1[id_kode])
	                                      {
	                                        echo"<option value='$data1[id_kode]' selected='$data[nama_kode]'>$data1[nama_kode]</option>";  
	                                      }
	                                    else
	                                      {
	                                        echo"<option value='$data1[id_kode]'>$data1[nama_kode]</option>"; 
	                                      }
	                                }
	                            ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Unit Pengirim: </label>
						<div class="col-sm-8">
							<select data-plugin-selectTwo class="form-control" required name="cboUnit">
								<option>*Pilih</option>
								<?php
	                                $qr  = mysqli_query($koneksi, "SELECT*from unit") or die (mysqli_error());
	                                while ($dt = mysqli_fetch_array($qr))
	                                {   
	                                	if($data[id_unit] == $dt[id_unit])
	                                      {
	                                        echo"<option value='$dt[id_unit]' selected='$data[nama_unit]'>$dt[nama_unit]</option>";  
	                                      }
	                                    else
	                                      {
	                                        echo"<option value='$dt[id_unit]'>$dt[nama_unit]</option>"; 
	                                      }
	                                }
	                            ?>
							</select>
						</div>
					</div>
					
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=s_masuk" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>