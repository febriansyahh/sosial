<?php
	include "../../koneksi.php";
	$tglAwal=date("Y/m/d", strtotime($_POST['start']));
	$tglAkhir=date("Y/m/d", strtotime($_POST['end']));
	
	//Tanggal Sekarang
	date_default_timezone_set('Asia/Jakarta');
	$tanggal= mktime(date('m'),date('d'),date('Y'));
	$tglsekarang = date('Y-m-d', $tanggal);
	$thnsekarang = date('Y', $tanggal);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    	<title>Laporan Disposisi</title>
		<style>
			body {
			   font-family: Tahoma;
			   font-size: 11px;
			}

			h1, h2, h3, h4, h5, h6 {
			   padding: 2px 0px;
			   margin: 0px;
			}

			h1 {
			   font-size: 15pt;
			}

			h2 {
			   font-size: 13pt;
			}

			h3 {
			   font-size: 11pt;
			}

			h4 {
			   font-size: 9pt;
			}

			hr {
			   clear: both;
			}

			img {
			   margin: 2px;
			}

			.center {
			   text-align: center;
			}

			.th_cust {
			   border: 1px solid #000;
			}

			div.page-portrait {
			   visibility: visible;
			   font-family: Tahoma;
			   font-size: 11px;
			   margin: 0 auto;
			   width: 19.1cm;
			}

			div.page-landscape {
			   visibility: visible;
			   font-family: Tahoma;
			   font-size: 11px;
			   margin: 0 auto;
			   width: 25.5cm;
			}

			table {
			   border-collapse: collapse;
			}

			.box {
			   border: 1px solid #ccc;
			   padding: 4px;
			}

			table tr td {
			   font-family: "Times New Roman";
			   font-size: 14px;
			   padding: 4px 4px 4px 4px;
			}

			table tr th {
			   font-family: "Times New Roman";
			   font-size: 15px;
			   font-weight: bold;
			   background-color: #fff;
			   padding: 4px;
			}

			.tabel-common tr td {
			   font-family: Tahoma;
			   font-size: 11px;
			   padding: 0px 2px 0px 2px;
			   border: 1px solid #000;
			   vertical-align: top;
			}

			.tabel-common .nama {
			   width: 250px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .ttd {
			  
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .nomor {
			   width: 20px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .tanda {
			   width: 50px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .nim {
			   width: 80px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common tr th {
			   font-family: Tahoma;
			   font-size: 11px;
			   font-weight: bold;
			   background-color: #fff;
			   padding: 2px;
			   border: 1px solid #000;
			}

			.incommon-separator {
			   border-top: 1px solid #fff !important;
			   border-left: 1px solid #fff !important;
			   border-right: 1px solid #fff !important;
			   border-bottom: 1px solid #ccc !important;
			}

			.incommon-noseparator {
			   border: 1px solid #fff !important;
			}

			.bottom-separator {
			   border-bottom: 1px solid #ccc !important;
			}

			.tabel-info tr td, th {
			   font-family: Tahoma;
			   font-size: 11px;
			   padding: 2px;
			   font-weight: bold;
			}

			div.nobreak .hidden {
			   visibility: hidden;
			   display: none;
			}

			div.page-break .hidden {
			   visibility: visible;
			   margin: 10px 0px 10px 0px;
			}

			.page-break {
			   clear: both;
			}

			.link {
			   clear:both;
			   visibility: visible;
			}

			.alamat {
			  font-family: "Times New Roman", Helvetica, sans-serif;
			  font-size: 16px;
			}
			.yayasan {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 32px; }
			.univ {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 18px; }
			.fakultas {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 14px; }
			.label {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 10px; }


			#header .separatorAlamat{
			   background-color:#5C74B0;
			   color:#fff;
			   height:40px;
			   font-size: 13px;
			}
		</style>
	</head>
	<body onLoad="window.print();">
		<div class="page-portrait">
			<div class="page-break">
				<table style="border-collapse: collapse; line-height: 1.7em;" width="100%">
					<tbody>
						<tr>
							<td style="border-bottom:2px solid #000000;" valign="left" align="center" width="90">
								<img src="../../assets/images/logosn.png" width="100" height="100" style="padding:0px;">
							</td>
							<td colspan="3" style="border-bottom:2px solid #000000; padding-top: 0px; padding-right: 100px;" valign="middle" >
								<center><span class="univ"><strong>YAYASAN PEMBINA UNIVERSITAS MURIA KUDUS</strong></span><br>
								<center><span class="yayasan"><strong>UNIVERSITAS MURIA KUDUS</strong></span><br>
								<span class="alamat">Gondangmanis, Bae PO. BOX : 53 Telp : (0291) 438229 Fax : (0291) 437198<br></span>
								<span class="alamat">E-mail: muria@umk.ac.id http ://www.umk.ac.id<br></span></center>
								<span class="alamat">KUDUS 59352<br></span></center>
							</td>
						</tr>
						<tr>
							<td colspan="4">
								<span class="univ"></span>
							</td>
						</tr>
					</tbody>
		        </table>
		        <h3 align="center">LAPORAN DISPOSISI</h3><br>
		        <h4 align="center"><?php echo date("d/m/Y", strtotime($tglAwal)) ?> - <?php echo date("d/m/Y", strtotime($tglAkhir)) ?></h4>
		        <br />
		        <table style="border-collapse: collapse; border-width: 2px;" width="100%">
		        	<thead>
		        		<th class="th_cust">No</th>
		        		<th class="th_cust">No Surat</th>
		        		<th class="th_cust">Tgl Surat</th>
		        		<!-- <th class="th_cust">Jenis Surat</th> -->
		        		<th class="th_cust">Perihal</th>
		        		<th class="th_cust">Pengirim</th>
		        		<th class="th_cust">Disposisi</th>
		        	</thead>
		        	<tbody>
		        		<?php
		                    $no=1;
		                    $query = mysqli_query($koneksi,"SELECT * from surat_masuk inner join kode_surat on kode_surat.id_kode=surat_masuk.id_kode inner join unit on unit.id_unit=surat_masuk.id_unit inner join disposisi_s_masuk on disposisi_s_masuk.id_s_masuk=surat_masuk.id_s_masuk where tgl_s_kirim between '$tglAwal' and '$tglAkhir' order by no_s_masuk ASC");
		                    while($data = mysqli_fetch_array($query)){
		                ?>
		                <tr>
		                	<td class="th_cust"><center><?php echo $no ?>.</center></td>
							<td class="th_cust"><?php echo $data['no_s_masuk'] ?></td>
							<!-- <td class="th_cust"><?php echo $data['nama_kode'] ?></td> -->
							<td class="th_cust"><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
							<td class="th_cust"><?php echo $data['perihal_s_masuk'] ?></td>
							<td class="th_cust"><?php echo $data['nama_unit'] ?></td>
							<td class="th_cust">
								<ul>
									<?php
										$query2="SELECT*from tujuan_dispo inner join disposisi_s_masuk on disposisi_s_masuk.id_dispo=tujuan_dispo.id_dispo inner join unit on unit.id_unit=tujuan_dispo.id_unit where id_s_masuk='$data[id_s_masuk]'" ;
										$tampil2=mysqli_query($koneksi,$query2) or die(mysqli_error());
										while($data2=mysqli_fetch_array($tampil2)){
									?>
										<li>
											<?php echo $data2['nama_unit'] ?> ( <?php echo date("d/m/Y", strtotime($data2['tgl_dispo']));?> )
										</li>
									<?php
										}
									?>
								</ul>
							</td>
		                </tr>
		                <?php
		                	$no++;
		                	}
		                ?>
		            </tbody>
		        </table>
		    </div>
		</div>
	</body>
</html>