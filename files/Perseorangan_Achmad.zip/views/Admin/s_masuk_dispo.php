<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Disposisi</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$dt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk inner join disposisi_s_masuk on disposisi_s_masuk.id_s_masuk=surat_masuk.id_s_masuk where surat_masuk.id_s_masuk='$_GET[kd]'"));
			$surat=$dt['scan_s_masuk'];

		    if (isset ($_POST ['btnTambah'])) {
				$sql_insert = "INSERT INTO tujuan_dispo (id_unit,id_dispo,tgl_dispo) VALUES (
		              '".$_POST ['cboUnit']."',
		              '".$dt ['id_dispo']."',
		              '".date("Y/m/d", strtotime($_POST['txtTglSurat']))."')";
		        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

	        	if ($query_insert) {
	          		echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_dispo&kd=$dt[id_s_masuk]'>";
	        	}
		    }

		    if (!$_GET['id']=="") { 

				$sql_hapus = "DELETE FROM tujuan_dispo WHERE id_tujuan_d='".$_GET['id']."'";
				$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
				if ($query_hapus) {
			        echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Hapus Berhasil!</strong> Tunggu...
						  </div>";
			        echo "<meta http-equiv='refresh' content='1; url=?v=s_masuk_dispo&kd=$_GET[kd]'>";
			    }
		  	}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Disposisi Surat Masuk</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Nomor Surat: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" name="txtUsername" value="<?php echo $dt['no_s_masuk'] ?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Tanggal Surat: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" name="txtUsername" value="<?php echo date("d/m/Y", strtotime($dt['tgl_s_kirim']));?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Tanggal Terima: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" name="txtUsername" value="<?php echo date("d/m/Y", strtotime($dt['tgl_s_terima']));?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Perihal: </label>
						<div class="col-sm-5">
							<input type="text" class="form-control" name="txtUsername" value="<?php echo $dt['perihal_s_masuk'] ?>" readonly>
						</div>
					</div>
					<hr>

					<?php
						$dispo=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from disposisi_s_masuk where id_s_masuk='$_GET[kd]'"));
					?>

					<h4 style="font-weight: bold; color: red;">DISPOSISI</h4>
					<!-- <div class="form-group">
						<label class="col-sm-2 control-label">No Agenda: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" name="txtUsername" value="<?php echo $dispo['no_agenda'] ?>">
						</div>
					</div> -->
					<div class="form-group">
						<label class="col-sm-2 control-label">Unit: </label>
						<div class="col-sm-8">
							<select data-plugin-selectTwo class="form-control" name="cboUnit">
								<option>*Pilih Unit</option>
								<?php
	                                $query  = mysqli_query($koneksi, "SELECT*from unit where not exists(SELECT*from tujuan_dispo where tujuan_dispo.id_unit=unit.id_unit and id_dispo='$dt[id_dispo]')") or die (mysqli_error());
	                                while ($data = mysqli_fetch_array($query))
	                                {         
	                                    echo "<option value='$data[id_unit]'>$data[nama_unit]</option>";
	                                }
	                            ?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Tanggal Disposisi: </label>
						<div class="col-sm-2">
							<input type="text" name="txtTglSurat" data-plugin-datepicker class="form-control" required autocomplete="off">
						</div>
						<div class="col-sm-2">
							<button class="btn btn-success" type="submit" name="btnTambah">Tambah </button>
						</div>
					</div>
					<br>
					<table class="table table-bordered table-striped mb-none">
						<thead>
							<tr>
								<th width="32">No</th>
								<th>Unit</th>
								<th>Tgl Disposisi</th>
								<th width="55"></th>
							</tr>
						</thead>
						<tbody>
							<?php
			                    $no=1;
			                    $query = mysqli_query($koneksi,"SELECT * from tujuan_dispo inner join unit on unit.id_unit=tujuan_dispo.id_unit where id_dispo='$dispo[id_dispo]'");
			                    while($data = mysqli_fetch_array($query)){
			                ?>
							<tr class="gradeX">
								<td><center><?php echo $no ?>.</center></td>
								<td><?php echo $data['nama_unit'] ?></td>
								<td><?php echo date("d/m/Y", strtotime($data['tgl_dispo']));?></td>
									<!-- <a href="" class="btn btn-sm btn-default"><i class="fa fa-info"></i></a> -->
								<td>
									<a class="btn btn-sm btn-danger" data-toggle='modal' data-target='#konfirmasi_hapus' title="Hapus" data-href='?v=s_masuk_dispo&id=<?php echo $data['id_tujuan_d'] ?>&kd=<?php echo $data['id_dispo'] ?>'><i class="fa fa-trash-o"></i></a>
								</td>
							</tr>
							<?php
								$no++;
								}
							?>
						</tbody>
					</table>
				</div>
				<footer class="panel-footer">
					<a href="?v=s_masuk_daftar&id=<?php echo $dt['id_kode'] ?>" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>