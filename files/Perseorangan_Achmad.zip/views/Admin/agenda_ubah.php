<header class="page-header">
	<h2>Agenda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Daftar Agenda</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from agenda where id_agenda='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		    	if ($_FILES['File']['name']!=""){
		    		$nama_file = $_FILES["File"]["name"];
			        $file = $nama_file;

			        copy($_FILES['File']['tmp_name'],"../../File/Agenda/".$file);
			    }else{
			        $nama_file = $data['file_agenda'];
			        $file = $nama_file;
			    }

			    $imp= implode(", ", $_POST['cboHadir']);
				$sql_update = "UPDATE agenda SET
		      		nama_agenda='".$_POST['txtNama']."',
		      		isi_agenda='".$_POST['ckIsi']."',
		      		tgl_agenda='".date("Y/m/d", strtotime($_POST['txtTgl']))."',
		      		jam_agenda='".$_POST['txtWaktu']."',
		      		file_agenda='".$file."',
		      		undangan='".$imp."'
		      		WHERE id_agenda='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

	        	if ($query_update) {
	        		echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Berhasil!</strong> Tunggu...
						  </div>";
	          		echo "<meta http-equiv='refresh' content='1; url=?v=agenda'>";
	        	}
		    }
		?>
		
		<form method="POST" class="form-horizontal" enctype="multipart/form-data">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Ubah Daftar Agenda</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Agenda: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" value="<?php echo $data['nama_agenda'] ?>" maxlength="50" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Isi Agenda: </label>
						<div class="col-sm-10">
							<textarea class="summernote" name="ckIsi" data-plugin-summernote data-plugin-options='{ "height": 180, "codemirror": { "theme": "ambiance" } }'><?php echo $data['isi_agenda'] ?></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Waktu Agenda: </label>
						<div class="col-sm-2">
							<input type="text" value="<?php echo date("m/d/Y", strtotime($data['tgl_agenda']));?>" name="txtTgl" data-plugin-datepicker class="form-control" autocomplete="off">
						</div>
						<div class="col-sm-2">
							<input type="text" value="<?php echo $data['jam_agenda'] ?>" name="txtWaktu" data-plugin-timepicker class="form-control" data-plugin-options='{ "showMeridian": false }'>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label" for="w4-email">File</label>
						<div class="col-sm-4">
							<input type="file" class="form-control" accept=".pdf" name="File" required>
							<small>*) Kosongi bila File tidak diubah</small>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label" for="w4-email">Undangan</label>
						<div class="col-sm-6">
							<select multiple data-plugin-selectTwo class="form-control populate" required name="cboHadir[]">
								<option>*Pilih</option>
								<?php
			                        $query  = mysqli_query($koneksi, "SELECT * from pimpinan") or die (mysqli_error());
			                        while ($data = mysqli_fetch_array($query))
			                        {
			                        	echo "<option value='$data[nama_pimpinan]'>$data[nama_pimpinan]</option>";
			                        }
			                    ?>
							</select>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=agenda" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>