<header class="page-header">
	<h2>Surat Keluar</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Keluar</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar where id_s_keluar='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		    	if ($_FILES['File']['name']!=""){
		    		$nama2=str_replace('/', '', $_POST['txtNoSurat']);
			        $file = $nama2.'.pdf';

			        copy($_FILES['File']['tmp_name'],"../../File/SuratKeluar/".$file);
			        copy($_FILES['File']['tmp_name'],"../../File/SuratMasuk/".$file);
			    }else{
			        $nama_file = $data['scan_s_keluar'];
			        $file = $nama_file;
			    }

				$sql_update = "UPDATE surat_keluar SET
		      		perihal_s_keluar='".$_POST['txtPerihal']."',
		      		ket_s_keluar='".$_POST['taKet']."',
		      		scan_s_keluar='".$file."'
		      		WHERE id_s_keluar='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        if($_POST['cboTujuan']!=''){
		        	$sql_hapus = "DELETE FROM surat_masuk WHERE no_s_keluar='".$_POST['txtNoSurat']."'";
					$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());

			        $tujuan=$_POST['cboTujuan'];
					$count = count($tujuan);
					 
					for($x=0;$x<$count;$x++){

						$cboUnit = explode('*', $tujuan[$x]);
						$jenis = $cboUnit[0];
						$idunit = $cboUnit[1];
						if($jenis=='P'){
							$query='id_pimpinan';
						}else{
							$query='id_penerima';
						}
						mysqli_query($koneksi,"INSERT INTO surat_masuk (no_s_masuk,perihal_s_masuk,tgl_s_kirim,tgl_s_terima,scan_s_masuk,id_unit,$query) VALUES (
							'".$_POST ['txtNoSurat']."',
							'".$_POST ['txtPerihal']."',
							'".$data ['tgl_s_keluar']."',
							'".$data ['tgl_s_keluar']."',
							'".$file_nama."',
							'".$_POST ['cboPengirim']."',
							'".$idunit."'
						)");
					}
		        }

	        	if ($query_update) {
	        		echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Berhasil!</strong> Tunggu...
						  </div>";
	          		echo "<meta http-equiv='refresh' content='1; url=?v=s_keluar_daftar&id=$_POST[cboKode]'>";
	        	}
		    }
		?>
		
		<form method="POST" class="form-horizontal" enctype="multipart/form-data">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Ubah Surat Keluar</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">No Surat: </label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="txtNoSurat" readonly maxlength="50" value="<?php echo $data['no_s_keluar'] ?>">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Perihal Surat: </label>
						<div class="col-sm-6">
							<input type="text" class="form-control" name="txtPerihal" value="<?php echo $data['perihal_s_keluar'] ?>" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">File Surat: </label>
						<div class="col-sm-5">
							<input type="file" class="form-control" name="File" accept=".pdf">
							<small>*) Kosongi bila file tidak diubah</small>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Keterangan: </label>
						<div class="col-sm-9">
							<textarea name="taKet" class="form-control" rows="6"><?php echo $data['ket_s_keluar'] ?></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Ditujukan kepada: </label>
						<div class="col-sm-6">
							<select multiple data-plugin-selectTwo class="form-control populate" required name="cboTujuan[]">
								<?php
									$qryDitujuP = mysqli_query($koneksi,"SELECT * from pimpinan where status='1'");
									while($dtDitujuP = mysqli_fetch_array($qryDitujuP)){
								?>
								<option value="P*<?php echo $dtDitujuP['id_pimpinan'] ?>"><?php echo $dtDitujuP['jabatan_struktural'] ?></option>
								<?php
									}
									$qryDituju = mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.login='1' order by b.nama_unit,a.nama_unit asc");
									while($dtDituju = mysqli_fetch_array($qryDituju)){
										if($dtDituju['nama2']!=null){
											$unitt=$dtDituju['nama2'];
										}
								?>
									<option value="U*<?php echo $dtDituju['id_unit'] ?>"><?php echo $unitt ?> <?php echo $dtDituju['nama1'] ?></option>
								<?php
									}
								?>
							</select>
							<small>*) Kosongi bila tidak diubah</small>
						</div>
						<div class="col-sm-4">
							<span>Ditujukan:</span>
							<ul>
								<?php
									$qr = mysqli_query($koneksi,"SELECT * from surat_masuk where no_s_masuk='$data[no_s_keluar]'");
				                    while($dt = mysqli_fetch_array($qr)){
										if($dt['id_penerima']!=null){
											$getUnit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.id_unit='$dt[id_penerima]'"));
											if($getUnit['nama2']!=null){
												$penerima=$getUnit['nama2'].' '.$getUnit['nama1'];
											}else{
												$penerima=$getUnit['nama1'];
											}
										}else{
											$getPimpinan=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pimpinan where id_pimpinan='$dt[id_pimpinan]'"));
											$penerima=$getPimpinan['jabatan_struktural'];
										}
				                ?>
								<li><?php echo $penerima ?></li>
								<?php
									}
								?>
							</ul>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=s_keluar" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>