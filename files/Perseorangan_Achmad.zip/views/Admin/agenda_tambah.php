<header class="page-header">
	<h2>Agenda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Daftar Agenda</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
		    if (isset ($_POST ['btnSimpan'])) {
		    	$tgl=date("Y-m-d", strtotime($_POST['txtTgl']));
		    	$cek=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from agenda where tgl_agenda='$tgl' and jam_agenda='$_POST[txtWaktu]'"));
		    	// var_dump("");exit();

		    	if($cek < 1){

		    		date_default_timezone_set('Asia/Jakarta');
			        $waktu=date('Y-m-d H:i:s');

		    		$imp= implode(", ", $_POST['cboHadir']);
		    		$nama_file = $_FILES["File"]["name"];
		    		$sql_insert = "INSERT INTO agenda (nama_agenda,isi_agenda,tgl_agenda,jam_agenda,file_agenda,undangan,waktu_agd) VALUES (
			              '".$_POST ['txtNama']."',
			              '".$_POST ['ckIsi']."',
			              '".date("Y/m/d", strtotime($_POST['txtTgl']))."',
			              '".$_POST ['txtWaktu']."',
			              '".$nama_file."',
			              '".$imp."',
			              '".$waktu."')";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

		        	if ($query_insert) {
		        		copy($_FILES['File']['tmp_name'],"../../File/Agenda/".$nama_file);
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='1; url=?v=agenda'>";
		        	}
		    	}else{
		    		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Sudah ada Agenda pada <strong>$_POST[txtTgl]</strong> <strong>$_POST[txtWaktu]</strong>.
					 	  </div>";
		    	}
		    }
		?>
		
		<form method="POST" class="form-horizontal" enctype="multipart/form-data">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Daftar Agenda</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Agenda: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" maxlength="50" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Isi Agenda: </label>
						<div class="col-sm-10">
							<textarea class="summernote" name="ckIsi" data-plugin-summernote data-plugin-options='{ "height": 180, "codemirror": { "theme": "ambiance" } }'></textarea>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Waktu Agenda: </label>
						<div class="col-sm-2">
							<input type="text" name="txtTgl" data-plugin-datepicker class="form-control" autocomplete="off">
						</div>
						<div class="col-sm-2">
							<input type="text" name="txtWaktu" data-plugin-timepicker class="form-control" data-plugin-options='{ "showMeridian": false }'>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label" for="w4-email">File</label>
						<div class="col-sm-4">
							<input type="file" class="form-control" accept=".pdf" name="File" required>
							<small>*) File harus bertipe <code>.pdf</code></small>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label" for="w4-email">Undangan</label>
						<div class="col-sm-6">
							<select multiple data-plugin-selectTwo class="form-control populate" required name="cboHadir[]">
								<option>*Pilih</option>
								<?php
			                        $query  = mysqli_query($koneksi, "SELECT * from pimpinan") or die (mysqli_error());
			                        while ($data = mysqli_fetch_array($query))
			                        {
			                        	echo "<option value='$data[nama_pimpinan]'>$data[nama_pimpinan]</option>";
			                        }
			                    ?>
							</select>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=agenda" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>