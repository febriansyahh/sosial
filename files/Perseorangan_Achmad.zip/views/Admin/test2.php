<?php
/**
 * This example shows settings to use when sending via Google's Gmail servers.
 */

//SMTP needs accurate times, and the PHP time zone MUST be set
//This should be done in your php.ini, but this is how to do it if you don't have access to that
date_default_timezone_set('Asia/Jakarta');

require 'PHPMailer/PHPMailerAutoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer;

//Tell PHPMailer to use SMTP
$mail->isSMTP();

//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
// $mail->SMTPDebug = 2;

//Ask for HTML-friendly debug output
// $mail->Debugoutput = 'html';

//Set the hostname of the mail server
$mail->Host = 'smtp.gmail.com';
// use
// $mail->Host = gethostbyname('smtp.gmail.com');
// if your network does not support SMTP over IPv6

//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
$mail->Port = 587;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = "streamcool15@gmail.com";

//Password to use for SMTP authentication
$mail->Password = "higannanda";

$koneksi=mysqli_connect("localhost", "root", "", "att");
$data = array();
            $sql = mysqli_query($koneksi,"SELECT*from set_notif inner join grup_email on grup_email.id_grup_e=set_notif.id_grup_e inner join daftar_grup_e on daftar_grup_e.id_grup_e=grup_email.id_grup_e inner join pimpinan on pimpinan.id_pimpinan=daftar_grup_e.id_pimpinan inner join agenda on agenda.id_agenda=set_notif.id_agenda where id_s_notif='10'"); //query untuk mendapatkan semua data mahasiswa

            while ($r = mysqli_fetch_array($sql)){ // data akan di ulang
                $data[]=$r['email'];
            }

            $implode = implode(",",$data);
            $process = explode(",",$implode);
            // $thn="'".$implode."'";
            // print_r($process);exit();
            reset($process);

            foreach ($process as $to) {

            //Set who the message is to be sent from
            $mail->setFrom('from@example.com', 'Admin Sekretariat UMK');

            //Set an alternative reply-to address
            $mail->addReplyTo('replyto@example.com', 'Admin Sekretariat UMK');

            //Set who the message is to be sent to
            $mail->addAddress($to);

            $get = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * from set_notif inner join agenda on agenda.id_agenda=set_notif.id_agenda where id_s_notif='10'"));

            //Set the subject line
            $mail->Subject = $get['nama_agenda'];
            // $mail_body = 'Isi body'


            // $sent=mail($to,$mail_subject,$mail_body, "From: youremail@domain.com");

            $mailContent = '<h3 style="text-align: center; "><span style="font-weight: bold;">JUDUL</span></h3>Coba daftar Satu :<div><ul><li>Satu</li><li>Dua</li><li><span style="color: rgb(255, 255, 0); background-color: rgb(206, 0, 0);">Tiga</span></li></ul><span style="font-style: italic;">Terimakasih</span> <span style="text-decoration-line: underline;">atas</span> <span style="font-weight: bold;">perhatiannya</span></div>';
            $mail->Body = $get['isi_agenda'];
            //Read an HTML message body from an external file, convert referenced images to embedded,
            //convert HTML into a basic plain-text alternative body
            // $mail->msgHTML(file_get_contents('PHPMailer/examples/contents.html'), dirname(__FILE__));

            //Replace the plain text body with one created manually
            $mail->AltBody = 'This is a plain-text message body';

            //Attach an image file
            // $mail->addAttachment('PHPMailer/examples/images/phpmailer_mini.png');

            }
//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}

?>