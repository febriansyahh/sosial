<?php

	$koneksi = mysqli_connect("localhost","root","","att");
    // $idd=$_GET['id'];
    $pgw=mysqli_num_rows(mysqli_query($koneksi,"SELECT * from set_notif where status_kirim='Belum'"));
    echo $pgw.'<br>';
    if($pgw>0){
    	$cekwaktu=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * from set_notif inner join agenda on agenda.id_agenda=set_notif.id_agenda where status_kirim='Belum'"));
    	// WAktu Agenda
    	$waktu=$cekwaktu['tgl_agenda'].' '.$cekwaktu['jam_agenda'];

    	if($cekwaktu['set_waktu']=='30 menit'){
    		$add='+30 minutes';
    	}elseif($cekwaktu['set_waktu']=='1 jam'){
    		$add='+1 hours';
    	}elseif($cekwaktu['set_waktu']=='6 jam'){
    		$add='+6 hours';
    	}elseif($cekwaktu['set_waktu']=='12 jam'){
    		$add='+12 hours';
    	}

    	date_default_timezone_set('Asia/Jakarta');
		// echo date('Y-m-d H:i:s', strtotime($add));
		$waktudevice=date('Y-m-d H:i:s', strtotime($add));
		echo '<br> Waktu Device : '.$waktudevice;
    }
    echo '<br> Waktu : '.$waktu;

    if($waktu==$waktudevice){
    	$status='Sama';
    }else{
    	$status='Beda';
    }
    echo '<br>'.$status;

?>