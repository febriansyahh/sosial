<header class="page-header">
	<h2>Grup Email</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Grup Email</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<script>
    // function setNull(){
    //     $('#txtFormat').val("");
    // }
    function getFormat(){
        var format = $('#format').val();
        var kode = "01/"+format+"/A.01.01/I/1999"
        // console.log(format);
        if(format){
            $('#hasil').val(kode);
        }else{
        	$('#hasil').val('01//A.01.01/I/1999');
        }
        //  else{
        //     $('#txtKode').val('Lengkapi Kolom');
        // }
    }
</script>
<?php

	$unit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from unit where id_unit='$_GET[id]'"));

?>
<?php
	
	if (isset ($_POST ['btnSimpan'])) {

		$sql_insert = "INSERT INTO format_surat (format_surat,id_unit) VALUES (
                '".$_POST ['txtFormat']."',
            	'".$_GET ['id']."')";
        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

		if ($query_insert) {
      		echo "<script>window.location.replace('?v=unit_format_surat&id=$_GET[id]');</script>";
    	}
    }

    if (isset ($_POST ['btnUbah'])) {

		$sql_update = "UPDATE format_surat SET
      		format_surat='".$_POST['txtFormat']."'
      		WHERE id_format_s='".$_GET['format']."'";
        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		if ($query_update) {
      		echo "<script>window.location.replace('?v=unit_format_surat&id=$_GET[id]');</script>";
    	}
    }

    if (!$_GET['del']=="") { 

		$sql_hapus = "DELETE FROM format_surat WHERE id_format_s='".$_GET['del']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<script>window.location.replace('?v=unit_format_surat&id=$_GET[id]');</script>";
	    }
  	}

?>
<section class="panel">
	<?php if($_GET['status']!='' and $_GET['status']=='add'){ ?>
		<header class="panel-heading">
			<div class="panel-actions">
				<!-- <a href="#" class="fa fa-caret-down"></a> -->
			</div>

			<h2 class="panel-title">Tambah</h2>
		</header>
		<div class="panel-body">
			<form method="POST">
				<div class="form-group">
					<label class="col-sm-2 control-label">Format: </label>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="txtFormat" id="format" onkeyup="getFormat()" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label"></label>
					<div class="col-sm-8">
						<input type="" name="" id="hasil" style="height: 40px; font-size: 23px; border: 0px; width: 100%;" value="01//A.01.01/I/1999">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label"></label>
					<div class="col-sm-8">
						<button class="btn btn-primary" type="submit" name="btnSimpan">Simpan </button>
						<a href="?v=unit_format_surat&id=<?php echo $_GET['id'] ?>" class="btn btn-default">Batal</a>
					</div>
				</div>
			</form>
		</div>
	<?php } ?>
	<?php if($_GET['status']!='' and $_GET['status']=='edit'){
		$edit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from format_surat where id_format_s='$_GET[format]'"));
	 ?>
		<header class="panel-heading">
			<div class="panel-actions">
				<!-- <a href="#" class="fa fa-caret-down"></a> -->
			</div>

			<h2 class="panel-title">Ubah</h2>
		</header>
		<div class="panel-body">
			<form method="POST">
				<div class="form-group">
					<label class="col-sm-2 control-label">Format: </label>
					<div class="col-sm-8">
						<input type="text" class="form-control" name="txtFormat" id="format" onkeyup="getFormat()" value="<?php echo $edit['format_surat'] ?>" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label"></label>
					<div class="col-sm-8">
						<input type="" name="" id="hasil" style="height: 40px; font-size: 23px; border: 0px; width: 100%;" value="01/<?php echo $edit['format_surat'] ?>/A.01.01/I/1999">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label"></label>
					<div class="col-sm-8">
						<button class="btn btn-primary" type="submit" name="btnUbah">Simpan </button>
						<a href="?v=unit_format_surat&id=<?php echo $_GET['id'] ?>" class="btn btn-default">Batal</a>
					</div>
				</div>
			</form>
		</div>
	<?php } ?>
	<header class="panel-heading">
		<div class="panel-actions">
			<!-- <a href="#" class="fa fa-caret-down"></a> -->
		</div>

		<h2 class="panel-title">Format Nomor Surat "<?php echo $unit['nama_unit'] ?>" 
			<?php if($_GET['status']==''){ ?>
				<a href="?v=unit_format_surat&id=<?php echo $_GET['id'] ?>&status=add" class="btn btn-sm btn-success"><i class="fa fa-plus-square"></i> Tambah</a>
			<?php } ?>
		</h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>Format</th>
					<th width="138"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT * from format_surat where id_unit='$unit[id_unit]'");
                    while($data = mysqli_fetch_array($query)){
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td>
						<span class="label label-primary">Nomor Urut</span> / <?php echo $data['format_surat'] ?> / <span class="label label-primary">Kode Surat dan Sub</span> / <span class="label label-primary">Bulan Surat</span> / <span class="label label-primary">Tahun Surat</span><br>
						<small>Ex: 01/<?php echo $data['format_surat'] ?>/A.01.01/I/1999</small>
					</td>
					<td>
						<a href="?v=unit_format_surat&id=<?php echo $_GET['id'] ?>&status=edit&format=<?php echo $data['id_format_s'] ?>" title="Ubah" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
						<a class="btn btn-sm btn-danger" title="Hapus" data-toggle='modal' data-target='#konfirmasi_hapus' data-href='?v=unit_format_surat&id=<?php echo $_GET['id'] ?>&del=<?php echo $data['id_format_s'] ?>'><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
	<footer class="panel-footer">
		<a href="?v=unit" class="btn btn-default">Kembali</a>
	</footer>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>