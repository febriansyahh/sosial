<header class="page-header">
	<h2>Pimpinan</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Pimpinan</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pimpinan where id_pimpinan='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		      	$sql_update = "UPDATE pimpinan SET
							nip='".$_POST ['txtNIP']."',
                            nama='".$_POST ['txtNama']."',
                            gelar_depan='".$_POST ['txtGdepan']."',
                            gelar_belakang='".$_POST ['txtGbelakang']."',
                            email='".$_POST ['txtEmail']."',
                            jabatan_fungsional='".$_POST ['txtJfungsional']."',
                            jabatan_struktural='".$_POST ['txtJstruktural']."',
                            pangkat='".$_POST ['txtPangkat']."'
		      		WHERE id_pimpinan='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        if ($query_update) {
		          	echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Ubah Berhasil!</strong> Tunggu...
						</div>";
		          	echo "<meta http-equiv='refresh' content='1; url=?v=pimpinan'>";
		        }
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Pimpinan</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">NIP </label>
						<div class="col-sm-4">
							<input type="text" class="form-control" name="txtNIP" value="<?php echo $data['nip'] ?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Pimpinan: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" value="<?php echo $data['nama'] ?>" required>
						</div>
					</div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Gelar Depan: </label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="txtGdepan" value="<?php echo $data['gelar_depan'] ?>"" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Gelar Belakang: </label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="txtGbelakang" value="<?php echo $data['gelar_belakang'] ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email: </label>
                        <div class="col-sm-4">
                            <input type="email" class="form-control" name="txtEmail" value="<?php echo $data['email'] ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Jabatan Fungsional: </label>
                        <div class="col-sm-4">
                            <input type="text" name="txtJfungsional" class="form-control" value="<?php echo $data['jabatan_fungsional'] ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Jabatan Fungsional: </label>
                        <div class="col-sm-4">
                            <input type="text" name="txtJstruktural" class="form-control" value="<?php echo $data['jabatan_struktural'] ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Pangkat: </label>
                        <div class="col-sm-2">
                            <input type="text" name="txtPangkat" class="form-control" value="<?php echo $data['pangkat'] ?>">
                        </div>
                    </div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Ubah </button>
					<a href="?v=pimpinan" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>