<header class="page-header">
    <h2>Pimpinan</h2>

    <div class="right-wrapper pull-right">
        <ol class="breadcrumbs">
            <li>
                <a href="?v=beranda">
                    <i class="fa fa-home"></i>
                </a>
            </li>
            <li><span>Pimpinan</span></li>
            <li><span>Tambah</span></li>
        </ol>

        <a class="sidebar-right-toggle"></a>
    </div>
</header>

<div class="row">
    <div class="col-md-12">
        <?php
		    if (isset ($_POST ['btnSimpan'])) {

		      	$cek=mysqli_num_rows(mysqli_query($koneksi,"SELECT*from pimpinan where nip='$_POST[txtNIP]'"));
		      	$cekemail=mysqli_num_rows(mysqli_query($koneksi,"SELECT*from pimpinan where email='$_POST[txtEmail]'"));
		      	if($cek>0){
		      		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Pegawai dengan NIP <strong>$_POST[txtNIP]</strong> sudah dimasukkan.
					 	  </div>";
				}elseif($cekemail>0){
		      		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> Email <strong>$_POST[txtEmail]</strong> sudah dimasukkan.
					 	  </div>";
				}else{
					$sql_insert = "INSERT INTO pimpinan (nip,nama,gelar_depan,gelar_belakang,email,jabatan_fungsional,jabatan_struktural,pangkat,status) 
                        VALUES (
                            '".$_POST ['txtNIP']."',
                            '".$_POST ['txtNama']."',
                            '".$_POST ['txtGdepan']."',
                            '".$_POST ['txtGbelakang']."',
                            '".$_POST ['txtEmail']."',
                            '".$_POST ['txtJfungsional']."',
                            '".$_POST ['txtJstruktural']."',
                            '".$_POST ['txtPangkat']."',
                            1
                        )";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

		        	if ($query_insert) {
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='1; url=?v=pimpinan'>";
		        	}
		      	}
		    }
		?>

        <form method="POST" class="form-horizontal">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                    </div>

                    <h2 class="panel-title">Tambah Pimpinan</h2>
                    <!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
                </header>
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">NIP </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="txtNIP" onkeypress="return hanyaAngka(event)"
                                required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Nama Pimpinan: </label>
                        <div class="col-sm-4">
                            <input type="text" class="form-control" name="txtNama" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Gelar Depan: </label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="txtGdepan" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Gelar Belakang: </label>
                        <div class="col-sm-2">
                            <input type="text" class="form-control" name="txtGbelakang" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email: </label>
                        <div class="col-sm-4">
                            <input type="email" class="form-control" name="txtEmail" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Jabatan Fungsional: </label>
                        <div class="col-sm-4">
                            <input type="text" name="txtJfungsional" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Jabatan Fungsional: </label>
                        <div class="col-sm-4">
                            <input type="text" name="txtJstruktural" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Pangkat: </label>
                        <div class="col-sm-2">
                            <input type="text" name="txtPangkat" class="form-control">
                        </div>
                    </div>
                </div>
                <footer class="panel-footer">
                    <button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
                    <a href="?v=pimpinan" class="btn btn-default">Kembali</a>
                </footer>
            </section>
        </form>
    </div>
</div>