<header class="page-header">
	<h2>Grup Email</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Grup Email</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
		    if (isset ($_POST ['btnSimpan'])) {
				$sql_insert = "INSERT INTO grup_email (nama_grup_e,status_grup_e) VALUES (
		              '".$_POST ['txtNama']."',
		              '".$_POST ['cboStatus']."')";
		        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

	        	if ($query_insert) {
	        		echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Berhasil!</strong> Tunggu...
						  </div>";
	          		echo "<meta http-equiv='refresh' content='1; url=?v=grup'>";
	        	}
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Tambah Grup Email</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Nama Grup: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" required>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Status Grup: </label>
						<div class="col-sm-3">
							<select data-plugin-selectTwo class="form-control" name="cboStatus" required>
								<option value="Aktif">Aktif</option>
								<option value="Tidak Aktif">Tidak Aktif</option>
							</select>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
					<a href="?v=grup" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>