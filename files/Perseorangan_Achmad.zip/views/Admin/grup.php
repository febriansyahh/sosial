<header class="page-header">
	<h2>Grup Email</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Grup Email</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php

	if (!$_GET['id']=="") { 

		$sql_hapus = "DELETE FROM grup_email WHERE id_grup_e='".$_GET['id']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<div class='alert alert-primary'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<strong>Hapus Berhasil!</strong> Tunggu...
				  </div>";
	        echo "<meta http-equiv='refresh' content='1; url=?v=grup'>";
	    }
  	}

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Master Grup Email <a href="?v=grup_tambah" class="btn btn-sm btn-success"><i class="fa fa-plus-square"></i> Tambah</a></h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>Grup</th>
					<th>Isi</th>
					<th width="130">Status Grup</th>
					<th width="138"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT * from grup_email");
                    while($data = mysqli_fetch_array($query)){
                    	$isi=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from daftar_grup_e where id_grup_e='$data[id_grup_e]'"));
                    	if($data['status_grup_e']=="Aktif"){
                    		$label='success';
                    	}else{
                    		$label='danger';
                    	}
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td><?php echo $data['nama_grup_e'] ?></td>
					<td><?php echo $isi ?> email</td>
					<td><span class="label label-<?php echo $label ?>" style="font-size: 11px;"><?php echo $data['status_grup_e'] ?></span></td>
					<td>
						<a href="?v=grup_daftar&id=<?php echo $data['id_grup_e'] ?>" title="Daftar Email Grup" class="btn btn-sm btn-warning"><i class="fa fa-list"></i></a>
						<a href="?v=grup_ubah&id=<?php echo $data['id_grup_e'] ?>" title="Ubah" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
						<a class="btn btn-sm btn-danger" title="Hapus" data-toggle='modal' data-target='#konfirmasi_hapus' data-href='?v=grup&id=<?php echo $data['id_grup_e'] ?>'><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>