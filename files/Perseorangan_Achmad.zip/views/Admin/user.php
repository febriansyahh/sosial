<header class="page-header">
	<h2>User</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>User</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php

	if (!$_GET['id']=="") { 

		$sql_hapus = "DELETE FROM user WHERE id_user='".$_GET['id']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<div class='alert alert-primary'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<strong>Hapus Berhasil!</strong> Tunggu...
				  </div>";
	        echo "<meta http-equiv='refresh' content='1; url=?v=user'>";
	    }
  	}

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Data User <a href="?v=user_tambah" class="btn btn-sm btn-success"><i class="fa fa-plus-square"></i> Tambah</a></h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>Nama Pengguna</th>
					<th>Username</th>
					<th>Level</th>
					<th width="135"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT * from user WHERE level = 'Pimpinan' OR level = 'Unit' ORDER BY username ASC");
                    while($data = mysqli_fetch_array($query)){

						if($data['level']=='Pimpinan'){
							$dt = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan WHERE id_pimpinan = '$data[id_pimpinan]' "));
						} else if($data['level']=='Unit'){
							$dt = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROm unit WHERE id_unit = '$data[id_unit]' "));
						}

                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td>
						<?php
							if($data['level']=='Pimpinan'){
								echo $dt['gelar_depan'].".".$dt['nama'].", ".$dt['gelar_belakang'];
							} else if($data['level']=='Unit'){
								echo $dt['nama_unit'];
							}
						?>
					</td>
					<td><?php echo $data['username'] ?></td>
					<td><?php echo $data['level'] ?></td>
					<td>
						<a href="?v=user_ubah&id=<?php echo $data['id_user'] ?>" title="Ubah" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
						<a class="btn btn-sm btn-danger" data-toggle='modal' data-target='#konfirmasi_hapus' title="Hapus" data-href='?v=user&id=<?php echo $data['id_user'] ?>'><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>