<?php 

    function getUnit(){

        include "../../koneksi.php";

        // GET REQUEST
        $curl = curl_init();
        $host = 'https://ws.umk.ac.id/service/sdm/unitdata';
        curl_setopt_array($curl, array(
            CURLOPT_URL => $host,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => $_SERVER['HTTP_USER_AGENT'],
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array("api_key_umk: 96aa6e628e712a35284eeb4c018458d03d1be8e8")
        ));
                                        
        $response = curl_exec($curl);
        $err = curl_error($curl);
                                            
        curl_close($curl);

        if ($err) {
            return $err;
        } else {
            return $response;
        }

    }

    function getPegawai(){
        $curl = curl_init();
        $host = 'https://ws.umk.ac.id/service/sdm/pegawaidata';
        curl_setopt_array($curl, array(
            CURLOPT_URL => $host,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => $_SERVER['HTTP_USER_AGENT'],
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array("api_key_umk: 96aa6e628e712a35284eeb4c018458d03d1be8e8")
        ));
                                        
        $response = curl_exec($curl);
        $err = curl_error($curl);
                                            
        curl_close($curl);
        $res = array();
        $res_temp = array();
        $res_other = array();
        $test = array();
        $id = 0;

        if ($err) {
            return $err;
        } else {
            $json = json_decode($response,true);    
            $datajson = $json['data'];
            foreach ($datajson as $key => $value) {
                $test[$key] = $value;
                $test[$key]['id'] = $id;
                $id++;
            }
            krsort($test);
            foreach ($test as $key => $val) {
                if (!in_array($val['nip'], $res_temp)){
                    $res_temp[] = $val['nip'];
                    $res[$key] = $val;
                }
            }
            ksort($res);
            return $res;
        }
    }

?>