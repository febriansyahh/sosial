<header class="page-header">
	<h2>Pencarian</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Pencarian</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php

	$cekKeluar=mysqli_num_rows(mysqli_query($koneksi, "SELECT * from surat_keluar where no_s_keluar LIKE '%$_POST[q]%' or perihal_s_keluar LIKE '%$_POST[q]%'"));
	$cekMasuk=mysqli_num_rows(mysqli_query($koneksi, "SELECT * from surat_masuk inner join unit on unit.id_unit=surat_masuk.id_unit where no_s_masuk LIKE '%$_POST[q]%' or perihal_s_masuk LIKE '%$_POST[q]%' or nama_unit LIKE '%$_POST[q]%'"));

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Pencarian " <b><?php echo $_POST['q'] ?></b> "</h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none">
			<?php
				if($cekMasuk > 0){
			?>
				<thead>
					<tr>
						<th colspan="5" style="background-color: #c0c0c0;">SURAT MASUK</th>
					</tr>
					<tr>
						<th>No Surat</th>
						<th>Perihal</th>
						<th>Tanggal Surat</th>
						<th>Pengirim</th>
						<th width="65"></th>
					</tr>
				</thead>
				<tbody>
					<?php
	                    $query = mysqli_query($koneksi,"SELECT * from surat_masuk inner join unit on unit.id_unit=surat_masuk.id_unit where no_s_masuk LIKE '%$_POST[q]%' or perihal_s_masuk LIKE '%$_POST[q]%' or nama_unit LIKE '%$_POST[q]%'");
	                    while($data = mysqli_fetch_array($query)){
	                ?>
					<tr class="gradeX">
						<td><?php echo $data['no_s_masuk'] ?></td>
						<td><?php echo $data['perihal_s_masuk'] ?></td>
						<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
						<td><?php echo $data['nama_unit'] ?></td>
						<td>
							<a href="?v=s_masuk_proses&kd=<?php echo $data['id_s_masuk'] ?>" title="Detail" class="btn btn-sm btn-info"><i class="fa fa-search-plus"></i></a>
						</td>
					</tr>
					<?php
						$no++;
						}
					?>
				</tbody>
			<?php
				}
				if($cekKeluar > 0){
			?>
				<thead>
					<tr>
						<th colspan="5" style="background-color: #c0c0c0;">SURAT KELUAR</th>
					</tr>
					<tr>
						<th>No Surat</th>
						<th colspan="2">Perihal</th>
						<th>Tanggal Surat</th>
						<th width="65"></th>
					</tr>
				</thead>
				<tbody>
					<?php
	                    $query = mysqli_query($koneksi,"SELECT * from surat_keluar where no_s_keluar LIKE '%$_POST[q]%' or perihal_s_keluar LIKE '%$_POST[q]%'");
	                    while($data = mysqli_fetch_array($query)){
	                ?>
					<tr class="gradeX">
						<td><?php echo $data['no_s_keluar'] ?></td>
						<td colspan="2"><?php echo $data['perihal_s_keluar'] ?></td>
						<td><?php echo date("d/m/Y", strtotime($data['tgl_s_keluar']));?></td>
						<td>
							<a href="?v=s_keluar_detail&kd=<?php echo $data['id_s_keluar'] ?>" title="Detail" class="btn btn-sm btn-info"><i class="fa fa-search-plus"></i></a>
						</td>
					</tr>
					<?php
						$no++;
						}
					?>
				</tbody>
			<?php
				}
				if($cekKeluar < 1 && $cekMasuk < 1){
			?>
				<thead>
					<tr>
						<th colspan="5">SURAT TIDAK DITEMUKAN</th>
					</tr>
				</thead>
			<?php
				}
			?>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>