<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Proses</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM surat_masuk sm 
				INNER JOIN pimpinan p ON sm.id_pimpinan = p.id_pimpinan 
				INNER JOIN unit u ON sm.id_unit = u.id_unit where sm.id_s_masuk='$_GET[kd]'"));	
			$pimpinan = $data['gelar_depan'].".".$data['nama'].", ".$data['gelar_belakang'];		
			$surat=$data['scan_s_masuk'];
			$suratTugas=$data['surat_tugas'];
			$idsurat=$data['id_s_masuk'];
			$vKode = "";
			$vKeperluan = "";
			$vHari = "";
			$vTanggal = "";
			$vWaktu = "";
			$vTempat = "";
			$vKeterangan ="";
			$vTTD ="";

			$getStugas = mysqli_fetch_assoc(mysqli_query($koneksi,"SELECT * FROM surat_tugas WHERE id_s_masuk ='$idsurat' "));

			if($getStugas){
				$vKode = $getStugas['kd_s_tugas'];
				$vKeperluan = $getStugas['keperluan'];
				$vHari = $getStugas['hari'];
				$vTanggal = $getStugas['tanggal'];
				$vWaktu = $getStugas['waktu'];
				$vTempat = $getStugas['tempat'];
				$vKeterangan = $getStugas['keterangan'];
				$vTTD = $getStugas['ttd'];
			}

			$rowdispo = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk WHERE id_s_masuk = '$_GET[kd]' "));

			if(isset($_POST['btnSimpan'])){
				$kode = $_POST['txtKode'];
				$keperluan = $_POST['txtKeperluan'];
				$hari = $_POST['txtHari'];
				$tanggal = $_POST['txtTanggal'];
				$waktu = $_POST['txtWaktu'];
				$tempat = $_POST['txtTempat'];
				$keterangan = $_POST['txtKeterangan'];
				$ttd = $_POST['cboTTD'];

				if($getStugas){
					$query = mysqli_query($koneksi," UPDATE surat_tugas SET kd_s_tugas='$kode', keperluan= '$keperluan', hari= '$hari', tanggal='$tanggal',waktu='$waktu',tempat='$tempat', keterangan='$keterangan', ttd='$ttd' WHERE id_s_masuk ='$idsurat' ");
				} else {
					$query = mysqli_query($koneksi,"INSERT INTO surat_tugas VALUES(0,'$idsurat','$kode','$keperluan','$hari','$tanggal','$waktu','$tempat','$keterangan','$ttd')");
				}

				if ($query) {
					echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Surat Tugas Sudah Disimpan, Silahkan Cetak!</strong> Tunggu...
							</div>";
					echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_proses&kd=$idsurat'>";
				}

			}
		
		?>

		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Proses Surat Masuk</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">

					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i>
									Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
							<!-- <li>
								<a href="#recent11" data-toggle="tab" class="text-center">Surat Tugas</a>
							</li> -->
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Pengirim</b></td>
											<?php if($data['nama_unit']=='Lainnya'){ ?>
											<td><?php echo $data['pengirim_eks'] ?></td>
											<?php }else{ ?>
											<td><?php echo $data['nama_unit'] ?></td>
											<?php } ?>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Terima</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Ditujukan Kepada</b></td>
											<td><?php echo $pimpinan;?> [<?php echo $data['nip'];?>]</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>No Agenda</b></td>
											<td><?php echo $data['no_agenda'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Pegawai yang ditugaskan</b></td>
											<td>
												<?php 
													$getpgw = mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk dsm INNER JOIN pgw p ON dsm.id_pgw = p.id_pgw WHERE dsm.id_s_masuk = '$_GET[kd]' AND status ='1' ");
													while ($dpgw = mysqli_fetch_assoc($getpgw)) {
												?>
												<p><b><?php echo $dpgw['gelar_depan']." ".$dpgw['nama'].", ".$dpgw['gelar_belakang'] ?></b> <?php if($getStugas){?> <a href="surat_tugas.php?id=<?php echo $getStugas['id_s_masuk'] ?>&pgw=<?php echo $dpgw['id_pgw'] ?>&ttd=<?php echo $getStugas['ttd'] ?>" target='_blank' class="btn btn-sm btn-info">Cetak Surat Tugas</a> <?php ;} ?> </p> 
												<?php
													}
												?>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanda Tangan Dari</b></td>
											<td>
												<select style="width:500px;" name="cboTTD" class="form-control">
													<option> Pilih TTD </option>
													<?php 
														$q = mysqli_query($koneksi,"SELECT * FROM pimpinan");
														while ($dp = mysqli_fetch_array($q)) {
													?>
													<option value="<?php echo $dp['id_pimpinan'] ?>" <?php if($getStugas['ttd']==$dp['id_pimpinan']){echo"SELECTED";} ?> > <?php echo $dp['gelar_depan']." ".$dp['nama'].", ".$dp['gelar_belakang']." [".$dp['jabatan_struktural']."]" ?> </option>
													<?php
														}
													?>
												</select>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat Tugas</b></td>
											<td>
												<input value="<?php echo $vKode; ?>" name="txtKode" type="text" style="width:500px;" class="form-control">
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Keperluan</b></td>
											<td>
												<textarea name="txtKeperluan" class="form-control" rows="3" ><?php echo $vKeperluan; ?></textarea>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Hari</b></td>
											<td>
												<input value="<?php echo $vHari; ?>" name="txtHari" type="text" style="width:500px;" class="form-control">
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal</b></td>
											<td>
												<input value="<?php echo $vTanggal; ?>" name="txtTanggal" type="text" style="width:500px;" class="form-control">
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Waktu</b></td>
											<td>
												<input value="<?php echo $vWaktu; ?>" name="txtWaktu" type="text" style="width:500px;" class="form-control">
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tempat</b></td>
											<td>
												<textarea name="txtTempat" class="form-control" rows="3" ><?php echo $vTempat; ?></textarea>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Keterangan</b></td>
											<td>
												<textarea name="txtKeterangan" class="form-control" rows="3" ><?php echo $vKeterangan; ?></textarea>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
							<!-- <div id="recent11" class="tab-pane">
								<div id="example2"></div>
							</div> -->
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<a href="?v=s_masuk_daftar&id=<?php echo $data['id_kode'] ?>" class="btn btn-default">Kembali</a>
					<?php 
						if(!$getBau){
					?>
					<button name="btnSimpan" type="submit" class="btn btn-success" style="float:right">Simpan</button>
					<?php		
						}
					?>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>
	PDFObject.embed("../../File/SuratMasuk/<?php echo $surat ?>#toolbar=0", "#example1");
</script>
<!-- <script>PDFObject.embed("../../File/Surat Tugas/<?php echo $suratTugas ?>#toolbar=1", "#example2");</script> -->

<style>
	.pdfobject-container {
		height: 90rem;
		border: 0.4rem solid rgba(0, 0, 0, .1);
	}
</style>

<script>
	function hanyaAngka(evt) {
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))

			return false;
		return true;
	}

	function yesnoCheck() {
		if (document.getElementById('radioExample2').checked) {
			document.getElementById('disposisi').style.display = 'block';
			document.getElementById('listdispo').style.display = 'block';
		} else if (document.getElementById('radioExample1').checked) {
			document.getElementById('disposisi').style.display = 'none';
			document.getElementById('listdispo').style.display = 'none';
		}
	}
</script>