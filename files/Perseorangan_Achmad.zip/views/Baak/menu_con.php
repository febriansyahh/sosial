<?php
if(isset($_GET['v'])) {
	switch ($_GET['v']) {
			
			case 'beranda' :
			require_once "beranda.php";
			break;

			case 'user' :
			require_once "user.php";
			break;

			case 'pimpinan' :
			require_once "pimpinan.php";
			break;

			case 'pimpinan_tambah' :
			require_once "pimpinan_tambah.php";
			break;

			case 'pimpinan_ubah' :
			require_once "pimpinan_ubah.php";
			break;

			case 'user_tambah' :
			require_once "user_tambah.php";
			break;

			case 'user_ubah' :
			require_once "user_ubah.php";
			break;

			case 'pegawai' :
			require_once "pegawai.php";
			break;

			case 'pegawai_tambah' :
			require_once "pegawai_tambah.php";
			break;

			case 'pegawai_ubah' :
			require_once "pegawai_ubah.php";
			break;

			case 'grup' :
			require_once "grup.php";
			break;

			case 'grup_tambah' :
			require_once "grup_tambah.php";
			break;

			case 'grup_ubah' :
			require_once "grup_ubah.php";
			break;

			case 'grup_daftar' :
			require_once "grup_daftar.php";
			break;

			case 'agenda' :
			require_once "agenda.php";
			break;

			case 'agenda_tambah' :
			require_once "agenda_tambah.php";
			break;

			case 'agenda_hadir' :
			require_once "agenda_hadir.php";
			break;

			case 'agenda_ubah' :
			require_once "agenda_ubah.php";
			break;

			case 'agenda_detail' :
			require_once "agenda_detail.php";
			break;

			case 'agenda_notif' :
			require_once "agenda_notif.php";
			break;

			case 'agenda_notif_tambah' :
			require_once "agenda_notif_tambah.php";
			break;

			case 'agenda_notif_ubah' :
			require_once "agenda_notif_ubah.php";
			break;

			case 'agenda_notif_detail' :
			require_once "agenda_notif_detail.php";
			break;

			case 'kode' :
			require_once "kode.php";
			break;

			case 'kode_tambah' :
			require_once "kode_tambah.php";
			break;

			case 'kode_ubah' :
			require_once "kode_ubah.php";
			break;

			case 'unit' :
			require_once "unit.php";
			break;

			case 'unit_tambah' :
			require_once "unit_tambah.php";
			break;

			case 'unit_daftar' :
			require_once "unit_daftar.php";
			break;

			case 'unit_ubah' :
			require_once "unit_ubah.php";
			break;

			case 's_keluar' :
			require_once "s_keluar.php";
			break;

			case 's_keluar_daftar' :
			require_once "s_keluar_daftar.php";
			break;

			case 's_keluar_tambah' :
			require_once "s_keluar_tambah.php";
			break;

			case 's_keluar_ubah' :
			require_once "s_keluar_ubah.php";
			break;

			case 's_keluar_detail' :
			require_once "s_keluar_detail.php";
			break;

			case 's_masuk' :
			require_once "s_masuk.php";
			break;

			case 's_masuk_daftar' :
			require_once "s_masuk_daftar.php";
			break;

			case 's_masuk_tambah' :
			require_once "s_masuk_tambah.php";
			break;

			case 's_masuk_proses' :
			require_once "s_masuk_proses.php";
			break;

			case 's_masuk_ubah' :
			require_once "s_masuk_ubah.php";
			break;

			case 's_masuk_detail' :
			require_once "s_masuk_detail.php";
			break;

			case 's_masuk_dispo' :
			require_once "s_masuk_dispo.php";
			break;

			case 's_masuk_dispo_tambah' :
			require_once "s_masuk_dispo_tambah.php";
			break;

			case 's_masuk_dispo_ubah' :
			require_once "s_masuk_dispo_ubah.php";
			break;

			case 'lap_s_masuk' :
			require_once "lap_s_masuk.php";
			break;

			case 'lap_s_keluar' :
			require_once "lap_s_keluar.php";
			break;

			case 'lap_dispo' :
			require_once "lap_dispo.php";
			break;

			case 'pencarian' :
			require_once "pencarian.php";
			break;

		}
}else{
	require_once "beranda.php";
}
?>