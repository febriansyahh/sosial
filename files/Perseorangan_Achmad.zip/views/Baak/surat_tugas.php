<?php
	include "../../koneksi.php";
	// $tglAwal=date("Y/m/d", strtotime($_POST['start']));
	// $tglAkhir=date("Y/m/d", strtotime($_POST['end']));
	
	// //Tanggal Sekarang
	// date_default_timezone_set('Asia/Jakarta');
	// $tanggal= mktime(date('m'),date('d'),date('Y'));
	// $tglsekarang = date('Y-m-d', $tanggal);
	// $thnsekarang = date('Y', $tanggal);

	function tanggal_indo($tanggal)
    {
        $bulan = array (1 =>   'Januari',
                    'Februari',
                    'Maret',
                    'April',
                    'Mei',
                    'Juni',
                    'Juli',
                    'Agustus',
                    'September',
                    'Oktober',
                    'November',
                    'Desember'
                );

        return $bulan[ (int)$tanggal ];
    }

	$tgl = date("d");
	$bln = tanggal_indo(date('m'));
	$thn = date("Y");

	$getStugas = mysqli_fetch_assoc(mysqli_query($koneksi,"SELECT * FROM surat_tugas WHERE id_s_masuk ='$_GET[id]' "));
	$getPgw = mysqli_fetch_assoc(mysqli_query($koneksi,"SELECT * FROM pgw WHERE id_pgw ='$_GET[pgw]' "));
	$getPimp = mysqli_fetch_assoc(mysqli_query($koneksi,"SELECT * FROM pimpinan WHERE id_pimpinan ='$_GET[ttd]' "));

	?>

<!DOCTYPE html>
<html lang="en">
    <head>
    	<title>Laporan Surat Keluar</title>
		<style>
			body {
			   font-family: Tahoma;
			   font-size: 11px;
			}

			h1, h2, h3, h4, h5, h6 {
			   padding: 2px 0px;
			   margin: 0px;
			}

			h1 {
			   font-size: 15pt;
			}

			h2 {
			   font-size: 13pt;
			   font-family: "Times New Roman";
			}

			h3 {
			   font-size: 11pt;
			}

			h4 {
			   font-size: 9pt;
			}

			hr {
			   clear: both;
			}

			img {
			   margin: 2px;
			}

			.center {
			   text-align: center;
			}

			.th_cust {
			   border: 1px solid #000;
			}

			div.page-portrait {
			   visibility: visible;
			   font-family: Tahoma;
			   font-size: 11px;
			   margin: 0 auto;
			   width: 19.1cm;
			}

			div.page-landscape {
			   visibility: visible;
			   font-family: Tahoma;
			   font-size: 11px;
			   margin: 0 auto;
			   width: 25.5cm;
			}

			table {
			   border-collapse: collapse;
			}

			.box {
			   border: 1px solid #ccc;
			   padding: 4px;
			}

			table tr td {
			   font-family: "Times New Roman";
			   font-size: 13px;
			   padding: 4px 4px 2px 4px;
			}

			.cst {
				padding: 0px;
			}

			table tr th {
			   font-family: "Times New Roman";
			   font-size: 15px;
			   font-weight: bold;
			   background-color: #fff;
			   padding: 4px;
			}

			.tabel-common tr td {
			   font-family: Tahoma;
			   font-size: 11px;
			   padding: 0px 2px 0px 2px;
			   border: 1px solid #000;
			   vertical-align: top;
			}

			.tabel-common .nama {
			   width: 250px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .ttd {
			  
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .nomor {
			   width: 20px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .tanda {
			   width: 50px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common .nim {
			   width: 80px;
			   overflow: hidden;
			   padding: 7px 5px 7px 5px;
			}

			.tabel-common tr th {
			   font-family: Tahoma;
			   font-size: 11px;
			   font-weight: bold;
			   background-color: #fff;
			   padding: 2px;
			   border: 1px solid #000;
			}

			.incommon-separator {
			   border-top: 1px solid #fff !important;
			   border-left: 1px solid #fff !important;
			   border-right: 1px solid #fff !important;
			   border-bottom: 1px solid #ccc !important;
			}

			.incommon-noseparator {
			   border: 1px solid #fff !important;
			}

			.bottom-separator {
			   border-bottom: 1px solid #ccc !important;
			}

			.tabel-info tr td, th {
			   font-family: Tahoma;
			   font-size: 11px;
			   padding: 2px;
			   font-weight: bold;
			}

			div.nobreak .hidden {
			   visibility: hidden;
			   display: none;
			}

			div.page-break .hidden {
			   visibility: visible;
			   margin: 10px 0px 10px 0px;
			}

			.page-break {
			   clear: both;
			}

			.link {
			   clear:both;
			   visibility: visible;
			}

			.alamat {
			  font-family: "Times New Roman", Helvetica, sans-serif;
			  font-size: 16px;
			}
			.yayasan {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 32px; }
			.univ {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 18px; }
			.fakultas {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 14px; }
			.label {font-family: "Times New Roman", Helvetica, sans-serif; font-size: 10px; }


			#header .separatorAlamat{
			   background-color:#5C74B0;
			   color:#fff;
			   height:40px;
			   font-size: 13px;
			}
		</style>
	</head>
	<!-- <body onLoad="window.print();"> -->
	<body>
		<div class="page-portrait">
			<div class="page-break">
				<table style="border-collapse: collapse; line-height: 1.7em;" width="100%">
					<tbody>
						<tr>
							<td style="border-bottom:2px solid #000000;" valign="left" align="center" width="90">
								<!-- <img src="assets/images/LOGOUMK-hitam-putih.png" width="120" height="120" style="padding:0px;"> -->
								<img src="logohp.png" width="120" height="120" style="padding:0px;">
							</td>
							<td colspan="3" style="border-bottom:2px solid #000000; padding-top: 0px; padding-right: 50px;" valign="middle" >
								<center><span class="univ"><strong>YAYASAN PEMBINA UNIVERSITAS MURIA KUDUS</strong></span><br>
								<center><span class="yayasan"><strong>UNIVERSITAS MURIA KUDUS</strong></span><br>
								<span class="alamat">Gondangmanis, Bae PO. BOX : 53 Telp : (0291) 438229 Fax : (0291) 437198<br></span>
								<span class="alamat">E-mail: muria@umk.ac.id http ://www.umk.ac.id<br></span>
								<span class="alamat">KUDUS 59352<br></span></center>
							</td>
						</tr>
						<tr>
							<td colspan="4">
								<span class="univ"></span>
							</td>
						</tr>
					</tbody>
		        </table><br>
		        <h2 align="center">S U R A T - T U G A S</h2><br>
		        <hr style="border: solid 0.5px #000; width: 250px; margin-top: -7px; margin-bottom: 10px;">
		        <span style="font-family: Times New Roman; font-size: 15px;"><center><?php echo $getStugas['kd_s_tugas'] ?></center></span>
		        <br /><br>
		        <table style="border-collapse: collapse; border-width: 2px; text-align: justify;" width="100%">
		        	<tbody>
		        		<tr>
		        			<td width="45"></td>
		        			<td colspan="3" style="padding: 4px 4px 10px 4px;">Rektor Universitas Muria Kudus menugaskan :</td>
		        			<td width="55"></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Nama</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getPgw['gelar_depan']." ".$getPgw['nama'].", ".$getPgw['gelar_belakang']; ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">NIS</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getPgw['nip'] ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Pangkat/Golongan</td>
		        			<td width="5">:</td>
		        			<td> <?php if($getPgw['pangkat']){echo$getPgw['pangkat'];} else{echo "-";} ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Jabatan</td>
		        			<td width="5">:</td>
		        			<td> <?php if($getPgw['jabatan_fungsional']){echo$getPgw['jabatan_fungsional'];} else{echo "-";} ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Unit Organisasi</td>
		        			<td width="5">:</td>
		        			<td> Universitas Muria Kudus</td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Keperluan</td>
		        			<td width="5">:</td>
		        			<td valign="top"> <?php echo $getStugas['keperluan'] ?> </td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Hari</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getStugas['hari'] ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Tanggal</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getStugas['tanggal'] ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Waktu</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getStugas['waktu'] ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Tempat</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getStugas['tempat'] ?></td>
		        			<td></td>
		        		</tr>
		        		<tr>
		        			<td></td>
		        			<td width="115">Keterangan</td>
		        			<td width="5">:</td>
		        			<td> <?php echo $getStugas['keterangan'] ?> </td>
		        			<td></td>
		        		</tr>

		        		<tr>
		        			<td width="45"></td>
		        			<td colspan="3" style="padding: 24px 4px 10px 4px;">Harap dilaksanakan dengan sebaik-baiknya dan menyampaikan laporan setelah melaksanakan tugas.</td>
		        			<td width="55"></td>
		        		</tr>
		        	</tbody>
		        </table>
		        <br><br>
		        <table style="border-collapse: collapse; border-width: 2px;" width="100%">
		        	<tbody>
		        		<tr>
		        			<td class="cst" width="45"></td>
		        			<td class="cst"></td>
		        			<td class="cst" width="150"></td>
		        			<td class="cst">Kudus, <?php echo $tgl." ".$bln." ".$thn  ?></td>
		        			<td class="cst" width="55"></td>
		        		</tr>
		        		<tr>
		        			<td class="cst" width="45"></td>
		        			<td class="cst">Cap/Tanda tangan Instansian</td>
		        			<td class="cst"></td>
		        			<td class="cst"><?php if($getPimp['jabatan_struktural']!='Rektor'){echo "an. Rektor";} else{echo"Rektor";} ?></td>
		        			<td class="cst" width="55"></td>
		        		</tr>
		        		<tr>
		        			<td class="cst" width="45"></td>
		        			<td class="cst" style="padding-bottom: 80px;">yang dituju</td>
		        			<td class="cst"></td>
		        			<td class="cst" style="padding-bottom: 80px;"><?php if($getPimp['jabatan_struktural']!='Rektor'){echo $getPimp['jabatan_struktural'];} else{echo"Universitas Muria Kudus";} ?>,</td>
		        			<td class="cst" width="55"></td>
		        		</tr>
		        		<tr>
		        			<td class="cst" width="45"></td>
		        			<td class="cst">.............................................</td>
		        			<td class="cst"></td>
		        			<td class="cst"><b><?php echo $getPimp['gelar_depan']." ".$getPimp['nama'].", ".$getPimp['gelar_belakang'] ?></b></td>
		        			<td class="cst" width="55"></td>
		        		</tr>
		        		<tr>
		        			<td class="cst" width="45"></td>
		        			<td class="cst"></td>
		        			<td class="cst"></td>
		        			<td class="cst">NIS. <?php echo $getPimp['nip'] ?></td>
		        			<td class="cst" width="55"></td>
		        		</tr>
		        	</tbody>
		        </table>
		    </div>
		</div>
	</body>
</html>