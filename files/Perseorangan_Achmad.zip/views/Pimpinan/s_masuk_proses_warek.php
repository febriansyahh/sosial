<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Proses</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			include "function.php";

            $datapegawai = getPegawai();

            require '../../PHPMailer/PHPMailerAutoload.php';
			$mail = new PHPMailer;

			// $data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk inner join unit on unit.id_unit=surat_masuk.id_unit inner join pegawai on pegawai.id_pegawai=surat_masuk.id_pegawai where id_s_masuk='$_GET[kd]'"));
			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk inner join unit on unit.id_unit=surat_masuk.id_unit inner join pimpinan on pimpinan.id_pimpinan=surat_masuk.id_pimpinan where id_s_masuk='$_GET[kd]'"));
			$userinfo = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan INNER JOIN user ON user.id_pimpinan = pimpinan.id_pimpinan inner join pgw on pgw.nip=pimpinan.nip WHERE user.username = '$username' "));
			$getinfodispo = mysqli_fetch_array(mysqli_query($koneksi,"SELECT *from dispo_s_masuk where id_s_masuk='$data[id_s_masuk]' and id_pgw='$userinfo[id_pgw]'"));
			$dataz = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE id_pgw = '$getinfodispo[pemberi]' "));			
			$surat=$data['scan_s_masuk'];
			$suratTugas=$data['surat_tugas'];
			$idsurat=$data['id_s_masuk'];
			$iddispo = $getinfodispo['id_dispo'];
			
			if(isset($_POST['btnSimpan'])){

				if($_POST['rbStatus']=='1'){
					$sql_update = "UPDATE dispo_s_masuk SET
						status ='".$_POST['rbStatus']."',
						info_pemberi_dispo='".$_POST['txtInfo']."'
						WHERE id_dispo='".$iddispo."'";
					// var_dump($sql_update);exit();
		        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        	$sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$_GET['kd']."' AND pemberi = '".$userinfo['id_pgw']."' ";
					$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
				}else{

					$imp= implode("~ ", $_POST['cboTujuan']);
                    $exp= explode("~ ", $imp);
                    $count = count($exp);

					$sql_update = "UPDATE dispo_s_masuk SET
						status ='".$_POST['rbStatus']."',
						info_pemberi_dispo='".$_POST['txtInfo']."'
						WHERE id_dispo='".$iddispo."'";
					// var_dump($sql_update);
		        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        	if($_POST['cboTujuan'] != ''){
						$sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$_GET['kd']."' AND pemberi = '".$userinfo['id_pgw']."' ";
						$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());


                        $mail->isSMTP();                                     
                        $mail->Host = 'smtp.gmail.com';  
                        $mail->SMTPAuth = true;                      
                        $mail->Username = 'ardi.irfanto@umk.ac.id';        
                        $mail->Password = 'Regenerator';                         
                        $mail->SMTPSecure = 'tls';                           
                        $mail->Port = 587;                                   
                        $mail->setFrom('ardi.irfanto@umk.ac.id', 'Sistem Disposisi Surat Rektorat UMK');
                        $mail->smtpConnect(
                            array(
                                "ssl" => array(
                                    "verify_peer" => false,
                                    "verify_peer_name" => false,
                                    "allow_self_signed" => true
                                )
                            )
                        );

                        for($x=0;$x<$count;$x++){
                            $arrKeSave = explode('*',$exp[$x]);
                            $unit=$arrKeSave[0];
                            if($unit=='U'){
                            	$idunit=$unit=$arrKeSave[1];
                            	$gt_unit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from unit where id_unit='$idunit'"));
                            	// var_dump($gt_unit);
                            	// exit();
                            	mysqli_query($koneksi,"INSERT INTO dispo_s_masuk(id_s_masuk,id_pgw,unit,informasi,tgl_dispo,pemberi,status) 
	                                values('$idsurat','$gt_unit[id_unit][$x]','1','$_POST[txtInfo]',NOW(),'$userinfo[id_pgw]','2')");
	                            $email = $gt_unit['email'];

	                            $mail->Subject = 'Pemberitahuan Disposisi';
	                            $mail->Body    = "<div class='card' style='margin:50px;'>
	                                                <div class='card-header'>
	                                                    <h5 align='center'>Pemberitahuan Disposisi</h5>
	                                                </div>
	                                                <div class='card-body'>
	                                                    <div class='alert alert-success alert-bordered'>
	                                                        <p> <b> Berikut adalah Detail Disposisi: </b> </p>
	                                                        <p> Pemberi Disposisi      			:". $userinfo['gelar_depan']."".$userinfo['nama'].",". $userinfo['gelar_belakang'] ." </p>
	                                                        <p> Disposisi ditujukan kepada      :". $gt_unit['nama_unit']." </p>
	                                                        <p> Instruksi/Informasi     		:". $_POST['txtInfo'] ." </p>
	                                                        <hr>
	                                                        <p> Download File Surat Masuk       : <a href='localhost/disposisi2/File/SuratMasuk/". $data['scan_s_masuk'] ."'> Download </a> </p>
	                                                        <p> Untuk Ketersediaan terkait bisa/tidak silahkan menghubungi Admin Rektorat. Terima Kasih</p>
	                                                    </div>
	                                                </div>
	                                            </div>";
	                            $mail->AltBody = '----------------------------------------------';

	                            $mail->addAddress('higan.nanda@umk.ac.id','1');													
	                            $mail->isHTML(true);
	                            $mail->send();
	                            $mail->ClearAddresses();
                            }else{
                            	$arrKeNIP = $arrKeSave[0];
	                            $arrKeNama = $arrKeSave[1];
	                            $arrKeGdepan = $arrKeSave[2];
	                            $arrKeGblkg = $arrKeSave[3];
	                            $arrKeEmail = $arrKeSave[4];
	                            $arrKeJfung = $arrKeSave[5];
	                            $arrKeJStruk = $arrKeSave[6];
	                            $arrKePangkat = $arrKeSave[7];


	                            $getKe = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama ='$arrKeNama' "));

	                            if($getKe){
	                                $updateKe = mysqli_query($koneksi,"UPDATE pgw SET
	                                    nip = '$arrKeNIP',
	                                    nama = '$arrKeNama',
	                                    gelar_depan = '$arrKeGdepan',
	                                    gelar_belakang = '$arrKeGblkg',
	                                    email = '$arrKeEmail',
	                                    jabatan_fungsional = '$arrKeJfung',
	                                    jabatan_struktural = '$arrKeJStruk',
	                                    pangkat = '$arrKePangkat'
	                                    WHERE id_pgw = '$getKe[id_pgw]'"
	                                );
	                                $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama = '$arrKeNama' "));
	                            } else {
	                                $insertKe = mysqli_query($koneksi, "INSERT INTO pgw(nip,nama,gelar_depan,gelar_belakang,email,jabatan_fungsional,jabatan_struktural,pangkat)
	                                    VALUES ('$arrKeNIP','$arrKeNama','$arrKeGdepan','$arrKeGblkg','$arrKeEmail',
	                                        '$arrKeJfung','$arrKeJStruk','$arrKePangkat');
	                                ");
	                                $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw ORDER BY id_pgw DESC LIMIT 1 "));
	                            }

	                            mysqli_query($koneksi,"INSERT INTO dispo_s_masuk(id_s_masuk,id_pgw,informasi,tgl_dispo,pemberi,status) 
	                                values('$idsurat','$getKe2[id_pgw][$x]','$_POST[txtInfo]',NOW(),'$userinfo[id_pgw]','2')");
	                            $email = $getKe2['email'];

	                            $mail->Subject = 'Pemberitahuan Disposisi';
	                            $mail->Body    = "<div class='card' style='margin:50px;'>
	                                                <div class='card-header'>
	                                                    <h5 align='center'>Pemberitahuan Disposisi</h5>
	                                                </div>
	                                                <div class='card-body'>
	                                                    <div class='alert alert-success alert-bordered'>
	                                                        <p> <b> Berikut adalah Detail Disposisi: </b> </p>
	                                                        <p> Pemberi Disposisi      			:". $userinfo['gelar_depan']."".$userinfo['nama'].",". $userinfo['gelar_belakang'] ." </p>
	                                                        <p> Disposisi ditujukan kepada      :". $getKe2['gelar_depan']."".$getKe2['nama'].",". $getKe2['gelar_belakang'] ." </p>
	                                                        <p> Instruksi/Informasi     		:". $_POST['txtInfo'] ." </p>
	                                                        <hr>
	                                                        <p> Download File Surat Masuk       : <a href='localhost/disposisi2/File/SuratMasuk/". $data['scan_s_masuk'] ."'> Download </a> </p>
	                                                        <p> Untuk Ketersediaan terkait bisa/tidak silahkan menghubungi Admin Rektorat. Terima Kasih</p>
	                                                    </div>
	                                                </div>
	                                            </div>";
	                            $mail->AltBody = '----------------------------------------------';

	                            $mail->addAddress('higan.nanda@umk.ac.id','1');													
	                            $mail->isHTML(true);
	                            $mail->send();
	                            $mail->ClearAddresses();
                            }

                            // exit();
                            
                        }
                        
		        	}
				}

	        	if ($query_update) {
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_daftar&id=$data[id_kode]'>";
		        	}
			}

		?>

		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Proses Surat Masuk </h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">

					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i>
									Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
							<!-- <li>
								<a href="#recent11" data-toggle="tab" class="text-center">Surat Tugas</a>
							</li> -->
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<!-- Table Warek -->
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Pengirim</b></td>
											<?php if($data['nama_unit']=='Lainnya'){ ?>
											<td><?php echo $data['pengirim_eks'] ?></td>
											<?php }else{ ?>
											<td><?php echo $data['nama_unit'] ?></td>
											<?php } ?>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Terima</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Ditujukan Kepada</b></td>
											<td><?php echo $data['gelar_depan'].".".$data['nama'].",".$data['gelar_belakang'];?> [<?php echo $data['nip'];?>]</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>No Agenda</b></td>
											<td><?php echo $data['no_agenda'] ?></td>
										</tr>
										<?php 
											if($username !='rektor'){
												$getdispo = mysqli_fetch_array(mysqli_query($koneksi,"SELECT *from dispo_s_masuk where id_s_masuk='$data[id_s_masuk]' and id_pgw='$userinfo[id_pgw]'"));
												$ds = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE id_pgw = '$getdispo[pemberi]' "));
												// var_dump("SELECT * FROM pgw WHERE id_pgw = '$getdispo[pemberi]'");
										?>
										<tr class="gradeX">
											<td width="170"><b>Disposisi Dari</b></td>
											<td>
												<?php
													echo "<b> ".$ds['gelar_depan'].". ".$ds['nama'].", ".$ds['gelar_belakang']." </b>";
												?>
											</td>
										</tr>
										<?php
										if($data['status_s_masuk']=='0'){
											$dt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from dispo_s_masuk where id_s_masuk='$data[id_s_masuk]'"));
										?>
										<tr class="gradeX">
											<td width="170"><b>Disposisi ke</b></td>
											<td>
												<ul>
													<?php
														$qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk 
														inner join pgw on pgw.id_pgw=dispo_s_masuk.id_pgw
														where id_s_masuk='$data[id_s_masuk]' and pemberi = '$getdispo[pemberi]' ");
														while($dta = mysqli_fetch_array($qr)){
															$st = '';
															if($dta['status']=='1'){
																$st = 'Bisa';
															} else if($dta['status']=='0'){
																$st='Tidak Bisa';
															} else {
																$st='Belum Konfirmasi';
															}
						                			?>
													<li>
														<b><?php echo $dta['gelar_depan']." ".$dta['nama'].",".$dta['gelar_belakang'] ?> </b>
														(<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>) - <?php echo $st ?>
													</li>
													<p> - Instruksi/Informasi :  <?php echo $dta['informasi'] ?></p>
													<?php
														}
													?>
												</ul>
											</td>
										</tr>
										<?php
											}
										?>
										<tr class="gradeX">
											<td width="170"><b>Instruksi/Informasi</b></td>
											<td>
												<?php
													echo $getdispo['informasi'];
												?>
											</td>
										</tr>
										<?php
											}
										?>
										<tr class="gradeX">
											<td width="170" colspan="2" style="font-size: 15px; color:red;">
												<b>PROSES DISPOSISI</b></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Aksi</b></td>
											<td>
												<div class="col-md-4">
													<div class="radio-custom">
														<input type="radio" id="radioExample1"
															onclick="javascript:yesnoCheck();" name="rbStatus" value="1"
															<?php if($getinfodispo['status']=='1'){echo "checked";} ?>>
														<label for="radioExample1">OK</label>
													</div>
												</div>
												<div class="col-md-4">
													<div class="radio-custom">
														<input type="radio" id="radioExample2"
															onclick="javascript:yesnoCheck();" name="rbStatus" value="0"
															<?php if($getinfodispo['status']=='0'){echo "checked";} ?>>
														<label for="radioExample1">Disposisi</label>
													</div>
												</div>
												<?php
													if($getinfodispo['status']=='0'){
												?>
												<div class="col-md-7" id="disposisi" style="display: block;">
													<?php
													}else{
												?>
													<div class="col-md-12" id="disposisi" style="display: none;">
														<?php
													}
												?>
														<br>
														<?php
														if($getinfodispo['status']=='0'){
													?>
														<label>Ubah disposisi:</label>
														<?php
														}else{
													?>
														<label>Disposisi ke:</label>
														<?php
														}
													?>

														<select multiple data-plugin-selectTwo class="form-control populate" name="cboTujuan[]">
			                                                <option>*Pilih</option>
			                                                <?php
																	
																	$qryDituju = mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.level='1' order by b.nama_unit,a.nama_unit asc");
																	while($dtDituju = mysqli_fetch_array($qryDituju)){
																		if($dtDituju['nama2']!=null){
																			$unitt=$dtDituju['nama2'];
																		}
																?>
																	<option value="U*<?php echo $dtDituju['id_unit'] ?>"> <?php echo $dtDituju['nama1'] ?></option>
																<?php
																	}
																?>
			                                                <?php
			                                                    foreach ($datapegawai as $key => $val) {
			                                                        $value = $val['nip']."*".
			                                                                $val['nama']."*".
			                                                                $val['gelar_depan']."*".
			                                                                $val['gelar_belakang']."*".
			                                                                $val['email']."*".
			                                                                $val['jabatan_fungsional']."*".
			                                                                $val['jabatan_struktural']."*".
			                                                                $val['pangkat'];
			                                                        echo "<option value='$value' > $val[gelar_depan] $val[nama], $val[gelar_belakang] [$val[nip]] </option>";
			                                                    }
										                    ?>
			                                            </select>
														<small>*) Kosongi bila disposisi tidak diubah</small>
													</div>
													<?php
														if($getinfodispo['status']=='0'){
													?>
													<div class="col-md-5" id="listdispo" style="top: 20px;margin-bottom:20px">
														<b>Disposisi Ke : </b>
														<ul>
															<?php
																$qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk dsm where dsm.id_s_masuk='$data[id_s_masuk]' and dsm.pemberi='$userinfo[id_pgw]'");
																while($dta = mysqli_fetch_array($qr)){
																	if($dta['unit']=='0'){
																			$pgw=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pgw where id_pgw=$dta[id_pgw]"));
													        ?>
															<li>
																<b><?php echo $pgw['gelar_depan']." ".$pgw['nama'].",".$pgw['gelar_belakang'] ?> </b>
																(<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>) - <?php echo $st ?>
															</li>
															<?php
								                				}else{
								                					$unt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from unit where id_unit=$dta[id_pgw]"));
								                			?>
								                				<li>
																	<b><?php echo $unt['nama_unit'] ?> </b>
																	(<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>)
																</li>
															<?php
															}
														?>
														</ul>
													</div>
													<?php
														}}
													?>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Instruksi/Informasi</b></td>
											<td>
												<textarea class="form-control" rows="3" id="textareaAutosize"
													name="txtInfo"
													data-plugin-textarea-autosize><?php echo $getinfodispo['info_pemberi_dispo'] ?></textarea>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
							<!-- <div id="recent11" class="tab-pane">
								<div id="example2"></div>
							</div> -->
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan</button>
					<a href="Javascript:window.history.back()" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>
	PDFObject.embed("../../File/SuratMasuk/<?php echo $surat ?>#toolbar=0", "#example1");
</script>
<!-- <script>PDFObject.embed("../../File/Surat Tugas/<?php echo $suratTugas ?>#toolbar=1", "#example2");</script> -->

<style>
	.pdfobject-container {
		height: 90rem;
		border: 0.4rem solid rgba(0, 0, 0, .1);
	}
</style>

<script>
	function hanyaAngka(evt) {
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))

			return false;
		return true;
	}

	function yesnoCheck() {
		if (document.getElementById('radioExample2').checked) {
			document.getElementById('disposisi').style.display = 'block';
			document.getElementById('listdispo').style.display = 'block';
		} else if (document.getElementById('radioExample1').checked) {
			document.getElementById('disposisi').style.display = 'none';
			document.getElementById('listdispo').style.display = 'none';
		}
	}
</script>