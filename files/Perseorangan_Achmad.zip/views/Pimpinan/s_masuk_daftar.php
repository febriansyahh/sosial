<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Daftar</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php
	
	$getKD=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from kode_surat where id_kode='$_GET[id]'"));

	if(isset($_GET['kd'])){
		if (!$_GET['kd']=="") { 

			$sql_hapus = "DELETE FROM surat_masuk WHERE id_s_masuk='".$_GET['kd']."'";
			$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
			if ($query_hapus) {
				echo "<div class='alert alert-primary'>
						<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
						<strong>Hapus Berhasil!</strong> Tunggu...
					  </div>";
				echo "<meta http-equiv='refresh' content='1; url=?v=s_masuk_daftar&id=$_GET[id]'>";
			}
		  }
	}


?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Daftar Surat Masuk "<?php echo $getKD['nama_kode'] ?>"</h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>No Surat</th>
					<th>Tgl Surat</th>
					<th>Tgl Terima</th>
					<th>Perihal</th>
					<th>Waktu</th>
					<th>Pengirim</th>
					<th width="55"></th>
				</tr>
			</thead>
			<tbody>
				<?php
					$no=1;
					if($username == 'rektor' ){
                    	$query = mysqli_query($koneksi,"SELECT a.id_s_masuk, a.no_s_masuk, a.tgl_s_kirim, a.tgl_s_terima, a.time_s_masuk, a.perihal_s_masuk, a.pengirim_eks, a.id_unit, a.status_s_masuk, c.nama_unit from surat_masuk a 
						inner join kode_surat b on b.id_kode=a.id_kode 
						inner join unit c on c.id_unit=a.id_unit 
						left join unit d on d.parent=c.id_unit 
						where a.id_pimpinan = '$user[id_pimpinan]' 
						and b.parent='$_GET[id]' or b.id_kode='$_GET[id]' 
						order by a.time_s_masuk desc");
					} else {
						// $get = mysqli_fetch_array(mysqli_query($koneksi,"SELECT u.id_unit as id_unit FROM unit u
						// 	INNER JOIN pegawai p ON p.id_pegawai = u.id_pegawai
						// 	INNER JOIN user us ON us.id_pegawai = p.id_pegawai
						// 	WHERE us.username = '$username' "));
						$get = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan INNER JOIN user ON user.id_pimpinan = pimpinan.id_pimpinan inner join pgw on pgw.nip=pimpinan.nip WHERE user.username = '$username'"));

						// var_dump("SELECT * FROM pimpinan INNER JOIN user ON user.id_pimpinan = pimpinan.id_pimpinan WHERE user.username = '$username'");
						$query = mysqli_query($koneksi,"SELECT*from surat_masuk inner join dispo_s_masuk on dispo_s_masuk.id_s_masuk=surat_masuk.id_s_masuk inner join unit on unit.id_unit=surat_masuk.id_unit inner join kode_surat on kode_surat.id_kode=surat_masuk.id_kode
							WHERE id_pgw = '$get[id_pgw]'
							AND surat_masuk.id_kode ='$_GET[id]' and unit='0' OR id_pgw = '$get[id_pgw]'
							AND kode_surat.parent='$_GET[id]' and unit='0'
							ORDER BY surat_masuk.time_s_masuk DESC");
						// var_dump("SELECT*from surat_masuk inner join dispo_s_masuk on dispo_s_masuk.id_s_masuk=surat_masuk.id_s_masuk
						// 	WHERE id_pgw = '$get[id_pgw]'
						// 	AND surat_masuk.id_kode ='$_GET[id]'
						// 	ORDER BY surat_masuk.time_s_masuk DESC");
					}
						while($data = mysqli_fetch_array($query)){
						if($username !='rektor'){
							$getunit = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan INNER JOIN user ON user.id_pimpinan = pimpinan.id_pimpinan inner join pgw on pgw.nip=pimpinan.nip
								WHERE user.username = '$username' "));
							// $getdispo = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk 
							// 	WHERE pemberi = '$getunit[id_unit]' AND id_s_masuk='$data[id_s_masuk]' "));
						}
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td>
						<?php echo $data['no_s_masuk'] ?><br>
						<?php if($username == 'rektor' ) { ?>
							<?php if($data['status_s_masuk']==''){ ?>
								<span class="label label-danger">Belum DiProses</span>
							<?php }else{ ?>
								<span class="label label-success"><i class="fa fa-check"></i> Sudah Diproses</span>
							<?php } ?>
						<?php } else { ?>
							<?php 
								if($data['id_pgw']==$getunit['id_pgw']){
									if($data['status'] =='2' ){
							?>
							<span class="label label-danger">Belum DiProses</span>
							<?php
									} else {
							?>
							<span class="label label-success"><i class="fa fa-check"></i> Sudah Diproses</span>
							<?php
									}
								}	
							?>
						<?php } ?>
					</td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
					<td><?php echo $data['perihal_s_masuk'] ?></td>
					<td>
						<?php echo waktu_lalu($data['time_s_masuk']) ?> 

						<!-- <?php
							if($username=='rektor'){
								if($data['rektor']=='0'){
						?>
								<span class="label label-success">Belum Baca</span>
						<?php
								}
							}elseif($username=='warek1'){
								if($data['wr1']=='0'){
						?>
								<span class="label label-success">Belum Baca</span>
						<?php
								}
							}elseif($username=='warek2'){
								if($data['wr2']=='0'){
						?>
								<span class="label label-success">Belum Baca</span>
						<?php
								}
							}elseif($username=='warek3'){
								if($data['wr3']=='0'){
						?>
								<span class="label label-success">Belum Baca</span>
						<?php
								}
							}elseif($username=='warek4'){
								if($data['wr4']=='0'){
						?>
								<span class="label label-success">Belum Baca</span>
						<?php
								}
							}
						?> -->


					</td>
					<?php if($data['id_unit']=='999'){ ?>
						<td><?php echo $data['pengirim_eks'] ?></td>
					<?php }else{ ?>
						<td><?php echo $data['nama_unit'] ?></td>
					<?php } ?>
					<td>
						<a href="?v=<?php if($username=='rektor') {echo "s_masuk_proses";} else {echo "s_masuk_proses_warek";} ?>&kd=<?php echo $data['id_s_masuk'] ?>" title="Proses" class="btn btn-sm btn-success">Proses</a>
						<a href="?v=s_masuk_detail&kd=<?php echo $data['id_s_masuk'] ?>" title="Detail" class="btn btn-sm btn-info"><i class="fa fa-search-plus"></i></a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>