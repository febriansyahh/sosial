<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
		    if (isset ($_POST ['btnSimpan'])) {

		    	$cekNoSurat=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from surat_masuk where no_s_masuk='$_POST[txtNoSurat]'"));
		    	if($cekNoSurat>0){
		    		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> No Surat <strong>$_POST[txtNoSurat]</strong> sudah dimasukkan.
						  </div>";
		    	}else{

		    		// Menentukan nama File Arsip
		    		$nama2=str_replace('/', '', $_POST['txtNoSurat']);
			        $file_nama = $nama2.".pdf";

			        // Insert ke tabel surat masuk
					$sql_insert = "INSERT INTO surat_masuk (no_s_masuk,perihal_s_masuk,tgl_s_kirim,tgl_s_terima,scan_s_masuk,id_unit,id_kode) VALUES (
	                        '".$_POST ['txtNoSurat']."',
	                        '".$_POST ['txtPerihal']."',
	                        '".date("Y/m/d", strtotime($_POST['txtTglSurat']))."',
	                        '".date("Y/m/d", strtotime($_POST['txtTglTerima']))."',
	                        '".$file_nama."',
	                        '".$_POST ['cboUnit']."',
	                        '".$_POST ['cboKode']."')";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

			        // Get ID surat masuk
			        $getID=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk where no_s_masuk='$_POST[txtNoSurat]'"));
			        $idsurat=$getID['id_s_masuk'];

			        // Insert ke tabel disposisi
			        $sql_insert = "INSERT INTO disposisi_s_masuk (no_agenda,id_s_masuk) VALUES (
			        		'".$_POST ['txtNoAgenda']."',
	                        '".$idsurat."')";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

			  //       // Get ID Disposisi
			  //       $getIDDispo=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from disposisi_s_masuk where id_s_masuk='$idsurat'"));
			  //       $iddispo=$getIDDispo['id_dispo'];

			  //       // Insert ke tabel tujuan disposisi
			  //       $imp= implode(", ", $_POST['cboDispo']);
					// $exp= explode(", ", $imp);
					// $count = count($exp);
					 
					// for($x=0;$x<$count;$x++){
					// 	mysqli_query($koneksi,"INSERT INTO tujuan_dispo(id_unit,id_dispo) values('$exp[$x]','$iddispo')");
					// }

					if ($query_insert) {
						copy($_FILES['File']['tmp_name'],"../../File/Surat Masuk/".$file_nama);
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='1; url=?v=s_masuk'>";
		        	}
		    	}
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			
		</form>
	</div>
</div>

<div class="row">
	<div class="col-xs-12">
		<section class="panel form-wizard" id="w4">
			<form class="form-horizontal" method="POST" enctype="multipart/form-data">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
						<a href="#" class="fa fa-times"></a>
					</div>

					<h2 class="panel-title">Tambah Surat Masuk</h2>
				</header>
				<div class="panel-body">
					<div class="wizard-progress wizard-progress-lg">
						<div class="steps-progress">
							<div class="progress-indicator"></div>
						</div>
						<ul class="wizard-steps">
							<li class="active">
								<a href="#w4-account" data-toggle="tab"><span>1</span>Lengkapi Surat</a>
							</li>
							<li>
								<a href="#w4-confirm" data-toggle="tab"><span>2</span>Upload Arsip</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<div id="w4-account" class="tab-pane active">
							<section class="panel">
								<div class="panel-body">
									<div class="form-group">
										<label class="col-sm-2 control-label">No Surat: </label>
										<div class="col-sm-4">
											<input type="text" class="form-control" name="txtNoSurat" required maxlength="50">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Kode Surat: </label>
										<div class="col-sm-8">
											<select data-plugin-selectTwo class="form-control" required name="cboKode">
												<option>*Pilih</option>
												<?php
					                                $query  = mysqli_query($koneksi, "SELECT*from kode_surat") or die (mysqli_error());
					                                while ($data = mysqli_fetch_array($query))
					                                {         
					                                    echo "<option value='$data[id_kode]'>$data[nama_kode]</option>";
					                                }
					                            ?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Tanggal Surat: </label>
										<div class="col-sm-2">
											<input type="text" name="txtTglSurat" data-plugin-datepicker class="form-control" required autocomplete="off">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Tanggal Terima: </label>
										<div class="col-sm-2">
											<input type="text" name="txtTglTerima" data-plugin-datepicker class="form-control" required autocomplete="off">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Perihal Surat: </label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="txtPerihal" required maxlength="50">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Unit Pengirim: </label>
										<div class="col-sm-8">
											<select data-plugin-selectTwo class="form-control" required name="cboUnit">
												<option>*Pilih</option>
												<?php
					                                $qr  = mysqli_query($koneksi, "SELECT*from unit") or die (mysqli_error());
					                                while ($dt = mysqli_fetch_array($qr))
					                                {         
					                                    echo "<option value='$dt[id_unit]'>$dt[nama_unit]</option>";
					                                }
					                            ?>
											</select>
										</div>
									</div>
								</div>
							</section>
						</div>
						<div id="w4-confirm" class="tab-pane">
							<div class="form-group">
								<label class="col-sm-3 control-label">No Agenda: </label>
								<div class="col-sm-6">
									<input type="text" class="form-control" name="txtNoAgenda" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label" for="w4-email">File Arsip</label>
								<div class="col-sm-9">
									<input type="file" class="form-control" accept=".pdf" name="File" required>
									<small>*) File surat harus bertipe <code>.pdf</code></small>
								</div>
								<button class="btn btn-success" type="submit" name="btnSimpan">Tambah </button><br><br>
							</div>
						</div>
					</div>
				</div>
				<div class="panel-footer">
					<ul class="pager">
						<li class="previous disabled">
							<a><i class="fa fa-angle-left"></i> Sebelumnya</a>
						</li>
						<li class="finish hidden pull-right">
							
						</li>
						<li class="next">
							<a>Selanjutnya <i class="fa fa-angle-right"></i></a>
						</li>
					</ul>
				</div>
			</form>
		</section>
	</div>
</div>