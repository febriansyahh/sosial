<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Proses</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			include "function.php";

            $datapegawai = getPegawai();

			require '../../PHPMailer/PHPMailerAutoload.php';
			$mail = new PHPMailer;

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM surat_masuk sm 
				INNER JOIN pimpinan p ON sm.id_pimpinan = p.id_pimpinan 
				INNER JOIN unit u ON sm.id_unit = u.id_unit 
				where sm.id_s_masuk='$_GET[kd]'"));
			$getKode = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM kode_surat WHERE id_kode='$data[id_kode]'"));

			$pimpinan = $data['gelar_depan'].".".$data['nama'].", ".$data['gelar_belakang'];
			$surat=$data['scan_s_masuk'];
			$suratTugas=$data['surat_tugas'];
			$idsurat=$data['id_s_masuk'];
			$userinfo = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan INNER JOIN user ON user.id_pimpinan = pimpinan.id_pimpinan inner join pgw on pgw.nip=pimpinan.nip WHERE user.username = '$username' "));
			
			if(isset($_POST['btnSimpan'])){

				if($_POST['rbStatus']=='1'){
					$sql_update = "UPDATE surat_masuk SET
                        status_s_masuk='".$_POST['rbStatus']."',
                        info_rektor='".$_POST['txtInfo']."'
                        WHERE id_s_masuk='".$_GET['kd']."'";
                    $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
				}else{

					$imp= implode("~ ", $_POST['cboTujuan']);
                    $exp= explode("~ ", $imp);
                    $count = count($exp);

                    $sql_update = "UPDATE surat_masuk SET
                        status_s_masuk='".$_POST['rbStatus']."',
                        info_rektor='".$_POST['txtInfo']."'
                        WHERE id_s_masuk='".$_GET['kd']."'";
                    $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        	if($_POST['cboTujuan'] != ''){
		        		$sql_hapus = "DELETE FROM dispo_s_masuk WHERE id_s_masuk='".$_GET['kd']."'";
						$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
			
						// $mail->isSMTP();                                     
						// $mail->Host = 'smtp.gmail.com';  
						// $mail->SMTPAuth = true;                      
						// $mail->Username = 'ardi.irfanto@umk.ac.id';        
						// $mail->Password = 'Regenerator';                         
						// $mail->SMTPSecure = 'tls';                           
						// $mail->Port = 587;                                   
						// $mail->setFrom('ardi.irfanto@umk.ac.id', 'Sistem Disposisi Surat Rektorat UMK');
						// $mail->smtpConnect(
						// 	array(
						// 		"ssl" => array(
						// 			"verify_peer" => false,
						// 			"verify_peer_name" => false,
						// 			"allow_self_signed" => true
						// 		)
						// 	)
						// );

						for($x=0;$x<$count;$x++){
                            $arrKeSave = explode('*',$exp[$x]);

                            $arrKeNIP = $arrKeSave[0];
                            $arrKeNama = $arrKeSave[1];
                            $arrKeGdepan = $arrKeSave[2];
                            $arrKeGblkg = $arrKeSave[3];
                            $arrKeEmail = $arrKeSave[4];
                            $arrKeJfung = $arrKeSave[5];
                            $arrKeJStruk = $arrKeSave[6];
                            $arrKePangkat = $arrKeSave[7];


                            $getKe = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama ='$arrKeNama' "));

                            if($getKe){
                                $updateKe = mysqli_query($koneksi,"UPDATE pgw SET
                                    nip = '$arrKeNIP',
                                    nama = '$arrKeNama',
                                    gelar_depan = '$arrKeGdepan',
                                    gelar_belakang = '$arrKeGblkg',
                                    email = '$arrKeEmail',
                                    jabatan_fungsional = '$arrKeJfung',
                                    jabatan_struktural = '$arrKeJStruk',
                                    pangkat = '$arrKePangkat'
                                    WHERE id_pgw = '$getKe[id_pgw]'"
                                );
                                $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw WHERE nip ='$arrKeNIP' AND nama = '$arrKeNama' "));
                            } else {
                                $insertKe = mysqli_query($koneksi, "INSERT INTO pgw(nip,nama,gelar_depan,gelar_belakang,email,jabatan_fungsional,jabatan_struktural,pangkat)
                                    VALUES ('$arrKeNIP','$arrKeNama','$arrKeGdepan','$arrKeGblkg','$arrKeEmail',
                                        '$arrKeJfung','$arrKeJStruk','$arrKePangkat');
                                ");
                                $getKe2 = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pgw ORDER BY id_pgw DESC LIMIT 1 "));
                            }

                            mysqli_query($koneksi,"INSERT INTO dispo_s_masuk(id_s_masuk,id_pgw,informasi,tgl_dispo,pemberi,status) 
                                values('$idsurat','$getKe2[id_pgw][$x]','$_POST[txtInfo]',NOW(),'$userinfo[id_pgw]','2')");
                            // $email = $getKe2['email'];

                            // $mail->Subject = 'Pemberitahuan Disposisi';
                            // $mail->Body    = "<div class='card' style='margin:50px;'>
                            //                     <div class='card-header'>
                            //                         <h5 align='center'>Pemberitahuan Disposisi</h5>
                            //                     </div>
                            //                     <div class='card-body'>
                            //                         <div class='alert alert-success alert-bordered'>
                            //                             <p> <b> Berikut adalah Detail Disposisi: </b> </p>
                            //                             <p> Pemberi Disposisi      			:". $pimpinan ." </p>
                            //                             <p> Disposisi ditujukan kepada      :". $getKe2['gelar_depan']."".$getKe2['nama'].",". $getKe2['gelar_belakang'] ." </p>
                            //                             <p> Instruksi/Informasi     		:". $_POST['txtInfo'] ." </p>
                            //                             <hr>
                            //                             <p> Download File Surat Masuk       : <a href='localhost/disposisi2/File/SuratMasuk/". $data['scan_s_masuk'] ."'> Download </a> </p>
                            //                             <p> Untuk Ketersediaan terkait bisa/tidak silahkan menghubungi Admin Rektorat. Terima Kasih</p>
                            //                         </div>
                            //                     </div>
                            //                 </div>";
                            // $mail->AltBody = '----------------------------------------------';

                            // $mail->addAddress('higan.nanda@umk.ac.id','1');													
                            // $mail->isHTML(true);
                            // $mail->send();
                            // $mail->ClearAddresses();
                        }
						
		        	}
				}

	        	if ($query_update) {
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='0; url=?v=s_masuk_daftar&id=$getKode[parent]'>";
		        	}
			}

		?>

		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Proses Surat Masuk</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">

					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i>
									Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
							<!-- <li>
								<a href="#recent11" data-toggle="tab" class="text-center">Surat Tugas</a>
							</li> -->
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Pengirim</b></td>
											<?php if($data['nama_unit']=='Lainnya'){ ?>
											<td><?php echo $data['pengirim_eks'] ?></td>
											<?php }else{ ?>
											<td><?php echo $data['nama_unit'] ?></td>
											<?php } ?>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Terima</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Ditujukan Kepada</b></td>
											<td><?php echo $pimpinan?> [<?php echo $data['nip'];?>]</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>No Agenda</b></td>
											<td><?php echo $data['no_agenda'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170" colspan="2" style="font-size: 15px; color:red;">
												<b>PROSES</b></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Aksi</b></td>
											<td>
												<div class="col-md-4">
													<div class="radio-custom">
														<input type="radio" id="radioExample1"
															onclick="javascript:yesnoCheck();" name="rbStatus" value="1"
															<?php if($data['status_s_masuk']=='1'){echo "checked";} ?>>
														<label for="radioExample1">OK</label>
													</div>
												</div>
												<div class="col-md-4">
													<div class="radio-custom">
														<input type="radio" id="radioExample2"
															onclick="javascript:yesnoCheck();" name="rbStatus" value="0"
															<?php if($data['status_s_masuk']=='0'){echo "checked";} ?>>
														<label for="radioExample1">Disposisi</label>
													</div>
												</div>
												<?php
													if($data['status_s_masuk']=='0'){
												?>
												<div class="col-md-7" id="disposisi" style="display: block;">
													<?php
													}else{
												?>
													<div class="col-md-12" id="disposisi" style="display: none;">
														<?php
													}
												?>
														<br>
														<!-- <div class="col-md-9"> -->
														<?php
														if($data['status_s_masuk']=='0'){
													?>
														<label>Ubah disposisi:</label>
														<?php
														}else{
													?>
														<label>Disposisi ke:</label>
														<?php
														}
													?>
															<select multiple data-plugin-selectTwo class="form-control populate" name="cboTujuan[]">
				                                                <option>*Pilih</option>
				                                                <?php
																	
																	$qryDituju = mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.level='1' order by b.nama_unit,a.nama_unit asc");
																	while($dtDituju = mysqli_fetch_array($qryDituju)){
																		if($dtDituju['nama2']!=null){
																			$unitt=$dtDituju['nama2'];
																		}
																?>
																	<option value="U*<?php echo $dtDituju['id_unit'] ?>"> <?php echo $dtDituju['nama1'] ?></option>
																<?php
																	}
																?>
				                                                <?php
				                                                    foreach ($datapegawai as $key => $val) {
				                                                        $value = $val['nip']."*".
				                                                                $val['nama']."*".
				                                                                $val['gelar_depan']."*".
				                                                                $val['gelar_belakang']."*".
				                                                                $val['email']."*".
				                                                                $val['jabatan_fungsional']."*".
				                                                                $val['jabatan_struktural']."*".
				                                                                $val['pangkat'];
				                                                        echo "<option value='$value' > $val[gelar_depan] $val[nama], $val[gelar_belakang] [$val[nip]]</option>";
				                                                    }
											                    ?>
				                                            </select>
															<small>*) Kosongi bila disposisi tidak diubah</small>
														<!-- </div> -->
													</div>
													<?php
														$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_masuk where id_s_masuk='$_GET[kd]'"));
														if($data['status_s_masuk']=='0'){
															$getPemberi=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from dispo_s_masuk where id_s_masuk='$data[id_s_masuk]'"));
													?>
													<div class="col-md-5" id="listdispo" style="margin-bottom: 10px;">
														Disposisi Ke
														<ul>
															<?php
																$qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk dsm inner join pgw p on dsm.id_pgw = p.id_pgw where dsm.id_s_masuk='$data[id_s_masuk]' and dsm.pemberi='$getPemberi[pemberi]'");
																while($dta = mysqli_fetch_array($qr)){
													        ?>
															<li>
			                                                    <b><?php echo $dta['gelar_depan']." ".$dta['nama'].", ".$dta['gelar_belakang'] ?></b>
			                                                    (<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>)
			                                                </li>
															<?php
															}
														?>
														</ul>
													</div>
													<?php
														}
													?>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Instruksi/Informasi</b></td>
											<td>
												<textarea class="form-control" rows="3" id="textareaAutosize"
													name="txtInfo"
													data-plugin-textarea-autosize><?php echo $data['info_rektor'] ?></textarea>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
							<!-- <div id="recent11" class="tab-pane">
								<div id="example2"></div>
							</div> -->
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Simpan</button>
					<a href="?v=s_masuk_daftar&id=<?php echo $getKode['parent'] ?>" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>
	PDFObject.embed("../../File/SuratMasuk/<?php echo $surat ?>#toolbar=0", "#example1");
</script>
<!-- <script>PDFObject.embed("../../File/Surat Tugas/<?php echo $suratTugas ?>#toolbar=1", "#example2");</script> -->

<style>
	.pdfobject-container {
		height: 90rem;
		border: 0.4rem solid rgba(0, 0, 0, .1);
	}
</style>

<script>
	function hanyaAngka(evt) {
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))

			return false;
		return true;
	}

	function yesnoCheck() {
		if (document.getElementById('radioExample2').checked) {
			document.getElementById('disposisi').style.display = 'block';
			document.getElementById('listdispo').style.display = 'block';
		} else if (document.getElementById('radioExample1').checked) {
			document.getElementById('disposisi').style.display = 'none';
			document.getElementById('listdispo').style.display = 'none';
		}
	}
</script>