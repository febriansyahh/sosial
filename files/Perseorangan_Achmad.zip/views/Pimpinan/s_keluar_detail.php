<header class="page-header">
	<h2>Surat Keluar</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Keluar</span></li>
			<li><span>Detail</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar inner join tujuan_s_keluar on tujuan_s_keluar.id_s_keluar=surat_keluar.id_s_keluar where surat_keluar.id_s_keluar='$_GET[kd]'"));
			$surat=$data['scan_s_keluar'];

			if (!$_GET['kd']=="") {
				if($username=='rektor'){
					if($data['rektor']=='0'){
						$sql_update = "UPDATE surat_keluar SET
			      			rektor='1'
			      			WHERE id_s_keluar='".$_GET['kd']."'";
			        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
					}
				}elseif($username=='warek1'){
					if($data['wr1']=='0'){
						$sql_update = "UPDATE surat_keluar SET
			      			wr1='1'
			      			WHERE id_s_keluar='".$_GET['kd']."'";
			        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
					}
				}elseif($username=='warek2'){
					if($data['wr2']=='0'){
						$sql_update = "UPDATE surat_keluar SET
			      			wr2='1'
			      			WHERE id_s_keluar='".$_GET['kd']."'";
			        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
					}
				}elseif($username=='warek3'){
					if($data['wr3']=='0'){
						$sql_update = "UPDATE surat_keluar SET
			      			wr3='1'
			      			WHERE id_s_keluar='".$_GET['kd']."'";
			        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
					}
				}elseif($username=='warek4'){
					if($data['wr4']=='0'){
						$sql_update = "UPDATE surat_keluar SET
			      			wr4='1'
			      			WHERE id_s_keluar='".$_GET['kd']."'";
			        	$query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
					}
				}
			}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Detail Surat Keluar</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					
					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i> Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_keluar'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_keluar']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_keluar'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Unit Dituju</b></td>
											<td>
												<?php
													if($data['jenis_unit']=='Internal'){
												?>
												<ul>
													<?php
									                    $qr = mysqli_query($koneksi,"SELECT * from tujuan_s_keluar inner join unit on unit.id_unit=tujuan_s_keluar.id_unit where id_s_keluar='$_GET[kd]'");
									                    while($dt = mysqli_fetch_array($qr)){
									                ?>
													<li><?php echo $dt['nama_unit'] ?></li>
													<?php
														}
													?>
												</ul>
												<?php
													}else{
												?>
													<?php echo $data['unit_eks'] ?>
												<?php
													}
												?>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<a href="?v=s_keluar_daftar&id=<?php echo $data['id_kode'] ?>" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>PDFObject.embed("../../File/Surat Keluar/<?php echo $surat ?>#toolbar=0", "#example1");</script>

<style>
.pdfobject-container { height: 90rem; border: 0.4rem solid rgba(0,0,0,.1); }
</style>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>