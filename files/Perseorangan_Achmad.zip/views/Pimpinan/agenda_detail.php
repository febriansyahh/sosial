<header class="page-header">
	<h2>Agenda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Daftar Agenda</span></li>
			<li><span>Detail</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from agenda where id_agenda='$_GET[id]'"));
			$agenda=$data['file_agenda'];

		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Detail Daftar Agenda</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<table class="table">
						<tbody>
							<tr class="gradeX">
								<td width="170"><b>Nama Agenda</b></td>
								<td><?php echo $data['nama_agenda'] ?></td>
							</tr>
							<tr class="gradeX">
								<td width="170"><b>Waktu Agenda</b></td>
								<td><?php echo date("d/m/Y", strtotime($data['tgl_agenda']));?> <?php echo $data['jam_agenda'] ?></td>
							</tr>
							<?php
								if($data['kehadiran']!=''){
							?>
								<tr class="gradeX">
									<td width="170"><b>Kehadiran</b></td>
									<td><?php echo $data['kehadiran'] ?></td>
								</tr>
							<?php
								}
							?>
							<tr class="gradeX">
								<td width="170"><b>Isi Agenda</b></td>
								<td>
									<div class="panel-body" style="border: black 1px solid;">
										<?php echo $data['isi_agenda'] ?>
									</div>
								</td>
							</tr>
							<tr class="gradeX">
								<td colspan="2">
									<div id="example1"></div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<footer class="panel-footer">
					<a href="?v=agenda" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>PDFObject.embed("../../File/Agenda/<?php echo $agenda ?>#toolbar=1", "#example1");</script>

<style>
.pdfobject-container { height: 90rem; border: 0.4rem solid rgba(0,0,0,.1); }
</style>