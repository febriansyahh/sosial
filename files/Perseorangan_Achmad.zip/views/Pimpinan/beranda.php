<header class="page-header">
	<h2>Beranda</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><span>Beranda</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12 col-lg-12 col-xl-6">
		<section class="panel">
			<header class="panel-heading" style="background-color: white;">
				<div class="panel-heading-icon bg-default mt-sm" style="background-color: white;">
					<img src="../../assets/images/logosn.png" height="100"/>
				</div>
			</header>
			<div class="panel-body">
				<h3 class="text-semibold mt-none text-center">Selamat Datang, </h3>
				<p class="text-center">Anda telah masuk di Sistem Informasi Pengarsipan Surat Sekretariat Rektor Universitas Muria Kudus.
				</p><br>
				<form method="POST" action="?v=pencarian" class="search nav-form">
					<div class="input-group input-search">
						<input type="text" class="form-control" name="q" id="q" placeholder="Masukkan nomor surat lalu Klik Cari/Tekan 'Enter'">
						<span class="input-group-btn">
							<button class="btn btn-default" name="btnCari" title="Cari" type="submit"><i class="fa fa-search"></i></button>
						</span>
					</div>
				</form>
			</div>
		</section>
	</div>
</div>