<header class="page-header">
	<h2>Arsip Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Arsip Surat Masuk</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>



<section class="panel">
	<?php
        $query = mysqli_query($koneksi,"SELECT * from kode_surat where level='1' order by kd_surat asc");
        while($data = mysqli_fetch_array($query)){
        	if($username=='rektor'){
        		// $cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_masuk where id_kode=$data[idkode] group by id_kode"));
				$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_masuk a 
				inner join kode_surat b on b.id_kode=a.id_kode 
				where a.id_pimpinan = '$user[id_pimpinan]' 
				and parent='$data[id_kode]' group by parent"));
			} else {
				// $cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_masuk a 
				// inner join kode_surat b on b.id_kode=a.id_kode 
				// where a.id_pimpinan = '$user[id_pimpinan]' 
				// and parent='$data[id_kode]' group by parent"));
				$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(sm.id_s_masuk) as cnt, sm.id_kode FROM surat_masuk sm 
					INNER JOIN dispo_s_masuk dsm ON sm.id_s_masuk = dsm.id_s_masuk 
					INNER JOIN pgw u ON dsm.id_pgw = u.id_pgw 
					inner join pimpinan on pimpinan.nip=u.nip 
					inner join user on user.id_pimpinan=pimpinan.id_pimpinan
					inner join kode_surat ks on sm.id_kode = ks.id_kode
					WHERE parent='$data[id_kode]' AND user.username = '$username' and unit='0' GROUP BY parent
					"));
				// var_dump("SELECT count(sm.id_s_masuk) as cnt, sm.id_kode FROM surat_masuk sm 
				// 	INNER JOIN dispo_s_masuk dsm ON sm.id_s_masuk = dsm.id_s_masuk
				// 	INNER JOIN unit u ON dsm.id_unit = u.id_unit
				// 	INNER JOIN pegawai p ON u.id_pegawai = p.id_pegawai
				// 	INNER JOIN user us ON p.id_pegawai = us.id_pegawai
				// 	WHERE sm.id_kode='$data[idkode]'AND us.username = '$username' GROUP BY sm.id_kode");
			}
        	// }elseif($username=='warek1'){
        	// 	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt, id_kode from surat_masuk where id_pegawai='$user[id_pegawai]' and id_kode='$data[idkode]' group by id_kode"));
        	// }elseif($username=='warek2'){
        	// 	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_masuk where id_kode=$data[idkode] and wr2='0' group by id_kode"));
        	// }elseif($username=='warek3'){
        	// 	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_masuk where id_kode=$data[idkode] and wr3='0' group by id_kode"));
        	// }elseif($username=='warek4'){
        	// 	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt from surat_masuk where id_kode=$data[idkode] and wr4='0' group by id_kode"));
        	$pgw=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pgw where nip='$user[nip]'"));

			$belum=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as blm, sm.id_kode from surat_masuk sm 
				inner join kode_surat ks on sm.id_kode = ks.id_kode
				where sm.id_pimpinan='$user[id_pimpinan]' and ks.parent='$data[id_kode]' and sm.status_s_masuk='' group by parent"));
			// var_dump("SELECT count(*) as blm, sm.id_kode from surat_masuk sm 
			// 	inner join kode_surat ks on sm.id_kode = ks.id_kode
			// 	where sm.id_pimpinan='$user[id_pimpinan]' and ks.parent='$data[id_kode]' and sm.status_s_masuk='' group by parent");

			$blm_dispo=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as blm, sm.id_kode from surat_masuk sm inner join kode_surat ks on sm.id_kode = ks.id_kode inner join dispo_s_masuk dm on dm.id_s_masuk=sm.id_s_masuk where dm.id_pgw='$pgw[id_pgw]' and ks.parent='$data[id_kode]' and dm.status='2' group by parent"));

        	if($cek['cnt'] > 0){
        		$ttl=$cek['cnt'];
        		$label='<span class="label-label-success">Surat</span>';
        	}else{
        		$ttl='0';
        		$label='';
        	}

        	$blm=$belum['blm']+$blm_dispo['blm'];

        	if($belum['blm'] > 0 || $blm_dispo['blm'] > 0){
        		// $ttl=$cek['cnt'];
        		// $label='<span class="highlight">Surat Belum Proses</span>';
        		$belumm='<span class="label label-danger">'.$blm.' Surat Belum Proses</span>';
        	}else{
        		// $ttl='0';
        		$belumm='';
        	}
        	// $cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(id_s_masuk) as ttl_surat from kode_surat left join surat_masuk on surat_masuk.id_kode=kode_surat.id_kode inner join disposisi_s_masuk on disposisi_s_masuk.id_s_masuk=surat_masuk.id_s_masuk inner join tujuan_dispo on tujuan_dispo.id_dispo=disposisi_s_masuk.id_dispo inner join unit on unit.id_unit=tujuan_dispo.id_unit where nama_unit like '%$user[nama_pimpinan]%' group by kode_surat.id_kode order by kd_surat asc"));
    ?>
	<div class="col-md-6 col-lg-6 col-xl-3">
		<section class="panel panel-featured-bottom panel-featured-primary">
			<div class="panel-body">
				<div class="widget-summary">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-primary">
							<?php echo $data['kd_surat'] ?>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo $data['nama_kode'] ?></h4>
							<div class="info">
								<strong class="amount"><?php echo $ttl ?></strong> <?php echo $label ?> <?php echo $belumm ?>
								<!-- <span class="text-primary">(14 unread)</span> -->
							</div>
						</div>
						<div class="summary-footer">
							<a href="?v=s_masuk_daftar&id=<?php echo $data['id_kode'] ?>" class="text-uppercase">Tampilkan Semua</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<?php
		}
	?>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>