<header class="page-header">
	<h2>User</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>User</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from user inner join pimpinan on pimpinan.id_pimpinan=user.id_pimpinan where id_user='$_GET[id]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		      	if($_POST['txtPassword']!=''){
			      	$sql_update = "UPDATE user SET
			      		password='".$_POST['txtPassword']."'
			      		WHERE id_user='".$_GET['id']."'";
			        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

			        if ($query_update) {
			          	echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Ubah Berhasil!</strong> Tunggu...
							</div>";
			          	echo "<meta http-equiv='refresh' content='1; url=?v=user'>";
			        }
			    }else{
			    		echo "<meta http-equiv='refresh' content='0; url=?v=user'>";
			    }
		    }
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Ubah User</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Pegawai: </label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="txtNama" value="<?php echo $data['nama_pimpinan'] ?> [NIP: <?php echo $data['nip'] ?>]" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Username: </label>
						<div class="col-sm-3">
							<input type="text" class="form-control" name="txtUsername" value="<?php echo $data['username'] ?>" maxlength="10" readonly>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Password: </label>
						<div class="col-sm-3">
							<input type="password" class="form-control" name="txtPassword" maxlength="10">
							<small>)* Kosongi <code style="font-size: 12px;">password</code> bila tidak diubah</small>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<button class="btn btn-success" type="submit" name="btnSimpan">Ubah </button>
					<a href="?v=beranda" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>