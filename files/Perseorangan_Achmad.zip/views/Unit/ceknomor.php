<?php 
    // error_reporting(E_ERROR | E_WARNING | E_PARSE);
    include "../../koneksi.php";

    $kodesurat = $_POST['kodesurat'];
    $tgl = $_POST['tanggalsurat'];
    $tanggalsurat = explode('/',$tgl);
    $unitpengirim = $_POST['unitpengirim'];
    $id_unit = explode('*', $unitpengirim);
    $id_unit = $id_unit[0];
    // var_dump($id_unit);

    // var_dump($unitpengirim);
    function getRomawi($angka){
        switch ($angka){
            case 1: 
                return "I";
                break;
            case 2:
                return "II";
                break;
            case 3:
                return "III";
                break;
            case 4:
                return "IV";
                break;
            case 5:
                return "V";
                break;
            case 6:
                return "VI";
                break;
            case 7:
                return "VII";
                break;
            case 8:
                return "VIII";
                break;
            case 9:
                return "IX";
                break;
            case 10:
                return "X";
                break;
            case 11:
                return "XI";
                break;
            case 12:
                return "XII";
                break;
        }
    }
    if($unitpengirim=='' || $tgl==''){
        $ket="<span class='label label-danger' style='padding: 5px; line-height: 40px; font-size: 15px;'>*) Lengkapi kolom diatas.</span>";
    ?>
        <span id="ket"><?php echo $ket ?></span>
    <?php
        }else{
            $ket='';
            $bulan=getRomawi($tanggalsurat[0]);
            $tahun=$tanggalsurat[2];

            $cek_frmt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from setting_nomor where id_unit='$id_unit' and tipe='Urut Nomor'"));
            // var_dump($cek_frmt['setting']);
            // var_dump($cek_frmt);

            if($cek_frmt==null){
                $maxid=mysqli_fetch_array(mysqli_query($koneksi, "SELECT max(id_s_keluar) as max from surat_keluar where id_unit='$id_unit' and tgl_s_keluar LIKE '$tahun%'"));
                $maxno=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar where id_s_keluar='$maxid[max]'"));
                // var_dump($maxno);
                if($maxno==null){
                    $maxno='0';
                }else{
                    $maxno=$maxno['no_s_keluar'];
                }
                $maxno_imp=explode('/', $maxno);
                $no_last=$maxno_imp['0'];
                // $no_last=int($no_last);
                $no_depan=$no_last+1;
                $no_depan='0'.$no_depan;
            }else{
                if($cek_frmt['setting']=='Otomatis'){
                    $maxid=mysqli_fetch_array(mysqli_query($koneksi, "SELECT max(id_s_keluar) as max from surat_keluar where id_unit='$id_unit' and tgl_s_keluar LIKE '$tahun%'"));
                    $maxno=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar where id_s_keluar='$maxid[max]'"));
                    // var_dump($maxno);
                    if($maxno==null){
                        $maxno='0';
                    }else{
                        $maxno=$maxno['no_s_keluar'];
                    }
                    $maxno_imp=explode('/', $maxno);
                    $no_last=$maxno_imp['0'];
                    // $no_last=int($no_last);
                    $no_depan=$no_last+1;
                    $no_depan='0'.$no_depan;
                }else{
                    $no_depan=$cek_frmt['nomor_surat'];
                    $no_depan='0'.$no_depan;
                    $no_depan1=$no_depan.'/';
                    $cek_no=mysqli_num_rows(mysqli_query($koneksi, "SELECT * from surat_keluar where id_unit='$id_unit' and no_s_keluar LIKE '$no_depan1%' and tgl_s_keluar LIKE '$tahun%'"));
                    // var_dump("SELECT * from surat_keluar where id_unit='$id_unit' and no_s_keluar LIKE '$no_depan1' and tgl_s_keluar LIKE '$tahun%'");
                    if($cek_no < 1){
                        $no_depan=$no_depan;
                    }else{
                        $maxid=mysqli_fetch_array(mysqli_query($koneksi, "SELECT max(id_s_keluar) as max from surat_keluar where id_unit='$id_unit' and tgl_s_keluar LIKE '$tahun%'"));
                        $maxno=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar where id_s_keluar='$maxid[max]'"));
                        // var_dump($maxno);
                        if($maxno==null){
                            $maxno='0';
                        }else{
                            $maxno=$maxno['no_s_keluar'];
                        }
                        $maxno_imp=explode('/', $maxno);
                        $no_last=$maxno_imp['0'];
                        // $no_last=int($no_last);
                        $no_depan=$no_last+1;
                        $no_depan='0'.$no_depan;
                    }
                }
            }
            // var_dump($cek_no);

            $dt=mysqli_fetch_array(mysqli_query($koneksi,"SELECT a.kd_surat as sub_nomor, b.kd_surat as no_surat from kode_surat a inner join kode_surat b on b.id_kode=a.parent where a.id_kode ='$kodesurat'"));
            // var_dump("SELECT a.kd_surat as sub_nomor, b.kd_surat as no_surat from kode_surat a inner join kode_surat b on b.id_kode=a.parent where a.id_unit='$id_unit' and a.id_kode ='$kodesurat'");
            $sub=$dt['no_surat'].".".$dt['sub_nomor'];
            // var_dump($sub);
            // $sub_last=mysqli_num_rows(mysqli_query($koneksi, "SELECT * from surat_keluar where id_unit='$id_unit' and no_s_keluar LIKE '%$sub%'"));
            $sub_last=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * from surat_keluar where id_unit='$id_unit' and no_s_keluar LIKE '%$sub%' and tgl_s_keluar LIKE '$tahun%' order by id_s_keluar desc limit 1"));
            // var_dump($sub_last['no_s_keluar']);

            $cek_frmt_kd=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from setting_nomor where id_unit='$id_unit' and tipe='Urut Kode' and id_kode='$kodesurat'"));

            // var_dump($cek_frmt_kd['setting']);
                if($cek_frmt_kd==null){
                    if($sub_last==null){
                        $no_kode='01';
                    }else{
                        $exp=explode('/', $sub_last['no_s_keluar']);
                        $exp_no=$exp[2];
                        $exp2=explode('.', $exp_no);
                        $sub_last=$exp2[2];
                        $no_kode=$sub_last+1;
                        $no_kode='0'.$no_kode;
                    }
                }else{
                    if($cek_frmt_kd['setting']=='Otomatis'){
                        if($sub_last==null){
                            $no_kode='01';
                        }else{
                            $exp=explode('/', $sub_last['no_s_keluar']);
                            $exp_no=$exp[2];
                            $exp2=explode('.', $exp_no);
                            $sub_last=$exp2[2];
                            $no_kode=$sub_last+1;
                            $no_kode='0'.$no_kode;
                        }
                    }else{
                        $no_kd=$cek_frmt_kd['nomor_surat'];
                        $no_kd='0'.$no_kd;
                        // echo "MNN";
                        $no_kd1=$sub.'.'.$no_kd;
                        // var_dump($no_kd1);
                        $cek_no=mysqli_num_rows(mysqli_query($koneksi, "SELECT * from surat_keluar where id_unit='$id_unit' and no_s_keluar LIKE '%$no_kd1%' and tgl_s_keluar LIKE '$tahun%'"));
                        // var_dump($cek_no);
                        if($cek_no < 1){
                            $no_kode=$no_kd;
                        }else{
                            $exp=explode('/', $sub_last['no_s_keluar']);
                            $exp_no=$exp[2];
                            $exp2=explode('.', $exp_no);
                            $sub_last=$exp2[2];
                            $no_kode=$sub_last+1;
                            $no_kode='0'.$no_kode;
                        }
                    }
                }
            
            // $dt = mysqli_fetch_array($tampil);
            // $lt = mysqli_num_rows($tampil);
            // echo "<option>Pilih</option>";
            // for($i=1;$i<=$lt;$i++){

            $no_surat_depan=$no_depan.'/';
            $no_surat_blkg='/'.$sub.".".$no_kode."/".$bulan."/".$tahun;
        
    ?>
    <select data-plugin-selectTwo class="form-control populate" id="nomorsurat" name="cboNoSurat" required>
        <option value="">*) Pilih format surat</option>
        <?php
            $query = mysqli_query($koneksi,"SELECT * from format_surat where id_unit='$id_unit'");
            while($data = mysqli_fetch_array($query)){
        ?>
            <option value="<?php echo $no_surat_depan ?><?php echo $data['format_surat'] ?><?php echo $no_surat_blkg ?>"><?php echo $no_surat_depan ?><?php echo $data['format_surat'] ?><?php echo $no_surat_blkg ?></option>
        <?php } ?>
    </select>
    <?php
        }
    ?>
    
    <!-- <input type="text" class="form-control" name="txtNoSurat" id="nomorsurat" readonly maxlength="50" value="<?php echo $no_surat; ?>"> -->

<!-- <select data-plugin-selectTwo class="form-control populate" name="cboNoSurat"> -->
    <!-- <option value="">Pilih Format Surat</option> -->
