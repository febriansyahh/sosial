<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Daftar</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php
	
	$getKD=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from kode_surat where id_kode='$_GET[id]'"));


?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Daftar Surat Masuk "<?php echo $getKD['nama_kode'] ?>"</h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>No Surat</th>
					<th>Tgl Surat</th>
					<th>Tgl Terima</th>
					<th>Perihal</th>
					<th>Pengirim</th>
					<!-- <th>Waktu</th> -->
					<th width="130"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT id_pimpinan,a.id_s_masuk as id_s_masuk,c.nama_unit as nama_unit, a.no_s_masuk as no_s_masuk, b.nama_kode as nama_kode, a.tgl_s_kirim as tgl_s_kirim, a.perihal_s_masuk as perihal_s_masuk from surat_masuk a inner join kode_surat b on b.id_kode=a.id_kode inner join unit c on c.id_unit=a.id_unit left join unit d on d.parent=c.id_unit where a.id_pimpinan != 'NULL' and b.parent='$_GET[id]' or b.id_kode='$_GET[id]' order by tgl_s_kirim desc");
                    while($data = mysqli_fetch_array($query)){
						$getbau = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM status_bau WHERE id_s_masuk = '$data[id_s_masuk]'"));

                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td>
						<?php echo $data['no_s_masuk'] ?><br>
						<?php 
							if($getbau){
								if($getbau['status'] == 0){
						?>
						<span class="label label-danger">Belum DiProses</span>
						<?php					
								} else {
						?>
						<span class="label label-success"><i class="fa fa-check"></i> Sudah Diproses</span>
						<?php
								}
							} else {
						?>
						<span class="label label-danger">Belum DiProses</span>
						<?php
							}
						?>
					</td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
					<td><?php echo $data['perihal_s_masuk'] ?></td>
					<?php if($data['nama_unit']=='Lainnya'){ ?>
						<td><?php echo $data['pengirim_eks'] ?></td>
					<?php }else{ ?>
						<td><?php echo $data['nama_unit'] ?></td>
					<?php } ?>
					<td>
						<a style="margin:5px;" href="?v=s_tugas_proses&kd=<?php echo $data['id_s_masuk'] ?>" title="Proses" class="btn btn-sm btn-success">Proses</a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>