<header class="page-header">
	<h2>Disposisi</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Disposisi</span></li>
			<li><span>Daftar</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php
	$getUnit  = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM unit un INNER JOIN user us ON un.id_unit = us.id_unit WHERE us.username ='$_SESSION[username]' "));	
	$getKD=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from kode_surat where id_kode='$_GET[id]'"));

	if (!$_GET['kd']=="") { 

		$sql_hapus = "DELETE FROM surat_masuk WHERE id_s_masuk='".$_GET['kd']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<div class='alert alert-primary'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<strong>Hapus Berhasil!</strong> Tunggu...
				  </div>";
	        echo "<meta http-equiv='refresh' content='1; url=?v=s_masuk_daftar&id=$_GET[id]'>";
	    }
  	}

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Disposisi "<?php echo $getKD['nama_kode'] ?>"</h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>No Surat</th>
					<th>Nama Kode Sub</th>
					<th>Tgl Surat</th>
					<th>Perihal</th>
					<th>Pengirim</th>
					<!-- <th>Waktu</th> -->
					<th width="130"></th>
				</tr>
			</thead>
			<tbody>
				<?php
					$no=1;
					if($getUnit['id_unit']==10){
						$query = mysqli_query($koneksi,"SELECT id_pimpinan,a.id_s_masuk as id_s_masuk,c.nama_unit as nama_unit, a.no_s_masuk as no_s_masuk, b.nama_kode as nama_kode, a.tgl_s_kirim as tgl_s_kirim, a.perihal_s_masuk as perihal_s_masuk from surat_masuk a inner join kode_surat b on b.id_kode=a.id_kode inner join unit c on c.id_unit=a.id_unit left join unit d on d.parent=c.id_unit where a.id_pimpinan != 'NULL' and b.parent='$_GET[id]' or b.id_kode='$_GET[id]' order by tgl_s_kirim desc");
					} else {
						$query = mysqli_query($koneksi,"SELECT id_pimpinan,a.id_s_masuk as id_s_masuk,c.nama_unit as nama_unit, a.no_s_masuk as no_s_masuk, b.nama_kode as nama_kode, a.tgl_s_kirim as tgl_s_kirim, a.perihal_s_masuk as perihal_s_masuk, status from surat_masuk a inner join kode_surat b on b.id_kode=a.id_kode inner join unit c on c.id_unit=a.id_unit left join unit d on d.parent=c.id_unit inner join dispo_s_masuk ds on ds.id_s_masuk=a.id_s_masuk where ds.id_pgw = '$getUnit[id_unit]' and b.parent='$_GET[id]' and ds.unit='1' or ds.id_pgw = '$getUnit[id_unit]' and b.id_kode='$_GET[id]' and ds.unit='1' order by tgl_s_kirim desc");
					}
                    while($data = mysqli_fetch_array($query)){
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td>
						<?php echo $data['no_s_masuk'] ?><br>
						<?php 
							if($data['unit']=='0'){
								if($data['status']=='0'){
									echo "<span class='label label-danger'>Belum DiProses</span>";
								}else{
									echo "<span class='label label-success'><i class='fa fa-check'></i> Sudah Diproses</span>";
								}
							}else{
								if($data['status']=='2'){
									echo "<span class='label label-danger'>Belum Terbaca</span>";
								}else{
									echo "<span class='label label-success'><i class='fa fa-check'></i> Terbaca</span>";	
								}
							}
						?>

					</td>
					<td><?php echo $data['nama_kode'] ?></td>
					<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
					<td><?php echo $data['perihal_s_masuk'] ?></td>
					<td><?php echo $data['nama_unit'] ?></td>
					<td>
						<!-- <?php if($data['id_pimpinan']!=null){ ?>
							<a style="margin:5px;" href="?v=s_masuk_proses&kd=<?php echo $data['id_s_masuk'] ?>" title="Proses" class="btn btn-sm btn-success">Proses</a>
						<?php } ?> -->
						<a style="margin:5px;" href="?v=disposisi_detail&kd=<?php echo $data['id_s_masuk'] ?>" title="Detail" class="btn btn-sm btn-info"><i class="fa fa-search-plus"></i></a>
						<!-- <a style="margin:5px;" href="?v=s_masuk_ubah&id=<?php echo $data['id_s_masuk'] ?>" title="Ubah" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
						<a style="margin:5px;" class="btn btn-sm btn-danger" data-toggle='modal' data-target='#konfirmasi_hapus' title="Hapus" data-href='?v=s_masuk_daftar&kd=<?php echo $data['id_s_masuk'] ?>&id=<?php echo $_GET['id'] ?>'><i class="fa fa-trash-o"></i></a> -->
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>