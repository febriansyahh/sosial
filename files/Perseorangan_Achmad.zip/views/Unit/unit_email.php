<?php 

    $getEmail = mysqli_fetch_assoc(mysqli_query($koneksi,"SELECT * FROM unit WHERE id_unit='$_GET[id]'"));

    if(isset($_POST['simpan'])){
        $id = $_GET['id'];
        $email = $_POST['email'];

        $q = mysqli_query($koneksi,"UPDATE unit SET email='$email' WHERE id_unit='$id'");

        if($q){
            echo "<div class='alert alert-primary'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
                    <strong>Perubahan Email Berhasil!</strong> Tunggu...
                    </div>";
            echo "<meta http-equiv='refresh' content='1; url=?v=unit_email&id=$id'>";
        }
    }

?>

<header class="page-header">
	<h2>Email Unit</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Email Unit</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<!-- <a href="#" class="fa fa-caret-down"></a> -->
		</div>

		<h2 class="panel-title">Ubah Email Unit</h2>
	</header>
	<div class="panel-body">
        <form action="" method="POST">
            <div class=" form-group row">
                <div class="col-md-1">
                    <label for="">Email Unit</label>
                </div>
                <div class="col-md-3">
                    <input value="<?php echo $getEmail['email'] ?>" type="text" class="form-control" name="email">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-success" name="simpan">Simpan Perubahan</button>
                </div>
            </div>
        </form>
	</div>
	<footer class="panel-footer">
		<a href="?v=unit" class="btn btn-default">Kembali</a>
	</footer>
</section>