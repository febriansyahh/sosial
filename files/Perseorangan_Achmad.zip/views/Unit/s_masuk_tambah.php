<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php
			include "function.php";

			$datajson = json_decode(getUnit(),TRUE);
			$data_unit = $datajson['data'];
				

		    if (isset ($_POST ['btnSimpan'])) {

		    	$cekNoSurat=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from surat_masuk where no_s_masuk='$_POST[txtNoSurat]'"));
		    	if($cekNoSurat>0){
		    		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> No Surat <strong>$_POST[txtNoSurat]</strong> sudah dimasukkan.
						  </div>";
		    	}else{

		    		// Menentukan nama File Arsip
		    		$nama2=str_replace('/', '', $_POST['txtNoSurat']);
			        $file_nama = $nama2.".pdf";

			        date_default_timezone_set('Asia/Jakarta');
					$waktu=date('Y-m-d H:i:s');
					
					// Pemecahan Value
					$cboUnit = explode('*', $_POST['cboUnit']);
					$idunit = $cboUnit[0];
					$namaunit = $cboUnit[1];

					$row_unit = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM unit WHERE id_unit = '$idunit' "));

					if($row_unit > 0){
						$unit_update = mysqli_query($koneksi,"UPDATE unit SET nama_unit = '$namaunit' WHERE id_unit = '$idunit' ");
					} else {
						$unit_insert = mysqli_query($koneksi,"INSERT INTO unit VALUES('$idunit','$namaunit') ");
					}

					$tujuan = '';

					if($getUnit['id_unit']==10){
						$sql_insert = "INSERT INTO surat_masuk (no_s_masuk,perihal_s_masuk,tgl_s_kirim,tgl_s_terima,scan_s_masuk,id_unit,pengirim_eks,id_kode,id_pimpinan,no_agenda,time_s_masuk) 
										VALUES (
											'".$_POST ['txtNoSurat']."',
											'".$_POST ['txtPerihal']."',
											'".date("Y/m/d", strtotime($_POST['txtTglSurat']))."',
											'".date("Y/m/d", strtotime($_POST['txtTglTerima']))."',
											'".$file_nama."',
											'".$idunit."',
											'".$_POST ['txtEksternal']."',
											'".$_POST ['cboKode']."',
											'".$_POST ['cboKepada']."',
											'".$_POST ['txtNoAgenda']."',
											'".$waktu."'
										)";
					} else {
						$sql_insert = "INSERT INTO surat_masuk (no_s_masuk,perihal_s_masuk,tgl_s_kirim,tgl_s_terima,scan_s_masuk,id_unit,pengirim_eks,id_kode,id_penerima,no_agenda,time_s_masuk) 
										VALUES (
											'".$_POST ['txtNoSurat']."',
											'".$_POST ['txtPerihal']."',
											'".date("Y/m/d", strtotime($_POST['txtTglSurat']))."',
											'".date("Y/m/d", strtotime($_POST['txtTglTerima']))."',
											'".$file_nama."',
											'".$idunit."',
											'".$_POST ['txtEksternal']."',
											'".$_POST ['cboKode']."',
											'".$_POST ['cboKepada']."',
											'".$_POST ['txtNoAgenda']."',
											'".$waktu."'
										)";
					}
					$query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

					if ($query_insert) {
					move_uploaded_file($_FILES['File']['tmp_name'],"../../File/SuratMasuk/".$file_nama);
					// copy($_FILES['File_ST']['tmp_name'],"../../File/Surat Tugas/".$file_nama);
					echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Berhasil!</strong> Tunggu...
						</div>";
					echo "<meta http-equiv='refresh' content='1; url=?v=s_masuk'>";
					}
		    	}
		    }
		?>
	</div>
</div>

<div class="row">
	<div class="col-xs-12">
		<section class="panel form-wizard" id="w4">
			<form class="form-horizontal" method="POST" enctype="multipart/form-data">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
						<a href="#" class="fa fa-times"></a>
					</div>

					<h2 class="panel-title">Tambah Surat Masuk</h2>
				</header>
				<div class="panel-body">
					<div class="wizard-progress wizard-progress-lg">
						<div class="steps-progress">
							<div class="progress-indicator"></div>
						</div>
						<ul class="wizard-steps">
							<li class="active">
								<a href="#w4-account" data-toggle="tab"><span>1</span>Lengkapi Surat</a>
							</li>
							<li>
								<a href="#w4-confirm" data-toggle="tab"><span>2</span>Upload Arsip</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<div id="w4-account" class="tab-pane active">
							<section class="panel">
								<div class="panel-body">
									<div class="form-group">
										<label class="col-sm-2 control-label">No Surat: </label>
										<div class="col-sm-4">
											<input type="text" class="form-control" name="txtNoSurat" required maxlength="50">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Kode Surat: </label>
										<div class="col-sm-8">
											<select data-plugin-selectTwo class="form-control populate" name="cboKode" id="kodesurat">
												<?php
													$query = mysqli_query($koneksi,"SELECT * from kode_surat where level='1' order by kd_surat asc");
													while($data = mysqli_fetch_array($query)){
												?>
												<optgroup label="<?php echo $data['kd_surat'] ?> - <?php echo $data['nama_kode'] ?>">
													<?php
														$qry = mysqli_query($koneksi,"SELECT * from kode_surat where level='2' and parent='$data[id_kode]' order by kd_surat asc");
														while($dt = mysqli_fetch_array($qry)){
													?>
														<option value="<?php echo $dt['id_kode'] ?>"><?php echo $data['kd_surat'] ?>.<?php echo $dt['kd_surat'] ?> - <?php echo $dt['nama_kode'] ?></option>
													<?php
														}
													?>
												</optgroup>
												<?php
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Tanggal Surat: </label>
										<div class="col-sm-2">
											<input type="text" name="txtTglSurat" data-plugin-datepicker class="form-control" required autocomplete="off">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Tanggal Terima: </label>
										<div class="col-sm-2">
											<input type="text" name="txtTglTerima" data-plugin-datepicker class="form-control" required autocomplete="off">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Perihal Surat: </label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="txtPerihal" required maxlength="100">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Ditujukan Kepada: </label>
										<div class="col-sm-8">
											<select data-plugin-selectTwo class="form-control" required name="cboKepada">
												<?php
													$query  = mysqli_query($koneksi, "SELECT a.id_unit as id_unit,a.nama_unit as nama1, a.parent as parent, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent inner join user c on a.id_unit = c.id_unit where a.login='1' and c.username='$username' order by b.nama_unit,a.nama_unit asc");
													$dt = mysqli_fetch_array($query); 
													if($dt['id_unit'] != 10){
														if($dt['parent']==''){
															$unit=$dt['nama1'];
														} else {
															$unit=$dt['nama2']." ".$dt['nama1'];
														}
												?>
												<option value="<?php echo $dt['id_unit'] ?>"> <?php echo $unit ?> </option>
												<?php
													} else {
														$queryz  = mysqli_query($koneksi, "SELECT*from pimpinan") or die (mysqli_error());
														while ($data = mysqli_fetch_array($queryz))
														{         
															echo "<option value='$data[id_pimpinan]'>$data[gelar_depan].$data[nama], $data[gelar_belakang] [$data[nip]]</option>";
														}
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Pengirim: </label>
										<div class="col-sm-8">
											<select data-plugin-selectTwo class="form-control" id="unit" required name="cboUnit" onchange="if(this.value =='999'){this.form['txtEksternal'].style.visibility='visible';}else{this.form['txtEksternal'].style.visibility='hidden'; this.form['txtEksternal'].value='';}">
												<option>*Pilih</option>
												<?php 
													foreach ($data_unit as $key => $value) {
												?>
												<option value="<?php echo $value['idunit'] ?>*<?php echo $value['namaunit'] ?>"><?php echo $value['namaunit'] ?></option>
												<?php
													}
												?>
												<option value="999">Pengirim Lainya</option>
											</select><br>
											<!-- <small>Masukkan Nama Pengirim Lainnya</small> -->
											<input type="text" style="visibility: hidden;" class="form-control" placeholder="Nama Pengirim Lainnya" name="txtEksternal" maxlength="100">
										</div>
									</div>
								</div>
							</section>
						</div>
						<div id="w4-confirm" class="tab-pane">
							<div class="form-group">
								<label class="col-sm-3 control-label">No Agenda: </label>
								<div class="col-sm-6">
									<input type="text" class="form-control" name="txtNoAgenda" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label" for="w4-email">File Arsip</label>
								<div class="col-sm-9">
									<input type="file" class="form-control" accept=".pdf" name="File" required>
									<small>*) File surat harus bertipe <code>.pdf</code></small>
								</div>
							</div>
							<div class="form-group">
								<!-- <label class="col-sm-3 control-label" for="w4-email">Surat Tugas</label>
								<div class="col-sm-9">
									<input type="file" class="form-control" accept=".pdf" name="File_ST" required>
									<small>*) File surat harus bertipe <code>.pdf</code></small>
								</div> -->
								<button class="btn btn-success" type="submit" name="btnSimpan">Tambah </button><br><br>
							</div>
						</div>
					</div>
				</div>
				<div class="panel-footer">
					<ul class="pager">
						<li class="previous disabled">
							<a><i class="fa fa-angle-left"></i> Sebelumnya</a>
						</li>
						<li class="finish hidden pull-right">
							
						</li>
						<li class="next">
							<a>Selanjutnya <i class="fa fa-angle-right"></i></a>
						</li>
					</ul>
				</div>
			</form>
		</section>
	</div>
</div>