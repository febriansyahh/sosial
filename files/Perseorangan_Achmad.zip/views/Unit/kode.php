<header class="page-header">
	<h2>Kode Surat</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Kode Surat</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>
<?php

	if (!$_GET['id']=="") { 

		$sql_hapus = "DELETE FROM kode_surat WHERE id_kode='".$_GET['id']."'";
		$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
		if ($query_hapus) {
	        echo "<div class='alert alert-primary'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<strong>Hapus Berhasil!</strong> Tunggu...
				  </div>";
	        echo "<meta http-equiv='refresh' content='1; url=?v=kode'>";
	    }
  	}

?>
<section class="panel">
	<header class="panel-heading">
		<div class="panel-actions">
			<a href="#" class="fa fa-caret-down"></a>
		</div>

		<h2 class="panel-title">Master Kode Surat</h2>
	</header>
	<div class="panel-body">
		<table class="table table-bordered table-striped mb-none" id="datatable-default">
			<thead>
				<tr>
					<th width="32">No</th>
					<th>Kode</th>
					<th>Nama Kode</th>
					<th width="135"></th>
				</tr>
			</thead>
			<tbody>
				<?php
                    $no=1;
                    $query = mysqli_query($koneksi,"SELECT * from kode_surat where level='1' order by kd_surat asc");
                    while($data = mysqli_fetch_array($query)){
                ?>
				<tr class="gradeX">
					<td><center><?php echo $no ?>.</center></td>
					<td><?php echo $data['kd_surat'] ?></td>
					<td><?php echo $data['nama_kode'] ?></td>
					<td>
						<!-- <a href="" class="btn btn-sm btn-default"><i class="fa fa-info"></i></a> -->
						<a href="?v=kode_ubah&id=<?php echo $data['id_kode'] ?>" title="Ubah" class="btn btn-sm btn-warning">Setting</a>
					</td>
				</tr>
				<?php
					$no++;
					}
				?>
			</tbody>
		</table>
	</div>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>