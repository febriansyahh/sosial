<header class="page-header">
	<h2>Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Masuk</span></li>
			<li><span>Detail</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT b.parent as parent,id_penerima,id_pimpinan,a.id_s_masuk as id_s_masuk,c.nama_unit as nama_unit, a.no_s_masuk as no_s_masuk, b.nama_kode as nama_kode, a.tgl_s_kirim as tgl_s_kirim, a.tgl_s_terima as tgl_s_terima, a.perihal_s_masuk as perihal_s_masuk, a.scan_s_masuk as scan_s_masuk, status_s_masuk from surat_masuk a inner join kode_surat b on b.id_kode=a.id_kode inner join unit c on c.id_unit=a.id_unit left join unit d on d.parent=c.id_unit where a.id_s_masuk='$_GET[kd]'"));
			$surat=$data['scan_s_masuk'];
			$suratTugas=$data['surat_tugas'];

			if($data['id_pimpinan']!=null){
				$pimpinan=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pimpinan where id_pimpinan='$data[id_pimpinan]'"));
			}else{
				if($data['status_s_masuk']==''){
					mysqli_query($koneksi,"UPDATE surat_masuk SET
					      		status_s_masuk='1'
					      		WHERE id_s_masuk='".$_GET['kd']."'");
			        // $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
			        echo "<script>window.location.replace('?v=s_masuk_detail&kd=$_GET[kd]');</script>";
		    	}
			}
		?>
		
		<form method="POST" class="form-horizontal">
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Detail Surat Masuk</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					
					<div class="tabs">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#popular10" data-toggle="tab" class="text-center"><i class="fa fa-star"></i> Info Surat</a>
							</li>
							<li>
								<a href="#recent10" data-toggle="tab" class="text-center">Arsip Surat</a>
							</li>
							<!-- <li>
								<a href="#recent11" data-toggle="tab" class="text-center">Surat Tugas</a>
							</li> -->
						</ul>
						<div class="tab-content">
							<div id="popular10" class="tab-pane active">
								<table class="table">
									<tbody>
										<tr class="gradeX">
											<td width="170"><b>Pengirim</b></td>
											<?php if($data['id_unit']=='999'){ ?>
												<td><?php echo $data['pengirim_eks'] ?></td>
											<?php }else{ ?>
												<td><?php echo $data['nama_unit'] ?></td>
											<?php } ?>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nomor Surat</b></td>
											<td><?php echo $data['no_s_masuk'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Nama Sub Kode</b></td>
											<td><?php echo $data['nama_kode'] ?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Surat</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_kirim']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Tanggal Terima</b></td>
											<td><?php echo date("d/m/Y", strtotime($data['tgl_s_terima']));?></td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Ditujukan Kepada</b></td>
											<td>
												<?php
													$qr = mysqli_query($koneksi,"SELECT * from surat_masuk where id_s_masuk='$data[id_s_masuk]'");
								                    while($dt = mysqli_fetch_array($qr)){
														if($dt['id_penerima']!=null){
															$getUnit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.id_unit='$dt[id_penerima]'"));
															if($getUnit['nama2']!=null){
																$penerima=$getUnit['nama2'].' '.$getUnit['nama1'];
															}else{
																$penerima=$getUnit['nama1'];
															}
														}else{
															$getPimpinan=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pimpinan where id_pimpinan='$dt[id_pimpinan]'"));
															$penerima=$getPimpinan['jabatan_struktural'];
														}
								                ?>
												<li><?php echo $penerima ?></li>
												<?php
													}
												?>
											</td>
										</tr>
										<tr class="gradeX">
											<td width="170"><b>Perihal</b></td>
											<td><?php echo $data['perihal_s_masuk'] ?></td>
										</tr>
										<!-- <tr class="gradeX">
											<td width="170"><b>No Agenda</b></td>
											<td><?php echo $data['no_agenda'] ?></td>
										</tr> -->
										<?php if($data['id_pimpinan']!=null){ ?>
											<tr class="gradeX">
												<td width="170" colspan="2" style="font-size: 15px; color:red;"><b>PROSES</b></td>
											</tr>
											<tr class="gradeX">
												<td width="170"><b>Status</b></td>
												<td>
													<?php if($data['status_s_masuk']=='1'){ ?>
														Menghadiri/Menyanggupi
													<?php
														}elseif($data['status_s_masuk']=='0'){
													?>
														Disposisi
													<?php
														}else{
													?>
														Belum Diproses
													<?php
														}
													?>
												</td>
											</tr>
											<tr class="gradeX">
												<td colspan="2">
													<div class="panel-group" id="accordionPrimary">
														<?php
															$rowdispo = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk WHERE id_s_masuk = '$_GET[kd]' ")); 
															if($rowdispo > 0){
																$qdispo = mysqli_query($koneksi,"SELECT * FROM dispo_s_masuk WHERE id_s_masuk = '$_GET[kd]' GROUP BY pemberi ");
																while ($datadispo = mysqli_fetch_array($qdispo)) {
																	$getpemberi=mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM pgw WHERE id_pgw ='$datadispo[pemberi]'"));
															?>
														<div class="panel panel-accordion panel-accordion-primary">
															<div class="panel-heading">
																<h4 class="panel-title">
																	<a class="accordion-toggle" data-toggle="collapse"
																		data-parent="#accordionPrimary"
																		href="#<?php echo $datadispo['id_dispo'] ?>">
																		<?php echo $getpemberi['gelar_depan']." ".$getpemberi['nama'].",".$getpemberi['gelar_belakang'] ?>
																	</a>
																</h4>
															</div>
															<div id="<?php echo $datadispo['id_dispo'] ?>"
															class="accordion-body collapse">
															<div class="panel-body">
																Disposisi Ke:
																<ul>
																	<?php
																		$qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk where id_s_masuk='$data[id_s_masuk]' and pemberi = '$datadispo[pemberi]' ");
																		// $qr = mysqli_query($koneksi,"SELECT * from dispo_s_masuk inner join pgw on pgw.id_pgw=dispo_s_masuk.id_pgw where id_s_masuk='$data[id_s_masuk]' and pemberi = '$datadispo[pemberi]' ");
																		while($dta = mysqli_fetch_array($qr)){
																			$st = '';
																			if($dta['status']=='1'){
																				$st = 'OK';
																			} else if($dta['status']=='0'){
																				$st='Disposisi';
																			} else {
																				$st='Belum Konfirmasi';
																			}
																		if($dta['unit']=='0'){
																			$pgw=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from pgw where id_pgw=$dta[id_pgw]"));
										                			?>
										                				<li>
																			<b><?php echo $pgw['gelar_depan']." ".$pgw['nama'].",".$pgw['gelar_belakang'] ?> </b>
																			(<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>) - <?php echo $st ?>
																		</li>
										                			<?php
										                				}else{
										                					$unt=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from unit where id_unit=$dta[id_pgw]"));
										                			?>
										                				<li>
																			<b><?php echo $unt['nama_unit'] ?> </b>
																			(<?php echo date("d/m/Y", strtotime($dta['tgl_dispo']));?>) - <?php echo $st ?>
																		</li>
										                			<?php
										                				}
										                			?>
																	<p> - Instruksi/Informasi :  <?php
																		if($dta['info_pemberi_dispo']!='' && $dta['informasi']==''){
																			echo $dta['info_pemberi_dispo'];
																		}else{
																			echo $dta['informasi'];
																		}
																	?>
																	</p>
																	<?php
																		}
																	?>
																</ul>
															</div>
														</div>
														</div>
														<?php 
																}
															} else {
																if($data['status_s_masuk'] == '0' ){
																	echo "<b>" .$pimpinan. "</b> Mendisposisi";
															?>
															<?php
																} else if($data['status_s_masuk'] == '1' ) {
																	echo "<b>" .$pimpinan['gelar_depan']." ".$pimpinan['nama'].", ".$pimpinan['gelar_belakang']." ". "</b> OK";
																} else {
																	echo "<b>" .$pimpinan['gelar_depan']." ".$pimpinan['nama'].", ".$pimpinan['gelar_belakang']."&nbsp;". "</b> <span class='label label-warning' style='color: black;'>Belum Memberi Putusan</span>";
																}
															}
														?>
													</div>
												</td>
											</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
							<div id="recent10" class="tab-pane">
								<div id="example1"></div>
							</div>
							<!-- <?php
								if($suratTugas!=""){
							?>
								<div id="recent11" class="tab-pane">
									<div id="example2"></div>
								</div>
							<?php
								}else{
							?>
								<div id="recent11" class="tab-pane">
									<h3 style="text-align: center;">Tidak ada surat tugas</h3>
								</div>
							<?php
								}
							?> -->
						</div>
					</div>
				</div>
				<footer class="panel-footer">
					<a href="javascript:window.history.back()" class="btn btn-default">Kembali</a>
				</footer>
			</section>
		</form>
	</div>
</div>

<script src="../../assets/PDFObject-master/pdfobject.js"></script>
<script>PDFObject.embed("../../File/SuratMasuk/<?php echo $surat ?>#toolbar=1", "#example1");</script>
<script>PDFObject.embed("../../File/Surat Tugas/<?php echo $suratTugas ?>#toolbar=1", "#example2");</script>

<style>
.pdfobject-container { height: 90rem; border: 0.4rem solid rgba(0,0,0,.1); }
</style>

<script>
	function hanyaAngka(evt) {
	    var charCode = (evt.which) ? evt.which : event.keyCode
	    	if (charCode > 31 && (charCode < 48 || charCode > 57))

	    	return false;
	    return true;
	}
</script>