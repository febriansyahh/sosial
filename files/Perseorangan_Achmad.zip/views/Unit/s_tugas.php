<header class="page-header">
	<h2>Arsip Surat Masuk</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Arsip Surat Masuk</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<section class="panel">
	<?php
        $query = mysqli_query($koneksi,"SELECT * from kode_surat where level='1' order by kd_surat asc");
        while($data = mysqli_fetch_array($query)){

        	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT count(*) as cnt , id_s_masuk, parent from surat_masuk a inner join kode_surat b on b.id_kode=a.id_kode where a.id_pimpinan != 'NULL' and parent='$data[id_kode]' group by parent"));
        	// var_dump($cek);
        	if($cek['cnt'] > 0){
        		$ttl=$cek['cnt'];
        		$label='<span class="label-label-success">Surat</span>';
        	}else{
        		$ttl='0';
        		$label='';
			}

			$belum=mysqli_num_rows(mysqli_query($koneksi, "SELECT count(*) as blm, sm.id_kode from surat_masuk sm 
					inner join kode_surat ks on sm.id_kode = ks.id_kode inner join dispo_s_masuk dm on dm.id_s_masuk=sm.id_s_masuk
					where not exists(SELECT*from surat_tugas where surat_tugas.id_s_masuk=dm.id_s_masuk) and ks.parent='$data[id_kode]' group by parent"));

			if($belum > 0){
        		// $ttl=$cek['cnt'];
        		// $label='<span class="highlight">Surat Belum Proses</span>';
        		$belumm='<span class="label label-danger">'.$belum.' Surat Belum Proses</span>';
        	}else{
        		// $ttl='0';
        		$belumm='';
        	}
			
			$cekproses = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM surat_tugas WHERE id_s_masuk='$cek[id_s_masuk]'"));
			if(!$cekproses){
				$blmkonfirm = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM surat_masuk sm INNER JOIN kode_surat ks ON sm.id_kode = ks.id_kode WHERE ks.parent = '$cek[parent]' AND sm.id_s_masuk='$cek[id_s_masuk]' AND sm.id_s_masuk NOT IN(SELECT id_s_masuk FROM surat_tugas)"));
			} else {
				// echo "sudah";
			}
    ?>
	<div class="col-md-6 col-lg-6 col-xl-3">
		<section class="panel panel-featured-bottom panel-featured-primary">
			<div class="panel-body">
				<div class="widget-summary">
					<div class="widget-summary-col widget-summary-col-icon">
						<div class="summary-icon bg-primary">
							<?php echo $data['kd_surat'] ?>
						</div>
					</div>
					<div class="widget-summary-col">
						<div class="summary">
							<h4 class="title"><?php echo $data['nama_kode'] ?></h4>
							<div class="info">
								<strong class="amount"><?php echo $ttl ?></strong> <?php echo $label ?>
								<?php  echo $belumm ?>
								<!-- <span class="text-primary">(14 unread)</span> -->
								<!-- <?php 
									if($blmkonfirm > 0) {
								?>
								<div class="label label-warning" style="float:right"><?php echo $blmkonfirm ?> Belum Diproses </div>
								<?php 
									}
								?> -->
							</div>
						</div>
						<div class="summary-footer">
							<a href="?v=s_tugas_daftar&id=<?php echo $data['id_kode'] ?>" class="text-uppercase">Tampilkan Semua</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<?php
		}
	?>
</section>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });
</script>