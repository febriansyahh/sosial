<header class="page-header">
	<h2>Kode Surat</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Kode Surat</span></li>
			<li><span>Ubah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			$data=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from kode_surat where id_kode='$_GET[id]'"));
			$unit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from unit where id_unit='$getUnit[id_unit]'"));

		    if (isset ($_POST ['btnSimpan'])) {

		      	$sql_update = "UPDATE kode_surat SET
		      		kd_surat='".$_POST['txtKode']."',
		      		nama_kode='".$_POST['txtNama']."'
		      		WHERE id_kode='".$_GET['id']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

		        if ($query_update) {
		          	echo "<div class='alert alert-primary'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Ubah Berhasil!</strong> Tunggu...
						</div>";
		          	echo "<meta http-equiv='refresh' content='1; url=?v=kode'>";
		        }
		    }

		    if (isset ($_POST ['btnSetting'])) {
		  		$cek=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from setting_nomor where id_unit='$getUnit[id_unit]' and tipe='Urut Kode' and id_kode='$_GET[edit]'"));
		  		// var_dump($cek);exit();

		  		if($cek > 0){
		  			$sql_update = "UPDATE setting_nomor SET
			      		setting='".$_POST['rbSetting']."',
			      		nomor_surat='".$_POST['txtNomor']."'
			      		WHERE id_unit='".$getUnit['id_unit']."' and tipe='Urut Kode' and id_kode='".$_GET['edit']."'";
			        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());
		  		}else{
		  			$sql_insert = "INSERT INTO setting_nomor (tipe,setting,id_kode,id_unit,nomor_surat) VALUES (
			                'Urut Kode',
			                '".$_POST ['rbSetting']."',
			                '".$_GET ['edit']."',
			                '".$getUnit ['id_unit']."',
			            	'".$_POST ['txtNomor']."')";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());
		  		}

				if ($query_update || $query_insert) {
		      		echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]');</script>";
		    	}
		    }

		    if (isset ($_POST ['btnTambah'])) {
				$sql_insert = "INSERT INTO kode_surat (kd_surat,nama_kode,level,parent) VALUES (
					  '".$_POST ['txtKode_sub']."',
					  '".$_POST ['txtNama_sub']."',
					  '2',
		              '".$_GET ['id']."')";
		        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

	        	if ($query_insert) {
	          		echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]&edt_sub=1#1');</script>";
	        	}
		    }

		    if (isset ($_POST ['btnUbah'])) {
				$sql_update = "UPDATE kode_surat SET
		      		kd_surat='".$_POST['txtKode_sub']."',
		      		nama_kode='".$_POST['txtNama_sub']."'
		      		WHERE id_kode='".$_GET['edit']."'";
		        $query_update = mysqli_query($koneksi,$sql_update) or die (mysqli_error());

	        	if ($query_update) {
	          		echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]&edt_sub=1#1');</script>";
	        	}
		    }

		    if (!$_GET['del']=="") { 

				$sql_hapus = "DELETE FROM kode_surat WHERE id_kode='".$_GET['del']."'";
				$query_hapus = mysqli_query($koneksi,$sql_hapus) or die (mysqli_error());
				if ($query_hapus) {
			        echo "<script>window.location.replace('?v=kode_ubah&id=$_GET[id]&edt_sub=1#1');</script>";
			    }
		  	}
		?>
		
		<form method="POST" class="form-horizontal">
			<?php if($_GET['edit']!=''){
				$edit=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from setting_nomor where id_unit='$getUnit[id_unit]' and tipe='Urut Kode' and id_kode='$_GET[edit]'"));
			?>
			<section class="panel">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Setting</h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="form-group">
						<label class="col-sm-2 control-label">Setting Tipe: </label>
						<div class="col-sm-8">
							<div class="col-sm-2">
								<div class="radio-custom">
									<input type="radio" id="radio1" name="rbSetting" value="Otomatis" <?php if($edit['setting']=='Otomatis' || $edit==null){echo "checked";} ?>>
									<label for="radio1">Otomatis</label>
								</div>
							</div>
							<div class="col-sm-2">
								<div class="radio-custom">
									<input type="radio" id="radio2" name="rbSetting" value="Manual" <?php if($edit['setting']=='Manual'){echo "checked";} ?>>
									<label for="radio2">Manual</label>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">Nomor Urut: </label>
						<div class="col-sm-2">
							<?php if($edit['setting']=='Otomatis' || $edit==null){ ?>
								<input type="text" class="form-control" name="txtNomor" id="nomor" disabled>
							<?php }else{ ?>
								<input type="text" class="form-control" name="txtNomor" id="nomor" required value="<?php echo $edit['nomor_surat'] ?>">
							<?php } ?>
						</div>
					</div>
				</div>
				<footer class="panel-footer">
						<button class="btn btn-success" type="submit" name="btnSetting">Simpan </button>
					<a href="?v=kode_ubah&id=<?php echo $_GET['id'] ?>" class="btn btn-default">Batal</a>
				</footer>
			</section>
			<?php } ?>

			<section class="panel" id='1'>
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
					</div>

					<h2 class="panel-title">Sub Kode Surat - <?php echo $data['kd_surat'] ?> - <?php echo $data['nama_kode'] ?></h2>
					<!-- <p class="panel-subtitle">
						Use <code>.form-horizontal</code> class in the form to style with horizontal fields.
					</p> -->
				</header>
				<div class="panel-body">
					<div class="col-sm-12">
						<table class="table table-bordered table-striped mb-none" id="datatable-default">
							<thead>
								<tr>
									<th width="32">No</th>
									<th>Kode</th>
									<th>Nama Kode</th>
									<th>Tipe</th>
									<th>Nomor Mulai</th>
									<th width="125"></th>
								</tr>
							</thead>
							<tbody>
								<?php
				                    $no=1;
				                    $query = mysqli_query($koneksi,"SELECT * from kode_surat where parent='$_GET[id]' and level='2' order by kd_surat asc");
				                    // var_dump("SELECT * from kode_surat where parent='$_GET[id]' and level='2' order by kd_surat asc");
				                    while($dt = mysqli_fetch_array($query)){
				                    	$cek=mysqli_fetch_array(mysqli_query($koneksi, "SELECT *FROM setting_nomor where id_unit='$unit[id_unit]' and id_kode='$dt[id_kode]' and tipe='Urut Kode'"));
				                    if($_GET['edit']==$dt['id_kode']){
				                ?>
				                <tr class="gradeX" style="background-color: yellow;">
				                <?php }else{ ?>
				                <tr class="gradeX">
				                <?php } ?>
									<td><center><?php echo $no ?>.</center></td>
									<td><?php echo $dt['kd_surat'] ?></td>
									<td><?php echo $dt['nama_kode'] ?></td>
									<td><center>
										<?php
											if($cek==null){
												echo "<b>Otomatis</b>";
											}else{
												echo "<b>".$cek['setting']."</b>";
											}
										?>
									</center></td>
									<td><center>
										<?php
											if($cek==null){
												echo "";
											}else{
												echo "<b>".$cek['nomor_surat']."</b>";
											}
										?>
									</center></td>
									<td>
										<?php if($_GET['edit']!=$dt['id_kode']){ ?>
											<a href="?v=kode_ubah&id=<?php echo $dt['parent'] ?>&edit=<?php echo $dt['id_kode'] ?>" title="Ubah" class="btn btn-xs btn-warning">Setting</a>
										<?php } ?>
									</td>
								</tr>
								<?php
									$no++;
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</section>
		</form>
	</div>
</div>

<div class="modal fade" id="konfirmasi_hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Lanjutkan hapus data?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Data yang berelasi ikut terhapus.
            </div>
            <div class="modal-footer">
                <a class="btn btn-danger btn-ok"><i class="fa fa-trash"></i> Hapus</a>
                <button type="button" class="btn btn-light" data-dismiss="modal"><i class="fa fa-close"></i> Batal</button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/vendor/jquery/jquery.js"></script>

<script type="text/javascript">
    //Hapus Data
    $(document).ready(function() {
        $('#konfirmasi_hapus').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    });

    $(document).ready(function () {
		$("input[name=rbSetting]:radio").click(function () {
			if ($(this).attr("value") == "Otomatis") {
				console.log("Otomatis");
				$("#nomor").val("");
				document.getElementById("nomor").disabled = true;
			}
			if ($(this).attr("value") == "Manual") {
				console.log("Manual");
				$("#nomor").val("");
				document.getElementById("nomor").disabled = false;
			}
		});
	});
</script>