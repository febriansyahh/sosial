<header class="page-header">
	<h2>Surat Keluar</h2>

	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li>
				<a href="?v=beranda">
					<i class="fa fa-home"></i>
				</a>
			</li>
			<li><span>Surat Keluar</span></li>
			<li><span>Tambah</span></li>
		</ol>

		<a class="sidebar-right-toggle"></a>
	</div>
</header>

<div class="row">
	<div class="col-md-12">
		<?php

			require '../../PHPMailer/PHPMailerAutoload.php';
			$mail = new PHPMailer;

			$getUnit = mysqli_fetch_array(mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent inner join user c on a.id_unit = c.id_unit where a.level='1' and c.username = '$_SESSION[username]' order by b.nama_unit,a.nama_unit asc  "));
			if($getUnit['parent']==''){
				$kirim = $getUnit['nama1'];
			} else {
				$kirim = $getUnit['nama2']." ".$getUnit['nama1'];
			}

		    if (isset ($_POST ['btnSimpan'])) {

		    	$cekNoSurat=mysqli_num_rows(mysqli_query($koneksi, "SELECT*from surat_keluar where no_s_keluar='$_POST[cboNoSurat]'"));
		    	if($cekNoSurat>0){
		    		echo "<div class='alert alert-danger'>
							<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
							<strong>Simpan Gagal!</strong> No Surat <strong>$_POST[cboNoSurat]</strong> sudah dimasukkan.
						  </div>";
		    	}else{

					$mail->isSMTP();                                     
					$mail->Host = 'smtp.gmail.com';  
					$mail->SMTPAuth = true;                      
					$mail->Username = 'ardi.irfanto@umk.ac.id';        
					$mail->Password = 'Regenerator';                         
					$mail->SMTPSecure = 'tls';                           
					$mail->Port = 587;                                   
					$mail->setFrom('ardi.irfanto@umk.ac.id', 'Sistem Pengiriman Surat UMK');
					$mail->smtpConnect(
						array(
							"ssl" => array(
								"verify_peer" => false,
								"verify_peer_name" => false,
								"allow_self_signed" => true
							)
						)
					);

		    		$nama2=str_replace('/', '', $_POST['cboNoSurat']);
			        $file_nama = $nama2.".pdf";

			        date_default_timezone_set('Asia/Jakarta');
					$waktu=date('Y-m-d H:i:s');

					$id_unit = $_POST['cboPengirim'];

					$sql_insert = "INSERT INTO surat_keluar (no_s_keluar,tgl_s_keluar,perihal_s_keluar,ket_s_keluar,scan_s_keluar,id_kode,id_unit,time_s_keluar) VALUES (
	                        '".$_POST ['cboNoSurat']."',
	                        '".date("Y-m-d", strtotime($_POST['txtTgl']))."',
	                        '".$_POST ['txtPerihal']."',
	                        '".$_POST ['taKet']."',
	                        '".$file_nama."',
	                        '".$_POST ['cboKode']."',
	                        '".$id_unit."',
	                    	'".$waktu."')";
			        $query_insert = mysqli_query($koneksi,$sql_insert) or die (mysqli_error());

			        $getID=mysqli_fetch_array(mysqli_query($koneksi, "SELECT*from surat_keluar where no_s_keluar='$_POST[cboNoSurat]'"));
			        $idsurat=$getID['id_s_keluar'];

			        $tujuan=$_POST['cboTujuan'];
					$count = count($tujuan);
					 
					for($x=0;$x<$count;$x++){

						$cboUnit = explode('*', $tujuan[$x]);
						$jenis = $cboUnit[0];
						$idunit = $cboUnit[1];
						if($jenis=='P'){
							$query='id_pimpinan';
							$getMail = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan WHERE id_pimpinan = '$id_unit' "));
							$email = $getMail['email'];
							// $tujuan = $getMail['jabatan_struktural'];


							// mysqli_query($koneksi,"INSERT INTO surat_masuk (no_s_masuk,perihal_s_masuk,tgl_s_kirim,tgl_s_terima,scan_s_masuk,id_unit,id_kode,$query) VALUES (
							// 	'".$_POST ['cboNoSurat']."',
							// 	'".$_POST ['txtPerihal']."',
							// 	'".date("Y/m/d", strtotime($_POST['txtTgl']))."',
							// 	'".$waktu."',
							// 	'".$file_nama."',
							// 	'".$_POST ['cboPengirim']."',
							// 	'".$_POST ['cboKode']."',
							// 	'".$id_unit."'
							// )");

							// $getMail = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pimpinan WHERE id_pimpinan = '$id_unit' "));
							// $email = $getMail['email'];

						}else{
							$query='id_penerima';
							$getMail = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM unit WHERE id_unit='$id_unit' asc  "));
							$email = $getMail['email'];
							// if($getMail['parent']==''){
							// 	$tujuan = $getMail['nama1'];
							// } else {
							// 	$tujuan = $getMail['nama2']." ".$getMail['nama1'];
							// }
							
						}
						mysqli_query($koneksi,"INSERT INTO surat_masuk (no_s_masuk,perihal_s_masuk,tgl_s_kirim,tgl_s_terima,scan_s_masuk,id_unit,id_kode,$query) VALUES (
							'".$_POST ['cboNoSurat']."',
							'".$_POST ['txtPerihal']."',
							'".date("Y/m/d", strtotime($_POST['txtTgl']))."',
							'".$waktu."',
							'".$file_nama."',
							'".$_POST ['cboPengirim']."',
							'".$_POST ['cboKode']."',
							'".$idunit."'
						)");
						$mail->Subject = 'Pemberitahuan Surat Masuk';
						$mail->Body    = "<div class='card' style='margin:50px;'>
											<div class='card-header'>
												<h5 align='center'>Pemberitahuan Surat Masuk</h5>
											</div>
											<div class='card-body'>
												<div class='alert alert-success alert-bordered'>
													<p> <b> Berikut adalah Detail Surat: </b> </p>
													<p> Pengirim Surat      			:". $kirim ." </p>
													<p> Perihal Surat     				:". $_POST ['txtPerihal'] ." </p>
													<hr>
													<p> Download File Surat Masuk       : <a href='localhost/disposisi/File/SuratMasuk/". $file_nama."'> Download </a> </p>
													<p> Untuk Meninjau lebih detail terkait surat, silahkan login <a href='localhost/disposisi/'> Disini </a>  . Terima Kasih</p>
												</div>
											</div>
										</div>";
						$mail->AltBody = '----------------------------------------------';

						// $mail->addAddress('ardi.irfanto@umk.ac.id','1');
						$mail->addAddress('','1');
						$mail->isHTML(true);
						$mail->send();
						$mail->ClearAddresses();

					}

					if ($query_insert) {
						copy($_FILES['File']['tmp_name'],"../../File/SuratMasuk/".$file_nama);
						copy($_FILES['File']['tmp_name'],"../../File/SuratKeluar/".$file_nama);
		        		echo "<div class='alert alert-primary'>
								<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								<strong>Simpan Berhasil!</strong> Tunggu...
							  </div>";
		          		echo "<meta http-equiv='refresh' content='1; url=?v=s_keluar'>";
		        	}
		    	}
		    }
		?>
		
	</div>
</div>

<div class="row">
	<div class="col-xs-12">
		<section class="panel form-wizard" id="w4">
			<form class="form-horizontal" method="POST" enctype="multipart/form-data">
				<header class="panel-heading">
					<div class="panel-actions">
						<a href="#" class="fa fa-caret-down"></a>
						<a href="#" class="fa fa-times"></a>
					</div>

					<h2 class="panel-title">Tambah Surat Keluar</h2>
				</header>
				<div class="panel-body">
					<div class="wizard-progress wizard-progress-lg">
						<div class="steps-progress">
							<div class="progress-indicator"></div>
						</div>
						<ul class="wizard-steps">
							<li class="active">
								<a href="#w4-account" data-toggle="tab"><span>1</span>Lengkapi Surat</a>
							</li>
							<li>
								<a href="#w4-confirm" data-toggle="tab"><span>2</span>Upload Arsip</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<div id="w4-account" class="tab-pane active">
							<section class="panel">
								<div class="panel-body">
									<div class="form-group">
										<label class="col-sm-2 control-label">Pengirim: </label>
										<div class="col-sm-8">
											<?php 
												$getUnit  = mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM unit un INNER JOIN user us ON un.id_unit = us.id_unit WHERE us.username ='$_SESSION[username]' "))
											?>
											<select data-plugin-selectTwo class="form-control populate" name="cboPengirim" id="unitpengirim" required>
												<?php
													$qryPengirim = mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.login='1' AND a.id_unit = '$getUnit[id_unit]' order by b.nama_unit,a.nama_unit asc");
													while($dtPengirim = mysqli_fetch_array($qryPengirim)){
														if($dtPengirim['nama2']!=null){
															$unit=$dtPengirim['nama2'];
														} else {
															$unit = '';
														}
												?>
													<option value="<?php echo $dtPengirim['id_unit'] ?>" <?php if($getUnit['id_unit']==$dtPengirim['id_unit']){echo"SELECTED";} ?> ><?php echo $unit." ".$dtPengirim['nama1']  ?></option>
												<?php
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Kode Surat: </label>
										<div class="col-sm-8">
											<select data-plugin-selectTwo class="form-control populate" name="cboKode" id="kodesurat">
												<?php
													$query = mysqli_query($koneksi,"SELECT * from kode_surat where level='1' order by kd_surat asc");
													while($data = mysqli_fetch_array($query)){
												?>
												<optgroup label="<?php echo $data['kd_surat'] ?> - <?php echo $data['nama_kode'] ?>">
													<?php
														$qry = mysqli_query($koneksi,"SELECT * from kode_surat where level='2' and parent='$data[id_kode]' order by kd_surat asc");
														while($dt = mysqli_fetch_array($qry)){
													?>
														<option value="<?php echo $dt['id_kode'] ?>"><?php echo $data['kd_surat'] ?>.<?php echo $dt['kd_surat'] ?> - <?php echo $dt['nama_kode'] ?></option>
													<?php
														}
													?>
												</optgroup>
												<?php
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Tanggal Surat: </label>
										<div class="col-sm-2">
											<input type="text" name="txtTgl" data-plugin-datepicker class="form-control" required id="tanggalsurat" autocomplete="off">
										</div>
										<div class="col-sm-2">
											<button class="btn btn-warning" id="cek" type="submit" name="button">Cek Nomor</button>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">No Surat: </label>
										<div class="col-sm-7" id="nomorsurat">
											<span class="label label-default" id="ket" style='padding: 5px; line-height: 40px; font-size: 15px;'>*) Lengkapi pilihan kolom diatas terlebih dahulu</span>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Perihal Surat: </label>
										<div class="col-sm-6">
											<input type="text" class="form-control" name="txtPerihal" required maxlength="100" id="lantai" onkeyup="getKode()">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Ditujukan kepada: </label>
										<div class="col-sm-6">
											<select multiple data-plugin-selectTwo class="form-control populate" required name="cboTujuan[]">
												<?php
													$qryDitujuP = mysqli_query($koneksi,"SELECT * from pimpinan where status='1' and jabatan_struktural!='Ka BAU'");
													while($dtDitujuP = mysqli_fetch_array($qryDitujuP)){
												?>
												<option value="P*<?php echo $dtDitujuP['id_pimpinan'] ?>"><?php echo $dtDitujuP['jabatan_struktural'] ?></option>
												<?php
													}
													$qryDituju = mysqli_query($koneksi,"SELECT a.id_unit as id_unit,a.nama_unit as nama1, b.nama_unit as nama2 from unit a left join unit b on b.id_unit=a.parent where a.level='1' order by b.nama_unit,a.nama_unit asc");
													while($dtDituju = mysqli_fetch_array($qryDituju)){
														if($dtDituju['nama2']!=null){
															$unitt=$dtDituju['nama2'];
														}
												?>
													<option value="U*<?php echo $dtDituju['id_unit'] ?>"><?php echo $unitt ?> <?php echo $dtDituju['nama1'] ?></option>
												<?php
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Keterangan: </label>
										<div class="col-sm-9">
											<textarea name="taKet" class="form-control" rows="6"></textarea>
										</div>
									</div>
								</div>
							</section>
						</div>
						<div id="w4-confirm" class="tab-pane">
							<div class="form-group">
								<label class="col-sm-3 control-label" for="w4-email">File Arsip</label>
								<div class="col-sm-9">
									<input type="file" class="form-control" accept=".pdf" name="File" required>
									<small>*) File surat harus bertipe <code>.pdf</code></small>
								</div>
							</div>
							<button class="btn btn-success" type="submit" name="btnSimpan">Simpan </button>
						</div>
					</div>
				</div>
				<div class="panel-footer">
					<ul class="pager">
						<li class="previous disabled">
							<a><i class="fa fa-angle-left"></i> Sebelumnya</a>
						</li>
						<li class="finish hidden pull-right">
							
						</li>
						<li class="next">
							<a>Selanjutnya <i class="fa fa-angle-right"></i></a>
						</li>
					</ul>
				</div>
			</form>
		</section>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$("#cek").click(function(){
			var kodesurat = $('#kodesurat').val();
			var tanggalsurat = $('#tanggalsurat').val();
			var unitpengirim = $('#unitpengirim').val();

			// console.log(kodesurat);
			// console.log(tanggalsurat);

      		$.ajax({
            	type : 'POST',
           		url : 'ceknomor.php',
            	data :  {'kodesurat' : kodesurat, 'tanggalsurat' : tanggalsurat, 'unitpengirim' : unitpengirim},
            	// data: 'kodesurat=' + kodesurat,
            	dataType: "html",
					success: function (response) {

					$("#nomorsurat").html(response);
				}
          	});
		});
	});
</script>