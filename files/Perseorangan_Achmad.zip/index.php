<!doctype html>
<html class="fixed">
	<head>

		<!-- Basic -->
		<meta charset="UTF-8">
		<title>Halaman Login</title>

		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
		<link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="assets/stylesheets/theme.css" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

		<!-- Head Libs -->
		<script src="assets/vendor/modernizr/modernizr.js"></script>

	</head>
	<body>
		<!-- start: page -->
		<section class="body-sign">
			<div class="center-sign">
				<a href="/" class="logo pull-left">
					<img src="assets/images/logosn.png" height="54" alt="Porto Admin" />
				</a>

				<div class="panel panel-sign">
					<div class="panel-title-sign mt-xl text-right">
						<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Log In</h2>
					</div>
					<div class="panel-body">
						<form method="post">

							<?php
								if(isset($_POST["btnLogin"]))
								{
								  include "koneksi.php";
								  session_start();
								  $query = "SELECT * FROM user WHERE username = '".$_POST['txtUser']."'";
								  $statement = mysqli_query($koneksi, $query);
								  $total_row = mysqli_num_rows($statement);
								  $output = '';
								  if($total_row > 0)
								  {
								    while($row = mysqli_fetch_array($statement)){
								      if($_POST["txtPass"] == $row["password"])
								      {
										$_SESSION["username"] = $row["username"];
										$_SESSION["level"] = $row["level"];
								        if($row["level"]=='Admin'){
								          echo "<div class='alert alert-primary'>
								                        <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
								                     </div>
								                     <meta http-equiv='refresh' content='1; url=views/Admin/index.php'>";
								        }elseif($row["level"]=='Pimpinan'){
								          echo "<div class='alert alert-primary'>
								                        <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
								                     </div>
								                     <meta http-equiv='refresh' content='1; url=views/Pimpinan/index'>";
										}
										elseif($row["level"]=='Unit'){
											echo "<div class='alert alert-primary'>
														  <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
													   </div>
													   <meta http-equiv='refresh' content='1; url=views/Unit/index'>";
										}elseif($row["level"]=='BAU'){
											echo "<div class='alert alert-primary'>
														  <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
													   </div>
													   <meta http-equiv='refresh' content='1; url=views/Bau/index'>";
										}elseif($row["level"]=='BAAK'){
											echo "<div class='alert alert-primary'>
														  <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
													   </div>
													   <meta http-equiv='refresh' content='1; url=views/Baak/index'>";
										  }
								      }else{
								          echo  "<div class='alert alert-danger'>
								                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								                        <strong>Login Gagal! Password salah.
								                    </div>";
								      }
								    }
								  }else{
								    echo "<div class='alert alert-danger'>
								                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
								                  <strong>Login Gagal! Username tidak ditemukan.
								               </div>";
								  }
								  echo $output;
								}
							?>
							<span id="error_message"></span>
							

							<div class="form-group mb-lg">
								<label>Username</label>
								<div class="input-group input-group-icon">
									<input name="txtUser" type="text" class="form-control input-lg" />
									<span class="input-group-addon">
										<span class="icon icon-lg">
											<i class="fa fa-user"></i>
										</span>
									</span>
								</div>
							</div>

							<div class="form-group mb-lg">
								<div class="clearfix">
									<label class="pull-left">Password</label>
								</div>
								<div class="input-group input-group-icon">
									<input name="txtPass" id="txtPass" type="password" class="form-control input-lg" />
									<span class="input-group-addon">
										<span class="icon icon-lg">
											<i class="fa fa-lock"></i>
										</span>
									</span>
								</div>
							</div>

							<div class="row">
								<div class="col-sm-8">
									<div class="checkbox-custom checkbox-default">
									</div>
								</div>
								<div class="col-sm-4 text-right">
									<button type="submit" name="btnLogin" class="btn btn-primary hidden-xs">Log In</button>
								</div>
							</div>

						</form>
					</div>
				</div>

				<p class="text-center text-muted mt-md mb-md"><?php echo date('Y') ?>. Universitas Muria Kudus</p>
			</div>
		</section>
		<!-- end: page -->

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>
</html>

<!-- <script>
$(document).ready(function(){
	$('#login_form').on('submit', function(event){
		event.preventDefault();
		$.ajax({
			url:"check_login.php",
			method:"POST",
			data:$(this).serialize(),
			success:function(data){
				if(data != ''){
					$('#error_message').html(data);
					$('#txtPass').val('');  
				}
			}
		})
	});
});
</script> -->