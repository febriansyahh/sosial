<?php

//check_login.php

if(isset($_POST["txtUser"]))
{
  include "koneksi.php";
  session_start();
  $query = "SELECT * FROM user WHERE username = '".$_POST['txtUser']."'";
  $statement = mysqli_query($koneksi, $query);
  $total_row = mysqli_num_rows($statement);
  $output = '';
  if($total_row > 0)
  {
    while($row = mysqli_fetch_array($statement)){
      if($_POST["txtPass"] == $row["password"])
      { 
        $_SESSION["id_user"] = $row["id_user"];
        $_SESSION["username"] = $row["username"];
        $_SESSION["level"] = $row["level"];
        if($row["level"]=='Admin'){
          $output = "<div class='alert alert-primary'>
                        <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
                     </div>
                     <meta http-equiv='refresh' content='1; url=views/Admin/index.php'>";
        }elseif($row["level"]=='Pimpinan'){
          $output = "<div class='alert alert-primary'>
                        <strong>Login Berhasil!</strong> Tunggu ... <i class='fas fa-circle-notch fa-spin'></i>
                     </div>
                     <meta http-equiv='refresh' content='1; url=views/Pimpinan/index'>";
        }
      }else{
          $output = "<div class='alert alert-danger'>
                        <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
                        <strong>Login Gagal! Password salah.
                    </div>";
      }
    }
  }else{
    $output = "<div class='alert alert-danger'>
                  <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
                  <strong>Login Gagal! Username tidak ditemukan.
               </div>";
  }
  echo $output;
}

?>