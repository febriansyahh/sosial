<?php
	$koneksi = mysqli_connect("localhost","sispo","sispoUMK#21","sispo");
?>